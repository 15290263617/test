<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Admin\Controller;
use Think\Controller;
class SysController extends PublicController {
	
	//系统常量
	public function index(){
		$page = I('page')? : 1;
        $count = M('sys_enum')->where("egroup=11 or egroup=12")->order("id desc")->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
        $data=M('sys_enum')->where("egroup=11 or egroup=12")->order("id desc")->limit($rpage1,$rpage2)->select();
        $this->assign('data',$data);
        $this->assign('page',$rpage['page']);
		$this->display();
	}
	
	//图片修改
	public function mod(){
		$id=I('get.id');
		$conf=M('sys_enum')->where("id='$id'")->find();
		$this->assign('conf',$conf);
		$this->display();
	}

	//普通修改
	public function edit(){
		$id=I('get.id');
		$conf=M('sys_enum')->where("id='$id'")->find();
		$this->assign('conf',$conf);
		$this->display();
	}
	
	//系统常量编辑
	public function editconf(){
	   $id=I('post.id');
	   $data['ename']=I('post.ename');
	   $data['evalue']=I('post.evalue');
       $result=M('sys_enum')->where("id='$id'")->save($data);
       if($result){
            $msg['status'] = 1;
			$msg['info']="修改成功";
        } else {
			  $msg['status'] = "修改失败";
              $msg['info'] = 0;
            }
        $this->ajaxReturn($msg);
	}
	
	//导航管理
	public function nav(){
		$data=M("sys_enum")->where("egroup='1'")->order("id asc")->select();
        $this->assign("data", $data);
        $this->display();		
	}
	
	
	//导航编辑
	public function editnav() {
       $evalue=I("post.evalue");
       $map['id']=I("post.id");
       $map['evalue']=$evalue;
        $nav=M("sys_enum");
       
        $result=$nav->save($map);
        if($result){
            $data['info']=1;
        }else{
            $data['info']=0;
        }
        $this->ajaxReturn(json_encode($data));
    }
	
	//友情链接管理
	public function friend(){
		$page = I('page')? : 1;
        $count = M('sys_enum')->where("egroup=10")->order("id desc")->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
        $data=M('sys_enum')->where("egroup=10")->order("id desc")->limit($rpage1,$rpage2)->select();
        $this->assign('data',$data);
        $this->assign('page',$rpage['page']);
		$this->display();
	}
	
   //友情链接添加
	public function add(){
		   $date['ename']=I('post.ename');
		   $date['evalue']=I('post.evalue');
		   $date['egroup']=10;
		   $result=M('sys_enum')->add($date);
		   if($result){
			$dat['info']=1;
        }else{
            $dat['info']=0;
        }
        $this->ajaxreturn($dat);
			   
	   
   }
   
   
   //友情链接编辑
   public function editf(){
		$id=I('post.id');
		$date['ename']=I('post.ename');
		$date['evalue']=I('post.evalue');
		$res=M('sys_enum')->where("id='$id'")->save($date);
		if($res){
		$dat['info']=1;
        }else{
        $dat['info']=0;
        }
        $this->ajaxreturn($dat);
   }
   
   //友情链接删除
   public function delete(){
	    $id = I('post.id');
        $result = M('sys_enum')->where("id='$id'")->delete();
        if ($result) {
                $stat['status'] = 1;
            } else {
                $stat['status'] = 0;
            }
        $this->ajaxReturn($stat);
   }
   
  
  

   
   
//上传图片处理
    public function upload() {
        if ($_FILES['upload']['error'] === 0) {
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
            $upload->savePath = './badge/';
            $upload->saveName = array('uniqid', '');
            $info = $upload->upload();
            if (!$info) {
                $this->error($upload->getError());
            } else {
                foreach ($info as $file) {
                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];
              
                }

                echo json_encode(array('info' => 1, 'path' => $path));
            }
        } else {
            $this->error('上传失败');
        }
    }
	
	
}
