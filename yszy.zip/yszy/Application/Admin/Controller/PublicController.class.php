<?php

namespace Admin\Controller;

use Think\Controller;

class PublicController extends Controller {
	
    function __construct() {
        parent::__construct();
        
        $HTQX = session('HTQX');
        if ($HTQX != 'xdz') {
            /* header("Content-type:text/html; charset=utf-8");
            die('����Ƿ�'); */
			$this->redirect ( 'User/Index/index' );
        }
        $uid=session("adminid");
        $a_d=M("admin")->where("id=$uid")->find();
        $this->assign('a_d',$a_d);
		$rolesss=explode('-',$a_d['role']);
		$this->assign('rolesss',$rolesss);
    }
	//�ж�Ȩ��
	public function qx($id){
		$adminid=session('adminid');
		$roless=M('admin')->where("id='$adminid'")->getField("role");
		$rolesss=explode('-',$roless);
		$result=in_array($id,$rolesss);
		return $result;
	}
    public function error1() {
        layout(false);
        $this->display();
    }

    public function _empty() {
        $this->redirect('Public/error1');
    }
}