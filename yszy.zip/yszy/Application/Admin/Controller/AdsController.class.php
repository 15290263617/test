<?php
namespace Admin\Controller;
use Think\Controller;
class AdsController extends PublicController {

//最新中的banner添加
	public function banner(){
		if(I('post.')){
			$date=I('post.');
			$date['ptime']=time();
			$result=M('ads')->add($date);
			if($result){
			$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);

		}else{
			//$date=$this->navcate();
			//$this->assign('date',$date);
			$this->display();
		}
		
	}                                                                                                                     

//Banner广告列表
	public function blist(){
		$page = I('page')? : 1;
        $count =M('ads')->count();
        $rpage = Page($count, 8, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
		$banner=M('ads')->order('ad_id desc')->limit($rpage1,$rpage2)->select();
		$this->assign('banner',$banner);
		$this->assign('page',$rpage['page']);
		$this->display();
	}

//Banner广告编辑
	public function bedit(){
		if(I('post.')){
			$id=I('post.ad_id');
			$date=I('post.');
			$result=M('ads')->where("ad_id='$id'")->save($date);
			if($result){
			$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);


		}else{
		$id=I('get.id');
		$banner=M('ads')->where("ad_id='$id'")->find();
		$this->assign('ads',$banner);
		$this->display();
	}
	}

//banner广告删除
	public function bdelete(){
		$id=I('post.id');
		$result=M('ads')->where("ad_id='$id'")->delete();
		if($result){
			$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);
	}

//获取导航分类
	public function navcate(){
		$nav=M('nav')->where("type!=1")->order('id asc')->select();
		 	$str = '<select class="form-control" id="nav_id" name="navid"><option value="">请选择</option>';
            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>" . $this->getsub($v['id']);
            
                }
            $str .= '</select>';
       
           return $str;
	}

public function navcate4(){
        $nav=M('nav')->where("type=0")->order('id asc')->select();
            $str = '<select class="form-control" id="nav_id" name="navid"><option value="">请选择</option>';
            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>";
            
                }
            $str .= '</select>';
       
           return $str;
    }

//获取视频导航分类
    public function navcate2(){
        $nav=M('nav')->where("type=0")->order('id asc')->select();

            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>" ;
            
                }
          
       
           return $str;
    }

//获取视频导航分类
    public function navcate3(){
        $nav=M('nav')->where("type!=1")->order('id asc')->select();

            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>". $this->getsub($v['id']);
            
                }
          
       
           return $str;
    }

//获取导航的子类
	 //查找子类
     public function getsub($id) {
        $art_cate = M('nav');
        $cateData = $art_cate->where("pid='$id'")->order('id asc')->select();
        if (empty($cateData))
            return false;
        $ret = '';
        foreach ($cateData as $k => $v) {
            
            
            $ret .= "<option value='{$v['id']}'>&nbsp;&nbsp;&nbsp;&nbsp;|_{$v['name']}</option>";
           
        }
        return $ret;
    }

//添加广告
	public function index(){
		if(I('post.')){
			$date=I('post.');
			$date['ptime']=time();
			$result=M('ads')->add($date);
			if($result){
			$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);

		}else{
		$date=$this->navcate();
		// dump($date);exit;
		$this->assign('date',$date);
		$this->display();
		}
	}

//广告列表
	public function adlist(){
		$date=$this->navcate3();
		$this->assign('date',$date);

		$navid=$_POST['navid'];
    	$position=$_POST['position_id'];
    	if($navid!=null){
    		$where.="and nav_id='$navid'";
    	}
    	if($position!=null){
    		$where.="and position_id='$position'";
    	}
    	$ads=M('ads');
    	$page = I('page')? : 1;
        $count = $ads->where("1=1 $where")->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
    	$adslist=$ads->where("1=1 $where")->order("id desc")->limit($rpage1,$rpage2)->select();
    	$this->assign('navid',$navid);
    	$this->assign('position',$position);
    	$this->assign('ads',$adslist);
    	$this->assign('page',$rpage['page']);
		$this->display();
	}

//广告编辑
	public function adedit(){
        if(I('post.')){
            $id=I('post.id');
            $date=I('post.');
            $result=M('ads')->where("id='$id'")->save($date);
            if($result){
            $dat['status']=1;
         }else{
            $dat['status']=0;
        }
        $this->ajaxreturn($dat);

        }else{
		$id=I('get.id');

		$ads=M('ads')->where("id='$id'")->find();
		$this->assign('ads',$ads);
		$navid=$ads['nav_id'];
		$navname=M('nav')->where("id='$navid'")->getField("name");
		

			$nav=M('nav')->where("type!=1")->order('id asc')->select();
		 	$str = "<select class='form-control' id='nav_id' name='navid'><option value='{$ads['nav_id']}'>{$navname}</option><option value=''>请选择</option>";
            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>" . $this->getsub($v['id']);
            
                }
            $str .= '</select>';
       
        $this->assign('date',$str);
		$this->display();
        }
	}

//广告删除
    public function adelete(){
        $id=I('get.id');
        $result=M('ads')->where("id='$id'")->delete();
        if($result){
            $dat['status']=1;
        }else{
            $dat['status']=0;
        }
        $this->ajaxreturn($dat);
    }

//视频添加
    public function video(){
        if(I('post.')){
            $date=I('post.');
            $date['ptime']=time();
            $result=M('video')->add($date);
            if($result){
            $dat['status']=1;
        }else{
            $dat['status']=0;
        }
        $this->ajaxreturn($dat);

        }else{
        $date=$this->navcate4();
        $this->assign('date',$date);
        $this->display();
        }
    }

//视频列表
    public function vlist(){
        $date=$this->navcate2();
        $this->assign('date',$date);

        $navid=$_POST['navid'];
        if($navid!=null){
            $where.="and nav_id='$navid'";
        }
        $video=M('video');
        $page = I('page')? : 1;
        $count = $video->where("1=1 $where")->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
        $videolist=$video->where("1=1 $where")->order("id desc")->limit($rpage1,$rpage2)->select();
        $this->assign('navid',$navid);
        $this->assign('video',$videolist);
        $this->assign('page',$rpage['page']);
        $this->display();

    }

//视频编辑
    public function vedit(){
        if(I('post.')){
            $id=I('post.id');
            $date=I('post.');
            $result=M('video')->where("id='$id'")->save($date);

            if($result){
            $dat['status']=1;
        }else{
            $dat['status']=0;
        }
        $this->ajaxreturn($dat);

        }else{
        $id=I('get.id');
        $video=M('video')->where("id='$id'")->find();
        $this->assign('video',$video);
        $navid=$video['nav_id'];
        $navname=M('nav')->where("id='$navid'")->getField('name');

            $nav=M('nav')->where("type=0")->order('id asc')->select();
            $str = "<select class='form-control' id='nav_id' name='navid'><option value='{$video['nav_id']}'>{$navname}</option><option value=''>请选择</option>";
            foreach ($nav as $v) {
            $str .= "<option value='{$v['id']}'>{$v['name']}</option>" . $this->getsub($v['id']);
            
                }
            $str .= '</select>';

        $this->assign('date',$str);
        $this->display();
        }

    }

//视频删除
    public function vdelete(){
        $id=I('get.id');
        $result=M('video')->where("id='$id'")->delete();
        if($result){
            $dat['status']=1;
        }else{
            $dat['status']=0;
        }
        $this->ajaxreturn($dat);
    }





//上传图片处理
    public function upload() {
        if ($_FILES['upload']['error'] === 0) {
            $upload = new \Think\Upload();
            $upload->maxSize = 31457280;
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
            $upload->savePath = './ads/';
            $upload->saveName = array('uniqid', '');
            $info = $upload->upload();
            if (!$info) {
                $this->error($upload->getError());
            } else {
                foreach ($info as $file) {
                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];
              
                }

                echo json_encode(array('info' => 1, 'path' => $path));
            }
        } else {
            $this->error('上传失败');
        }
    }


}