<?php

namespace Admin\Controller;

use Think\Controller;

class GoodsController extends PublicController {
	
	//商品添加页面
	public function addgoods(){
		//查询商品的类型
		$cate=M('goods_cate')->order('cat_sort')->select();
		$this->assign('cate',$cate);
		//查询商品系列
		$enum=M('sys_enum')->order('id asc')->where("egroup = '1'")->select();
		$this->assign('enum',$enum);
		//查询商品品牌
		$brand=M('brand')->select();
		$this->assign('brand',$brand);
		if(I('post.')){
			$goods = M('goods');
			 $_POST['add_time']=time();
             $data = $_POST;
                $result = $goods->add($data);
                if ($result > 0) {
                    $stats['info'] = 1;
					$stats['id']=$result;
                } else {
                    $stats['info'] = 0;
                } 
				
               $this->ajaxReturn($stats);
        } else {
			

				$this->display();
		
	}
	
	}
	
//添加商品图集
	
	public function goodsimg(){
		if (empty($_FILES['fileList'])) {
            $id = $_GET['id'];
			$type=I('get.type');
			$this->assign('type',$type);
            session('gid', $id);
            $img = M('goods_img')->where("goods_id='$id'")->order('img_id desc')->select();
            $this->assign('img', $img);
            $this->display();
        } else {

            $upload = new \Think\Upload(); // 实例化上传类
            $upload->maxSize = 3145728; // 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg'); // 设置附件上传类型
            $upload->rootPath = './Uploads/'; // 设置附件上传根目录
            $upload->savePath = 'images/'; // 设置附件上传（子）目录
            $upload->saveName = array('uniqid', time() . '_' . mt_rand());
            // 上传文件 
            $info = $upload->upload();

            if (!$info) {// 上传错误提示错误信息
                $this->ajaxReturn($upload->getError());
            } else {// 上传成功入库
                foreach ($info as $file) {

                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];

                    $date['goods_id'] = $_SESSION['gid'];
                    $date['img_url'] = $path;
                    $result = M('goods_img')->add($date);
                   
                }

            }
        }
	}
	
//编辑商品图集
	//添加商品图集
	
	public function goodsupimg(){
		if (empty($_FILES['fileList'])) {
            $id = $_GET['id'];
            session('gid', $id);
            $img = M('goods_img')->where("goods_id='$id'")->order('img_id desc')->select();
            $this->assign('img', $img);
            $this->display();
        } else {

            $upload = new \Think\Upload(); // 实例化上传类
            $upload->maxSize = 3145728; // 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg'); // 设置附件上传类型
            $upload->rootPath = './Uploads/'; // 设置附件上传根目录
            $upload->savePath = 'images/'; // 设置附件上传（子）目录
            $upload->saveName = array('uniqid', time() . '_' . mt_rand());
            // 上传文件 
            $info = $upload->upload();

            if (!$info) {// 上传错误提示错误信息
                $this->ajaxReturn($upload->getError());
            } else {// 上传成功入库
                foreach ($info as $file) {

                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];

                    $date['goods_id'] = $_SESSION['gid'];
                    $date['img_url'] = $path;
                    $result = M('goods_img')->add($date);
                   
                }

            }
        }
	}
	
	
//对单个图片进行修改
     public function updateimg() {
        
        $id = $_POST['id'];
        $result = M('goods_img')->where("img_id='$id'")->setField('sort', $_POST['sort']);
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }

        echo json_encode($data);
    }

    //商品图集删除
    public function deleteimg() {
        $id = $_POST['id'];
        $imgpath = M('goods_img')->where("img_id='$id'")->find();
        $field = "./Uploads/" . $imgpath['path'];
        $gid=$imgpath['id'];
        unlink($field);
        $result = M('goods_img')->where("img_id='$id'")->delete();
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }

        echo json_encode($data);
    }

    //删除商品所有图集
       //删除商品所有图集
    public function delete_all_img() {
        $id = explode('-', substr(trim($_POST['id']), 0, -1));
        $num = count($id);
        $sub = array();
        for ($i = 0; $i < $num; $i++) {
            $sys = M('goods_img');
            $sys->delete($id[$i]);
           
        }
        echo json_encode(array('info' => 1));
    }
	
//商品列表
	public function glist(){
			$page = I('page')? : 1;
            $count = M("goods")->where("g_type = '1'")->count();
            $rpage = Page($count, 8, $page);
            $rpage1 = $rpage['page_l'];
            $rpage2 = $rpage['page_r'];
            $goodlist = M('goods')->limit("$rpage1,$rpage2")->where("g_type = '1'")->order('goods_id desc')->select();
            $this->assign('goods', $goodlist);
            $this->assign('page', $rpage['page']);
            /* 遍历商品列表结束 */
            $this->display();
	}
	
//礼包列表
	public function glblist(){
			$page = I('page')? : 1;
            $count = M("goods")->where("g_type<>1")->count();
            $rpage = Page($count, 8, $page);
            $rpage1 = $rpage['page_l'];
            $rpage2 = $rpage['page_r'];
            $goodlist = M('goods')->limit("$rpage1,$rpage2")->where("g_type<>1")->order('goods_id desc')->select();
            $this->assign('goods', $goodlist);
            $this->assign('page', $rpage['page']);
            /* 遍历商品列表结束 */
            $this->display();
	}
	
	
//商品批量上架
    public function all_on_sale() {
        $id = explode('-', substr(trim($_POST['id']), 0, -1));
        // var_dump($id);exit;
        $num = count($id);
        $sub = array();
        for ($i = 0; $i < $num; $i++) {
            $result = M('goods')->where("goods_id='$id[$i]'")->setField("is_on_sale", 1);
        }
        echo json_encode(array('info' => 1));
    }

    //商品批量下架
    public function all_down_sale() {
        $id = explode('-', substr(trim($_POST['id']), 0, -1));
        // var_dump($id);exit;
        $num = count($id);
        $sub = array();
        for ($i = 0; $i < $num; $i++) {
            $data['is_on_sale'] = 0;
            $result = M('goods')->where("goods_id='$id[$i]'")->setField($data);
        }

        echo json_encode(array('info' => 1));
    }
	
	//编辑商品
	public function upgoods(){
		if(I('post.')){
			$id=I('post.goods_id');
            $goods=$_POST;
            $result = M('goods')->where("goods_id='$id'")->save($goods);
            if ($result) {
                $stat['info'] = 1;
            } else {
                $stat['info'] = 0;
            }
            $this->ajaxReturn($stat);
		}else{
			
		
		$id=I('get.id');
		$goods=M('goods')->where("goods_id='$id'")->find();
		$this->assign('goods',$goods);
		
		//查询商品的类型
		$cate=M('goods_cate')->order('cat_sort')->select();
		$this->assign('cate',$cate);
		//查询商品系列
		$enum=M('sys_enum')->order('id asc')->where("egroup = '1'")->select();
		$this->assign('enum',$enum);
		//查询商品品牌
		$brand=M('brand')->select();
		$this->assign('brand',$brand);
		$this->assign('id',$id);
		$this->display();
		}
	}
	
	 //删除对应的商品
    public function delete() {
        $id = I('post.id');
        $result = M('goods')->where("goods_id='$id'")->delete();
        if ($result) {
                $stat['status'] = 1;
            } else {
                $stat['status'] = 0;
            }
        $this->ajaxReturn($stat);
    }

	//删除对应的商品
    public function catelist() {
        $art_cate = M("goods_cate");
        $data = $art_cate->order("cat_id desc")->select();
        $expland = array();
        foreach ($data as $k => $v) {
            $data[$k]['s_t'] = $v['cat_sort'];
            //查找顶级分类
            if (empty($v['parent_id'])) {
                $expland[$k] = $v['cat_id'];
                $data[$k]['is_p'] = 1;
            } else {
                $data[$k]['is_p'] = 0;
            }
        }
        $data = json_encode($data);
        //var_dump($data);
        $expland = json_encode($expland);
        $this->assign('data', $data);
        $this->assign('ids', $expland);
        $this->display();
    }
	
	public function addcate() {
		$type=M("goods_cate")->select();
		$this->assign('type',$type); 
        $this->display();
    }
	
	
	public function cateadd() {
        //quanx("article");
        $art_cate = M("article_cat");
        $result = $art_cate->add($_POST);
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);

    }

    public function editcate() {
        //quanx("article");
        $art_cate = M("goods_cate");
        $id = $_POST['id'];
        $art_cate->cat_id = $id;
        $art_cate->cat_name = $_POST['name'];
        $art_cate->cat_sort = $_POST['sort'];
        $result = $art_cate->save();
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }
        echo json_encode($data);
    }
	
	public function cate_del(){
		$id=I('get.cat_id');
		$result=M('Goods_cate')->where("cat_id = '$id'")->delete();
		if($result){
			$data['status'] = 1;
		}else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);
	}
	
	public function goods_comm(){
		$id=I('get.id');
		$page = I('page')? : 1;
            $count =M('goods_comment')->where("goods_id='$id'")->count();
            $rpage = Page($count, 10, $page);
            $rpage1 = $rpage['page_l'];
            $rpage2 = $rpage['page_r'];
            $result =M('goods_comment')->where("goods_id='$id'")->limit("$rpage1,$rpage2")->order('comment_time desc')->select();
		foreach($result as &$val){
			$user_id=$val['user_id'];
			$val['user_name']=M('user_info')->where("user_id='$user_id'")->getfield('user_name');
			switch ($val['star']) {
				case '1':$val['ping']='不满意';break;
				case '2':$val['ping']='一般';break;
				case '3':$val['ping']='一般';break;
				case '4':$val['ping']='满意';break;
				case '5':$val['ping']='非常满意';break;
				default:$result['ping']='好评';break;
			}
			
		}
		$this->assign('page', $rpage['page']);
		$this->assign('result',$result); 
        $this->display();
	}
	
	public function commentdel(){
		$id=I('post.id');
		$result=M('goods_comment')->where("comment_id = '$id'")->delete();
		if($result){
			$data['status'] = 1;
		}else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);
	}
	
	public function commentsh(){
		$id=I('post.id');
		$result=M('goods_comment')->where("comment_id = '$id'")->setfield('is_deal',2);
		if($result){
			$data['status'] = 1;
		}else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);
	}
	
	public function goods_record(){
		$page = I('page')? : 1;
            $count = M('kc_change')->count();
            $rpage = Page($count, 10, $page);
            $rpage1 = $rpage['page_l'];
            $rpage2 = $rpage['page_r'];
            $result = M('kc_change')->limit("$rpage1,$rpage2")->order('id desc')->select();
			foreach($result as &$val){
				/* $uid=$val['user_id'];
				$val['user_name']=M('') */
				$goods_id=$val['sp_id'];
				$val['goods_name']=M('goods')->where("goods_id='$goods_id'")->getfield('goods_name');
				$startnum=$val['startnum'];
				$endnum=$val['endnum'];
				if($startnum>$endnum){
					$val['kcchange']=$startnum-$endnum;
				}else{
					$val['kcchange']=$endnum-$startnum;
				}
			}
            $this->assign('page', $rpage['page']);
			$this->assign('result',$result); 
			$this->display();
	}
	
	 //上传图片处理
    public function upload() {
        if ($_FILES['upload']['error'] === 0) {
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
            $upload->savePath = './goods/';
            $upload->saveName = array('uniqid', '');
            $info = $upload->upload();
            if (!$info) {
                $this->error($upload->getError());
            } else {
                foreach ($info as $file) {
                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];
                }

                echo json_encode(array('info' => 1, 'path' => $path));
            }
        } else {
            $this->error('上传失败');
        }
    }
	
	
}