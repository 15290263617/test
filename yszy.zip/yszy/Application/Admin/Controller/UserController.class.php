<?php

namespace Admin\Controller;

use Think\Controller;

class UserController extends PublicController {
	
	public function index(){
		$page = I('page')? : 1;
		$count=M('user')->count();
		$rpage = Page($count, 10, $page);
		$rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
		$search=I('get.search');
		if($search==""){
			$user=M('user')->limit($rpage1,$rpage2)->order('user_id desc')->select();
		}else{
			$user=M('user')->limit($rpage1,$rpage2)->order('user_id desc')->where('phone ='.$search)->select();
		}
		foreach ($user as &$val) {
			$uid=$val['user_id'];
			$res=M('user_info')->where("user_id = '$uid'")->find();
			$val['user_number']=$res['user_number'];
			$val['weixin']=$res['weixin'];
			$val['user_name']=$res['user_name'];
			$val['addtime']=$res['addtime'];
			$val['type']=$res['type'];
			$val['nick_name']=$res['nick_name'];
			$val['logintime']=$res['logintime'];
			$tjid=$res['recommend_id'];
			$val['tjname']=M('user_info')->where("user_id='$tjid'")->getField('nick_name');
			switch ($res['sex']) {
				case '1':$val['sex']='男';break;
				case '2':$val['sex']='女';break;
				default:$val['sex']='未知';break;
			}
			switch ($res['user_status']) {
				case '1':$val['user_status']='正常';break;
				case '2':$val['user_status']='封停';break;
				default:$val['user_status']='封停';break;
			}
			
			switch ($res['type']) {
				case '1':$val['type']='普通用户';break;
				case '2':$val['type']='vip用户';break;
				case '3':$val['type']='A型创业天使';break;
				default:$val['type']='B型创业天使';break;
			}
		}
		//dump($user);
		$this->assign('search',$search);
		$this->assign('user',$user);
		$this->assign('link',$rpage['page']);
		$this->display ();
	}
	
	/* 会员的操作 2删除 3停封 4启用 */
	public function userexe(){
		$id=I('get.id');
		$type=I('get.type');
		switch ($type) {
			case '2':
				M('user')->where("user_id = '$id'")->delete();
				M('user_info')->where("user_id = '$id'")->delete();
				$this->redirect('index');
				break;
			case '3':
				$data['user_status']=2;
				M('user_info')->where("user_id='$id'")->save($data);
                $this->redirect('index');
				break;
			case '4':
				$data['user_status']=1;
				M('user_info')->where("user_id='$id'")->save($data);
                $this->redirect('index');
				break;
			case '5':
				$data['type']=0;
				M('user')->where("user_id='$id'")->save($data);
				$this->redirect('index');
				break;
			case '6':
				$data['type']=1;
				M('user')->where("user_id='$id'")->save($data);
                $this->redirect('index');
				break;
			case '7':
				$data['tuijian']=0;
				M('user')->where("user_id='$id'")->save($data);
                $this->redirect('index');
				break;
			case '8':
				$data['tuijian']=1;
				M('user')->where("user_id='$id'")->save($data);
                $this->redirect('index');
				break;
			default:
				# code...
				break;
		}
	}
	
	public function search(){
		$username=I('get.username');
		$user=M('user')->where("username = '$username'")->select();
		foreach ($user as &$val) {
			$uid=$val['id'];
			$res=M('base_user')->where("uid = '$uid'")->find();
			$val['name']=$res['name'];
			switch ($val['status']) {
				case '0':$val['status']='正常';break;
				default:$val['status']='封停';break;
			}
		}
		$this->assign('user',$user);
		$this->display ();
	}
	
	//积分设置
	public function scores(){
		if(I('post.action')=='save'){
			$add_integral=I('post.add_integral');
			$add_grade=I('post.add_grade');
			if(!empty($add_integral) && !empty($add_grade)){
				$data['integral']=$add_integral;
				$data['grade']=$add_grade;
				$result=M('scores')->add($data);
				if($result){
					$this->redirect('User/scores');
				}
			}
			foreach($_POST as $k => $v){
				if(preg_match("#-#", $k)){
					$id=preg_replace("#[^0-9]#", "", $k);
					$fildes = preg_replace("#[^a-z]#", "", $k);
					$sql=$fildes."='".$v."'";
					//dump("update lx_scores set ".$dat." where id='{$id}'");exit;
					$Model = new \Think\Model();
					$res=$Model->execute("update lx_scores set ".$sql." where id='{$id}'");
				}else if(preg_match("#,#",$k)){
					$id=preg_replace("#[^0-9]#", "", $k);
					$res1=M('scores')->where("id = '$id'")->delete();
				}
			}
		}
			$scores=M('scores')->order('id asc')->select();
			$this->assign('scores',$scores);
			$this->display();
	}
	
	public function tx_record(){
		$page = I('page')? : 1;
		$count=M('tx_record')->count();
		$rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
		$result=M('tx_record')->order('id desc')->limit($rpage1,$rpage2)->select();
		$this->assign('result',$result);
		$this->assign('link',$rpage['page']);
		$this->display();
	}
	
	public function cz_record(){
		$page = I('page')? : 1;
        $count =M('cz_record')->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
		$result=M('cz_record')->order('id desc')->limit($rpage1,$rpage2)->select();
		
		foreach ($result as &$val) {
			$cz_type=$val['cz_type'];
			switch ($cz_type) {
				case '1':$val['cz_type']='微信支付';break;
				case '2':$val['cz_type']='支付宝支付';break;
				case '3':$val['cz_type']='网页支付';break;
				default:$val['cz_type']='网页支付';break;
			}
			$status=$val['status'];
			if($status==1){
				$val['status']="失败";
			}else{
				$val['status']="成功";
			}
			
		}
		$this->assign('result',$result);
		$this->assign('link',$rpage['page']);
		$this->display();
	}
	
	//受理提现申请
	public function tx_deal(){
		$id=I("id");
		$result=M("tx_record")->where("id='$id'")->setField('status',2);
		if($result){
			$msg['status']=1;
		}else{
			$msg['status']=0;
		}
		$this->ajaxReturn($msg);
	}
	
	//删除会员的提现记录
	public function cz_del(){
		$id=I("id");
		$result=M("cz_record")->where("id='$id'")->delete();
		if($result){
			$msg['status']=1;
		}else{
			$msg['status']=0;
		}
		$this->ajaxReturn($msg);
	}
	
	//删除会员的提现记录
	public function tx_del(){
		$id=I("id");
		$result=M("tx_record")->where("id='$id'")->delete();
		if($result){
			$msg['status']=1;
		}else{
			$msg['status']=0;
		}
		$this->ajaxReturn($msg);
	}
	
	
	
}