<?php
namespace Admin\Controller;
use Think\Controller;
class GroupController extends PublicController {
	//团队介绍内容列表
	 public function index(){
		$type=I('post.type');
		if($type!=null){
			$where="nav_id = '$type'";
		}
		$art=M('gart');
		$page = I('page')? : 1;
        $count = $art->where("$where")->count();
        $rpage = Page($count, 15, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
    	$article=$art->where("$where")->order("id desc")->limit($rpage1,$rpage2)->select();
		$nav=M("nav")->where("pid = '5'")->select();
		$this->assign('nav',$nav);
		$this->assign('article',$article);
		$this->assign('page',$rpage['page']);
		$this->assign('type',$type);
		$this->display();
    }
	//团队介绍添加
	public function add(){
		$type=M("nav")->where("pid = '5'")->select();
		$this->assign('type',$type);
		$this->display();
	}
	
	public function add_art(){
		$data=$_POST;
		$data['ptime']=time();
		$result=M('gart')->add($data);
    	if($result){
    		$return['status']=1;
    	}else{
    		$return['status']=0;
    	}
    	$this->ajaxreturn($return);
	}

//修改内容
	public function edit(){
		$id=I('get.id');
    	$article=M('gart')->where("id='$id'")->find();
		$type=M("nav")->where("pid = '5'")->select();
		$this->assign('type',$type);
    	$this->assign('art',$article);
    	$this->display();
	}
//修改的方法
	public function upart(){
		$aid=I('post.id');
    	$data=$_POST;
    	$result=M('gart')->where("id='$aid'")->save($data);
    	if($result){
    		$return['status']=1;
    	}else{
    		$return['status']=0;
    	}
    	$this->ajaxreturn($return);
	}

//删除内容
	public function del(){
		$id=I('post.id');
    	$result=M('gart')->where("id='$id'")->delete();
    	if($result){
    		$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);
	}
	
	
}