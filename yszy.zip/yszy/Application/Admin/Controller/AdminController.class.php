<?php

namespace Admin\Controller;

use Think\Controller;

class AdminController extends PublicController {

	public function index(){
		$page = I('page')? : 1;
        $count = M("admin")->order("id desc")->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
        $user = M('admin')->order("id asc")->limit("$rpage1,$rpage2")->select();
        $this->assign('data', $user);
        $this->assign('page', $rpage['page']);
        $this->display();
	}

	public function add(){
		$name = trim(I("post.name"));
		$password = trim(I("post.password"));
		$map['name'] = $name;
		$map['password'] = md5($password);
		$map['status'] = 0;
		$map['jointime']=time();
		$result = M("admin")->add($map);
		if ($result) {
			echo json_encode(array('status' => 1));
		} else {
			echo json_encode(array('status' => 0));
		}
	}

	public function delete(){
		$id=I('get.id');
		$result=M("admin")->where("id='$id'")->delete();
		if($result){
			$this->redirect('Admin/index');
		}else{
			$this->error('删除失败');
		}

	}




	
}