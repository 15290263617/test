<?php
namespace Admin\Controller;
use Think\Controller;
class ArticleController extends PublicController {
	
    public function index(){
		$type=I('post.type');
		if($type!=null){
			$where="cat_id='$type'";
		}
		$art=M('article');
		$page = I('page')? : 1;
        $count = $art->where("$where")->count();
		//$count = $art->count();
        $rpage = Page($count, 10, $page);
        $rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
    	$article=$art->where("$where")->limit($rpage1,$rpage2)->select();
		//$article=$art->limit($rpage1,$rpage2)->select();
		//$nav=M("nav")->where("pid = '4'")->select();
		//$this->assign('nav',$nav);
		$type=M("article_cat")->select();
		$this->assign('type',$type); 
		$this->assign('article',$article);
		$this->assign('page',$rpage['page']);
		//$this->assign('type',$type);
		$this->display();
    }
	
	public function add(){
		$type=M("article_cat")->select();
		$this->assign('type',$type); 
		$this->display();
	}
	public function add_art(){
		$data=$_POST;
		$data['addtime']=time();
		$result=M('article')->add($data);
    	if($result){
    		$return['status']=1;
    	}else{
    		$return['status']=0;
    	}
    	$this->ajaxreturn($return);
	}
	
	//修改文章
	public function edit(){
		$id=I('get.id');
    	$article=M('article')->where("article_id='$id'")->find();
		//$type=M("nav")->where("pid = '4'")->select();
		//$this->assign('type',$type);
    	$this->assign('article',$article);
    	$this->display();
	}
	
	public function mod(){
		$aid=I('post.article_id');
    	$data=$_POST;
    	$result=M('article')->where("article_id='$aid'")->save($data);
    	if($result){
    		$return['status']=1;
    	}else{
    		$return['status']=0;
    	}
    	$this->ajaxreturn($return);
	}
	
	//文章删除
    public function del(){
    	$id=I('post.id');
    	$result=M('article')->where("article_id='$id'")->delete();
    	if($result){
    		$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);
    }
	
	public function cate() {
        $art_cate = M("article_cat");
        $data = $art_cate->order("cat_id desc")->select();
        $expland = array();
        foreach ($data as $k => $v) {
            $data[$k]['s_t'] = $v['sort'];
            //查找顶级分类
            if (empty($v['parent_id'])) {
                $expland[$k] = $v['cat_id'];
                $data[$k]['is_p'] = 1;
            } else {
                $data[$k]['is_p'] = 0;
            }
        }
        $data = json_encode($data);
        //var_dump($data);
        $expland = json_encode($expland);
        $this->assign('data', $data);
        $this->assign('ids', $expland);
        $this->display();
    }
	
	public function addcate() {
		$type=M("article_cat")->where("parent_id=0")->select();
		$this->assign('type',$type); 
        $this->display();
    }
	
	
	public function cateadd() {
        //quanx("article");
        $art_cate = M("article_cat");
        $result = $art_cate->add($_POST);
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);

    }

    public function editcate() {
        //quanx("article");
        $art_cate = M("article_cat");
        $id = $_POST['id'];
        $art_cate->cat_id = $id;
        $art_cate->cat_name = $_POST['name'];
        $art_cate->sort = $_POST['sort'];
        $result = $art_cate->save();
        if ($result) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }
        echo json_encode($data);
    }
	
	public function cate_del(){
		$id=I('get.cat_id');
		$result=M('article_cat')->where("cat_id = '$id'")->delete();
		if($result){
			$data['status'] = 1;
		}else {
            $data['status'] = 0;
        }
        $this->ajaxreturn($data);
	}
	
	//取消本周推荐
	public function nh(){
		$id=I('post.id');
		$result=M('article')->where("id = '$id'")->setField('hot',0);
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxreturn($return);
	}
	
	//设置本周推荐
	public function h(){
		$id=I('post.id');
		$num=M('article')->where("hot = '1'")->count();
		if($num<4){
			$result=M('article')->where("id = '$id'")->setField('hot',1);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
		}else{
			$return['status']=2;
		}
		
		$this->ajaxreturn($return);
	}
	
	//取消优秀推荐
	public function nt(){
		$id=I('post.id');
		$result=M('article')->where("id = '$id'")->setField('top',0);
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxreturn($return);
	}
	
	//设置优秀推荐
	public function t(){
		$id=I('post.id');
		$result=M('article')->where("id = '$id'")->setField('top',1);
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxreturn($return);
	}
	
	//上传图片处理
    public function upload() {
        if ($_FILES['upload']['error'] === 0) {
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
            $upload->savePath = './article/';
            $upload->saveName = array('uniqid', '');
            $info = $upload->upload();
            if (!$info) {
                $this->error($upload->getError());
            } else {
                foreach ($info as $file) {
                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];
                }
                echo json_encode(array('info' => 1, 'path' => $path));
            }
        } else {
            $this->error('上传失败');
        }
    }
	
}