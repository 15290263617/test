<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Author:��С��
 * Copyright����������Ƽ�
 */

namespace Admin\Controller;

use Think\Controller;
use Think\DBManage;
use Think\Model;

class DbController extends PublicController {

    public function index() {
        $sql_data = M("sql_log")->order("create_time desc")->select();

        foreach ($sql_data as $k => $v) {
            $sql_data[$k]['create_time'] = date("Y-m-d H:i:s", $v['create_time']);
        }
        $this->assign("sql_data", $sql_data);
        $this->display();
    }

    public function backup() {
        //��������
        header("Content-type:text/html; charset=utf-8");
        if(I("get.type")==1){
            $id=I("get.id");
            $sql_title=M("sql_log")->where("id=$id")->getField("sql_title");
            $file=APP_PATH . "../Uploads/sql/".$sql_title;
            $this->download($file);
            return ;
        }
        if(I("get.type")==2){
            $id=I("get.id");
            $sql_title=M("sql_log")->where("id=$id")->getField("sql_title");
            $file=APP_PATH . "../Uploads/sql/".$sql_title;
            unlink($file);
            M("sql_log")->where("id=$id")->delete();
            $this->redirect("index");
        }
        $table_name = $_GET['table_name'];
        $db = new DBManage('localhost', 'root', 'root', 'lx_yszy', 'utf8');
        $filename = $db->backup($table_name, APP_PATH . "../Uploads/sql/");
        //var_dump( $filename);
        // $this->download($filename);
        //�������ݿ������־��
        $index = strrpos($filename, "/");
        $map['sql_title'] = substr($filename, $index + 1);
        $size = $this->FileSizeConvert(filesize($filename));
        $map['size'] = $size;
        $map['admin_id'] = session("adminid");
        $map['create_time'] = time();
        $result = M("sql_log")->add($map);
        if ($result) {
            $this->redirect("index");
        }
    }

    public function FileSizeConvert($bytes) {
        $bytes = floatval($bytes);
        $arBytes = array(
            0 => array(
                "UNIT" => "TB",
                "VALUE" => pow(1024, 4)
            ),
            1 => array(
                "UNIT" => "GB",
                "VALUE" => pow(1024, 3)
            ),
            2 => array(
                "UNIT" => "MB",
                "VALUE" => pow(1024, 2)
            ),
            3 => array(
                "UNIT" => "KB",
                "VALUE" => 1024
            ),
            4 => array(
                "UNIT" => "B",
                "VALUE" => 1
            ),
        );

        foreach ($arBytes as $arItem) {
            if ($bytes >= $arItem["VALUE"]) {
                $result = $bytes / $arItem["VALUE"];
                $result = str_replace(".", ",", strval(round($result, 2))) . " " . $arItem["UNIT"];
                break;
            }
        }
        return $result;
    }

    //�����ϴ�
    public function upload() {
        if ($_FILES['upload']['error'] === 0) {
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->exts = array('sql');
            $upload->savePath = './sql/';
            $upload->saveName = array('uniqid', '');
            $info = $upload->upload();
            if (!$info) {
                $this->error($upload->getError());
            } else {
                foreach ($info as $file) {
                    $imgpath = $file['savepath'];
                    $imgname = $file['savename'];
                    $path = $file['savepath'] . $file['savename'];
                }
                //$_POST['ad_code'] = $path;
                echo json_encode(array('info' => 1, 'path' => $path));
            }
        } else {
            $this->error('�ϴ�ʧ��');
        }
    }

    public function restore() {
        $id=I("post.id");
        $sql_name=M("sql_log")->where("id=$id")->getField("sql_title");
        $db = new DBManage('localhost', 'root', 'root', 'lx_yszy', 'utf8');
        $msg = $db->restore(APP_PATH . "../Uploads/sql/" . $sql_name);
        echo json_encode(array('msg' => $msg));
    }

    function download($file, $name = '') {
        $fileName = $name ? $name : pathinfo($file, PATHINFO_FILENAME);
        $filePath = realpath($file);

        $fp = fopen($filePath, 'rb');

        if (!$filePath || !$fp) {
            header('HTTP/1.1 404 Not Found');
            echo "Error: 404 Not Found.(server file path error)<!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding -->";
            exit;
        }

        $fileName = $fileName . '.' . pathinfo($filePath, PATHINFO_EXTENSION);
        $encoded_filename = urlencode($fileName);
        $encoded_filename = str_replace("+", "%20", $encoded_filename);

        header('HTTP/1.1 200 OK');
        header("Pragma: public");
        header("Expires: 0");
        header("Content-type: application/octet-stream");
        header("Content-Length: " . filesize($filePath));
        header("Accept-Ranges: bytes");
        header("Accept-Length: " . filesize($filePath));

        $ua = $_SERVER["HTTP_USER_AGENT"];
        if (preg_match("/MSIE/", $ua)) {
            header('Content-Disposition: attachment; filename="' . $encoded_filename . '"');
        } else if (preg_match("/Firefox/", $ua)) {
            header('Content-Disposition: attachment; filename*="utf8\'\'' . $fileName . '"');
        } else {
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
        }
        // ob_end_clean(); <--��Щ���������Ҫ���ô˺���
        // ����ļ�����
        fpassthru($fp);
        exit;
    }

}
