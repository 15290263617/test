<?php

namespace Admin\Controller;

use Think\Controller;

class OrderController extends PublicController {
	
	public function index(){
		$orderstatus=I('post.type');
		//dump($orderstatus);
		if($orderstatus){
			$where['order_status']=$orderstatus;
		}
		$page = I('page')? : 1;
		$count=M('order_info')->where($where)->count();
		$rpage = Page($count, 10, $page);
		$rpage1 = $rpage['page_l'];
        $rpage2 = $rpage['page_r'];
		$order_info=M('order_info')->limit($rpage1,$rpage2)->where($where)->select();
		foreach ($order_info as &$val) {
			switch ($val['order_status']) {
				case '1':$val['order_status']='提交未支付';break;
				case '2':$val['order_status']='待发货';break;
				case '3':$val['order_status']='待确认收货';break;
				case '4':$val['order_status']='待评价';break;
				case '5':$val['order_status']='交易成功';break;
				default:$val['order_status']='已取消';break;
			}
		
		/* $order_type=M('order_info')->select();
		$type=array();
		foreach($order_type as $key=>$v){
			$type[$key]=$v['order_status'];
		}
		foreach ($order_type as &$kval) {
			switch ($kval['order_status']) {
				case '1':$kval['status']='提交未支付';break;
				case '2':$kval['status']='待发货';break;
				case '3':$kval['status']='待确认收货';break;
				case '4':$kval['status']='待评价';break;
				case '5':$kval['status']='交易成功';break;
				default:$kval['status']='已取消';break;
			}
		} */
		
			/* $uid=$val['user_id'];
			$res=M('user_info')->where("user_id = '$uid'")->find();
			$val['user_number']=$res['user_number'];
			$val['weixin']=$res['weixin'];
			$val['user_name']=$res['user_name'];
			$val['addtime']=$res['addtime'];
			$val['type']=$res['type'];
			switch ($res['sex']) {
				case '1':$val['sex']='男';break;
				case '2':$val['sex']='女';break;
				default:$val['sex']='未知';break;
			}
			switch ($res['user_status']) {
				case '1':$val['user_status']='正常';break;
				default:$val['user_status']='封停';break;
			}
			
			switch ($res['type']) {
				case '1':$val['type']='普通用户';break;
				case '2':$val['type']='vip用户';break;
				case '3':$val['type']='A型创业天使';break;
				default:$val['type']='B型创业天使';break;
			} */
		}
		//dump($user);
		$this->assign('order_info',$order_info);
		$this->assign('orderstatus',$orderstatus);
		$this->assign('link',$rpage['page']);
		$this->display ();
	}
	
	public function Order_del(){
    	$id=I('post.id');
    	$resulta=M('order_info')->where("order_id='$id'")->delete();
		$resultb=M('order_goods')->where("order_id='$id'")->delete();
    	if($resulta && $resultb){
    		$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);
    }
	
	public function Order_info(){
    	$orderid=I('get.order_id');
		$order_info=M('order_info')->where("order_id='$orderid'")->field('order_status,order_id')->find();
		$result=M('order_goods')->where("order_id='$orderid'")->select();
		$this->assign('order_info',$order_info);
		$this->assign('order_goods',$result);
    	$this->display();
    }
	
	public function shipping_order(){
    	$id=I('post.order_id');
    	$result=M('order_info')->where("order_id='$id'")->setfield('order_status',3);
    	if($result){
    		$dat['status']=1;
    	}else{
    		$dat['status']=0;
    	}
    	$this->ajaxreturn($dat);
    }
	
}