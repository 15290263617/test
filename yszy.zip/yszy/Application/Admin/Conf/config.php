<?php
return array(
	//'配置项'=>'配置值'
	'LAYOUT_ON'=>true,
    'LAYOUT_NAME'=>'GUI',
	'TMPL_CACHE_ON' => false,
 'TMPL_CACHE_ON' => false,
   
);