<?php
//权限判断
function quanx($name,$type='1'){
$uid=session('USER')?:'';
if(!$uid){session('HTQX',null);header("location:/user");}
$quanx1= new\Think\Auth();	
$quanx2= $quanx1->check($name,$uid);
switch($type){case 1:return $quanx2?:tiaoc();break;case 2:return $quanx2;break;}}
//跳出规则
function tiaoc(){
    header("location:/Admin/public/error1");
}
//左侧显示隐藏
function qx_amdin($name,$type='1'){
    $uid=session('QX_ADMIN');   
    $quanx1= new\Think\Auth();
    $quanx2= $quanx1->check($name,$uid);
    switch($type){case 1:return $quanx2?:tiaoc();break;case 2:return $quanx2;break;}}

//文章分类
function getype($type){
	if($type==7){
		return '训练';        
	}elseif($type==8){
		return '美食';
	}elseif($type==9){
		return '励志';
	}else{
		return '全部';
	}
}


