<?php
function getuserinfo(){
/* 	$accessToken="9M7IqeiVRXOShriJBYr1uEZxDf9rHdnZr8iiFBfAK811TWMMuMwAdMFZxuYX0r9Aj7fotw8IcNkXs_fC-B1WYIu1yurvvI_CxW7wPhEolJcqyBWCU5qGHUk7fUKLyarpISDfAAAVFQ"; */
	$url="https://api.weixin.qq.com/cgi-bin/user/info?access_token=9M7IqeiVRXOShriJBYr1uEZxDf9rHdnZr8iiFBfAK811TWMMuMwAdMFZxuYX0r9Aj7fotw8IcNkXs_fC-B1WYIu1yurvvI_CxW7wPhEolJcqyBWCU5qGHUk7fUKLyarpISDfAAAVFQ&openid=oMnnYwSqYgu5yd2dNKEA9-W9GTwc
&lang=zh_CN";
	
	// ����һ��cURL��Դ
	$ch  =  curl_init ();

	curl_setopt	( $ch ,  CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/user/info?access_token=9M7IqeiVRXOShriJBYr1uEZxDf9rHdnZr8iiFBfAK811TWMMuMwAdMFZxuYX0r9Aj7fotw8IcNkXs_fC-B1WYIu1yurvvI_CxW7wPhEolJcqyBWCU5qGHUk7fUKLyarpISDfAAAVFQ&openid=oMnnYwSqYgu5yd2dNKEA9-W9GTwc
&lang=zh_CN");
	curl_setopt ( $ch ,  CURLOPT_RETURNTRANSFER  ,  1 );// ����
	
	// ץȡURL���������ݸ������
	 $output=curl_exec ( $ch );

	// �ر�cURL��Դ�������ͷ�ϵͳ��Դ
	curl_close ( $ch );
	
		var_dump($output);

 }