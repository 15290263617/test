<?php
namespace Weixin\Controller;
use Think\Controller;
class IndexController extends Controller {
	
	public function __construct(){
			
	}
	
	public function index(){
		 $signature = $_GET["signature"];//
         $timestamp = $_GET["timestamp"];//
         $nonce 	= $_GET["nonce"];//
		 
		 $echostr	= $_GET['echostr'];//
		 $token 	= 'YSZY';//和微信上写的同步
		 $tmpArr 	= array($token, $timestamp, $nonce);
		 sort($tmpArr);
		 $tmpStr 	= implode( $tmpArr );
		 $tmpStr 	= sha1( $tmpStr );
		if( $tmpStr == $signature && $echostr){
			echo $echostr;
			exit;
		}else{
			$this->reponseMsg();
		}
	}
	
	public function reponseMsg(){
		//1、获取到微信推送过来post数据（xml格式）
		$postArr=$GLOBALS['HTTP_RAW_POST_DATA'];
		//2、处理消息类型，并设置回复类型和内容
		/* <xml>
 <ToUserName><![CDATA[toUser]]></ToUserName>
 <FromUserName><![CDATA[fromUser]]></FromUserName>
 <CreateTime>1348831860</CreateTime>
 <MsgType><![CDATA[event]]></MsgType>
 <Event><![CDATA[subscribe]]></Event>
 <MsgId>1234567890123456</MsgId>
 </xml> */
		$postObj = simplexml_load_string( $postArr );//将xml转换为对象
		//$postObj->ToUserName= '';
		//$postObj->FromUserName= '';
		//$postObj->CreateTime= '';
		//$postObj->MsgType= '';
		//$postObj->Event= '';
		//判断该数据包是否是订阅的事件推送
		if(strtolower($postObj->MsgType)=='event'){
			//如果是关注 subscribe 事件
			if(strtolower($postObj->Event=='subscribe')){
				//回复用户消息
				$toUser=$postObj->FromUserName;
				$fromUser=$postObj->ToUserName;
				$time=time();
				$MsgType='text';
				//$content='欢迎关注豫商纸业的微信公众账号';
				$content='公众账号'.$fromUser.';微信用户的openid'.$toUser;
				$template="<xml>
						   <ToUserName><![CDATA[%s]]></ToUserName>
						   <FromUserName><![CDATA[%s]]></FromUserName>
						   <CreateTime>%s</CreateTime>
						   <MsgType><![CDATA[%s]]></MsgType>
						   <Content><![CDATA[%s]]></Content>
						   </xml>";
				$info=sprintf($template,$toUser,$fromUser,$time,$MsgType,$content);
				echo $info;
			}
		}
	}

	//获取Access_token
	public function getWxAccessToken(){
		$appid = 'wxd203d7682a1e9aa8';
		$appsecret = '59092c33ed0244d411c51f201a9781d8';
		$url="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wxd203d7682a1e9aa8&secret=59092c33ed0244d411c51f201a9781d8";
		$ch = curl_init();
		curl_setopt($ch , CURLOPT_URL , $url);
		curl_setopt($ch , CURLOPT_RETURNTRANSFER , 1);
		$res = curl_exec($ch);
		curl_close($ch);
		if(curl_errno($ch)){
			var_dump(curl_error($ch));
		}
		$arr = json_decode($res,true);
		echo "<pre>";
		var_dump($arr);
		echo "</pre>";
	}



}