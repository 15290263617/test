<?php
namespace Weixin\Controller;
use Think\Controller;

class WeixinController extends Controller
{
	private $wc = null;
	public  $openid = '';
    public  $uid=0;

	function __construct(){
		parent::__construct();
        if(!empty($_SESSION['uid'])){
            $this->uid = $_SESSION['uid'];
        }
		$this->wc = new \Org\Util\WeChat();
	}

    /**
     * @desc 微信接口入口验证
     * @author simayubo
     */
	 public function valid(){
		  $this->wc->wcValid();
    }

    /**
     * @desc 用户授权请求
     * @author simayubo
     */
    public function user_auth(){
		$phone=I('get.phone');
		if($phone){
			$_SESSION['phone']=$phone;
		}
    	$res = $this->wc->wxOauthBase();
    	header("location:".$res);
    }
	
	public function user_authopen(){
    	$res = $this->wc->wxOauthBaseopen();
    	header("location:".$res);
    }
	
	public function user_binda(){
		$code = I('get.code');
		$res = $this->wc->wxOauthAccessToken($code);
		$openid = $res['openid'];
		$resb=M('user_wx')->where("openid='$openid'")->find();
		if($resb){
			$user_id=M('user_info')->where("openid='$openid'")->getfield('user_id');
			if($user_id){
				session('uid',$user_id);
				$dat['logintime']=time();
				M('user_info')->where("user_id='$user_id'")->save($dat);
			}
			$gtype=session('gtype');
			switch ($gtype){
				case 1:
					$this->redirect('Wap/Index/index');
				break;
				case 2:
					$this->redirect('Wap/Angel/index');
				break;
				case 3:
					$this->redirect('Wap/Public/help');
				break;
				default:
					$this->redirect('Wap/Index/index');
				}
		}else{
			$tjid=$_SESSION['tjid'];
			$arr['openid']=$openid;
			$arr['tjid']=$tjid;
			$resa=M('user_wx')->add($arr);
			if($resa){
				$this->redirect('Wap/Index/index');
			}else{
				exit('系统错误');
			}
		}
	}

    /**
     * @desc 用户授权回调地址
     * @author simayubo
     */
    public function user_bind(){
        $code = I('get.code');
        $res = $this->wc->wxOauthAccessToken($code);
        $userinfo = $this->wc->wxOauthUser($res['access_token'], $res['openid']);
		
        $m_user = M('user_info');$b_user=M('user');
        $rows = $m_user->field(array('user_id'))->where(array('openid'=>$userinfo['openid']))->find();
         if (count($rows) > 0) {//用户已绑定，可以直接登录页面
            session('uid', $rows['user_id']);
            // $this->prize_go_num($rows['id']);
			$rtype=session('rtype');//跳转的session
			switch ($rtype)
			{
			case 1:
				$this->redirect('Wap/Public/account');
				break;
			case 2:
				$goods_id=session('goods_id');
				$this->redirect('Wap/Goods/proxq',array('goods_id'=>$goods_id));
				break;
			case 3:
				$this->redirect('Wap/Personal/center');
				break;
			default:
				$this->redirect('Wap/Index/index');
            }
            exit;
         }else{
			$phone=session('phone');
			if($phone){//pc端绑定（更新信息）
			$user=M('user')->where("phone='$phone'")->find();
			$user_id=$user['user_id'];
			$data = array(
				'openid'    =>  $userinfo['openid'],
				'nick_name' =>  $userinfo['nickname'],
				'sex'       =>  $userinfo['sex'],
				'location_c'=>  $userinfo['city']."市",
				'location_p'=>  $userinfo['province']."省",
					//'country' =>  $userinfo['country'],
				'head_img'  =>  $userinfo['headimgurl'],
				'type'   	=>  2,
				'user_id'	=>$user_id
				);
			$openid=$userinfo['openid'];
			$tjid=M('user_wx')->where("openid='$openid'")->getfield('tjid');
			if($tjid){
				$data['recommend_id']=$tjid;
			}
			$jid = M('user_info')->where("user_id='$user_id'")->save($data);
			if($jid>0){
				session('phone',null);
				//弹出一个授权成功的页面
				$this->redirect('Wap/Public/bdcg');
			}else{
				session('phone',null);
				exit('授权失败');
			}	
			}else{//手机端绑定（到绑定页面）
				session('user_info',$userinfo);
				$this->redirect('Wap/Public/bdsjh');
				exit;
			}
			
		 }
    }
	
/* 	 public function user_binda(){
        $code = I('get.code');
        $res = $this->wc->wxOauthAccessToken($code);
		$openid=$res['openid'];
		dump($openid);
		$resa=M('user_info')->where("openid='$openid'")->find();
		if($resa){
			
		}else{
			
		}
	} */
    /**
     * @desc 获取签名
     * @author simayubo
     */
    public function get_signPackage(){
        $signPackage=$this->wc->wxJsapiPackage();
        return $signPackage;
    }

    /**
     * @desc 微信支付
     * @author simayubo
     */
	public function js_api_call() {
//        $order_sn = I('get.order_sn', '');
//        if (empty($order_sn)) {
//            header('location:'.__ROOT__.'/');
//        }
        if($this->uid == 0){
            $this->redirect('Weixin/user_auth');
        }
        vendor('Weixinpay.WxPayPubHelper');
        //使用jsapi接口
        $jsApi = new \JsApi_pub();
        //=========步骤1：网页授权获取用户openid============
        $r = M('User')->field(array('openid'))->where(array('id'=>$this->uid))->find();
        $openid = $r['openid'];
        $res = array(
            'order_sn' => '20150109113322',
            'order_amount' => 255
        );
        //=========步骤2：使用统一支付接口，获取prepay_id============
        //使用统一支付接口
        $unifiedOrder = new \UnifiedOrder_pub();
        //设置统一支付接口参数
        //设置必填参数
        //appid已填,商户无需重复填写
        //mch_id已填,商户无需重复填写
        //noncestr已填,商户无需重复填写
        //spbill_create_ip已填,商户无需重复填写
        //sign已填,商户无需重复填写
        $total_fee = $res['order_amount']*100;
        //$total_fee = 1;
        $body = "订单支付{$res['order_sn']}";
        $unifiedOrder->setParameter("openid", "$openid");//用户标识
        $unifiedOrder->setParameter("body", $body);//商品描述
        //自定义订单号，此处仅作举例
        $out_trade_no = $res['order_sn'];
        $unifiedOrder->setParameter("out_trade_no", $out_trade_no);//商户订单号
        $unifiedOrder->setParameter("total_fee", $total_fee);//总金额
        //$unifiedOrder->setParameter("attach", "order_sn={$res['order_sn']}");//附加数据
        $unifiedOrder->setParameter("notify_url", \WxPayConf_pub::NOTIFY_URL);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        //非必填参数，商户可根据实际情况选填
        //$unifiedOrder->setParameter("sub_mch_id","XXXX");//子商户号
        //$unifiedOrder->setParameter("device_info","XXXX");//设备号
        //$unifiedOrder->setParameter("attach","XXXX");//附加数据
        //$unifiedOrder->setParameter("time_start","XXXX");//交易起始时间
        //$unifiedOrder->setParameter("time_expire","XXXX");//交易结束时间
        //$unifiedOrder->setParameter("goods_tag","XXXX");//商品标记
        //$unifiedOrder->setParameter("openid","XXXX");//用户标识
        //$unifiedOrder->setParameter("product_id","XXXX");//商品ID
        $prepay_id = $unifiedOrder->getPrepayId();
        //=========步骤3：使用jsapi调起支付============
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $wxconf = json_decode($jsApiParameters, true);
        if ($wxconf['package'] == 'prepay_id=') {
            $this->error('当前订单存在异常，不能使用支付');
        }
        $this->assign('res', $res);
        $this->assign('jsApiParameters', $jsApiParameters);
        $this->display('jsapi');
	}
	//异步通知url，商户根据实际开发过程设定
	public function notify_url() {
		vendor('Weixinpay.WxPayPubHelper');
	    //使用通用通知接口
		$notify = new \Notify_pub();
		//存储微信的回调
		$xml = $GLOBALS['HTTP_RAW_POST_DATA'];
		$notify->saveData($xml);
		//验证签名，并回应微信。
		//对后台通知交互时，如果微信收到商户的应答不是成功或超时，微信认为通知失败，
		//微信会通过一定的策略（如30分钟共8次）定期重新发起通知，
		//尽可能提高通知的成功率，但微信不保证通知最终能成功。
		if($notify->checkSign() == FALSE){
			$notify->setReturnParameter("return_code", "FAIL");//返回状态码
			$notify->setReturnParameter("return_msg", "签名失败");//返回信息
		}else{
			$notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
		}
		$returnXml = $notify->returnXml();
		//==商户根据实际情况设置相应的处理流程，此处仅作举例=======
		//以log文件形式记录回调信息
		//$log_name = "notify_url.log";//log文件路径
		//$this->log_result($log_name, "【接收到的notify通知】:\n".$xml."\n");
        $parameter = $notify->xmlToArray($xml);
        //$this->log_result($log_name, "【接收到的notify通知】:\n".$parameter."\n");
		if($notify->checkSign() == TRUE){
			if ($notify->data["return_code"] == "FAIL") {
                //此处应该更新一下订单状态，商户自行增删操作
                //$this->log_result($log_name, "【通信出错】:\n".$xml."\n");
                //更新订单数据【通信出错】设为无效订单
                echo 'error';
			}
			else if($notify->data["result_code"] == "FAIL"){
                //此处应该更新一下订单状态，商户自行增删操作
                //$this->log_result($log_name, "【业务出错】:\n".$xml."\n");
                //更新订单数据【通信出错】设为无效订单
                echo 'error';
			}
			else{
                //$this->log_result($log_name, "【支付成功】:\n".$xml."\n");
                //我这里用到一个process方法，成功返回数据后处理，返回地数据具体可以参考微信的文档
                if ($this->process($parameter)) {
                    //处理成功后输出success，微信就不会再下发请求了
                    echo 'success';
                }else {
                    //没有处理成功，微信会间隔的发送请求
                    echo 'error';
                }
			}
		}
	}
    //订单处理
    private function process($parameter) {
        //此处应该更新一下订单状态，商户自行增删操作
        /*
        * 返回的数据最少有以下几个
        * $parameter = array(
            'out_trade_no' => xxx,//商户订单号
            'total_fee' => XXXX,//支付金额
            'openid' => XXxxx,//付款的用户ID
        );
        */
        return true;
    }

    public function test($keyword='jj'){
    	$r = new \Org\Util\WeChat();

    	p($r->get_click('help'));
    }
}
