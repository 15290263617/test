<?php
namespace Weixin\Controller;
use Think\Controller;
class UserController extends Controller {
	
	public function index(){
		getuserinfo();
	}
	
	
	
}