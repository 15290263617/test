<?php

namespace User\Controller;

use Think\Controller;

class IndexController extends Controller {

    public function index() {
        //session('HTQX',null);
        if (session('HTQX') == 'xdz') {
            header("location:/admin");
        } else {
            if(I("post.")){
                $name=I("post.username");
                $pwd=md5(I("post.passwd"));
                $u_d=M("admin")->where("name='{$name}'")->find();
                if(!$u_d&&$name&&$pwd){//该用户不存在
                    $this->assign('pand',1231);
                }else{
                    $u_d1=M("admin")->where("name='{$name}' and password='{$pwd}'")->find();
                    if(!$u_d1){
                        $this->assign('pand',123);
                    }else{
						M('admin')->where("name='{$name}'")->setField('logtime',time());
                        session('HTQX','xdz');
                        session("adminid",$u_d1['id']);
                        $this->redirect("Admin/Index/index");
                    }
                }
                $this->display();
            }else{
                $this->display();
            }
            
           
        }
    }

//验证码	
    public function verify($code = '') {
        $code = I('code');
        if (!$code) {
            $verify = new \Think\Verify();
            $verify->entry(2);
        } else {
            $verify = new \Think\Verify();
            $verify1 = $verify->check($code, 2);
            $verify2 = $verify1 ? 1 : 2;
            echo $verify2;
        }
    }

    #code..
    //密码修改

    public function edt() {
        $oldpwd=md5(I("post.oldpwd"));
        //获取当前的管理员
        $admin = session("adminid")? : '';
        $a_d=M("Admin")->where("id=$admin and password='$oldpwd'")->find();
        if(!$a_d){
            echo json_encode(array('info'=>1,'msg'=>'输入的原始密码不对'));
            return ;
        }else{
            
            $data['password'] = md5(I("post.newpwd"));
            $User = M("admin");
            $User->where("id=$admin")->save($data);
        }
         echo json_encode(array('info'=>2,'msg'=>'密码修改成功'));
    }

    //退出功能
    public function tc() {
        session_destroy();
        header("location:/user");
    }

}
