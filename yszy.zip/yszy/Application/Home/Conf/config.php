<?php
return array(
	//'配置项'=>'配置值'
	'LAYOUT_ON'=>true,
    'LAYOUT_NAME'=>'public',
    'TMPL_CACHE_ON'=>  false,  
	
	define('WEB_HOST', 'http://www.chuangyepaper.com/'),
	'WxPayConf_pub'=>array(
		'APPID' => 'wxd203d7682a1e9aa8',
		'MCHID' => '1329446701',
		'KEY' => 'lingxiuwangluokejiyouxiangongsi0',
		'APPSECRET' => '59092c33ed0244d411c51f201a9781d8',
		'JS_API_CALL_URL' => WEB_HOST.'/index.php/Home/WxJsAPI/jsApiCall',
		'SSLCERT_PATH' => WEB_HOST.'/ThinkPHP/Library/Vendor/WxPayPubHelper/cacert/apiclient_cert.pem',
		'SSLKEY_PATH' => WEB_HOST.'/ThinkPHP/Library/Vendor/WxPayPubHelper/cacert/apiclient_key.pem',
		'NOTIFY_URL' =>  WEB_HOST.'index.php/Home/Wxpay/notify',
		'NOTIFY_URL1' =>  WEB_HOST.'index.php/Home/Wxcz/notify',
		'CURL_TIMEOUT' => 30,
	),
	
	
	
	
	
);