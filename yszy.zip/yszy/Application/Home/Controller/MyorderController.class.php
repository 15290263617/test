<?php
namespace Home\Controller;

use Think\Controller;

class MyorderController extends PublicController {
	
	public function __construct(){
		parent::__construct();
		
		if($_SESSION['home']['islogin']==''){
			$this->redirect('/Home/Login/login');
		}
	}
	
	//全部订单
    public function index(){
		//dump(session());
		$user_id=$_SESSION['home']['uid'];
		$position="o";
		$this->assign('wei',$position);
		$time=I('get.time');
		switch($time){
			case 1:$starttime=strtotime('-7 days');$endtime=time();break;
			case 2:$starttime=strtotime('-1 month');$endtime=time();break;
			case 3:$starttime=strtotime('-3 month');$endtime=time();break;
			case 4:$starttime=strtotime('-12 month');$endtime=time();break;
		}
		if($time){
			$where['add_time'] = array(array('gt',$starttime),array('lt',$endtime));
			$order=M('order_info')->order('order_id desc')->where("user_id = '$user_id'")->where($where)->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		//dump($order);
		$this->assign('order',$order);
		$this->assign('time',$time);
		$this->display();
	}
	
	//订单取消
	public function quxiao(){
		$order_id=I('post.order_id');
		$result=M('order_info')->where("order_id = '$order_id'")->setField('order_status','99');
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//待付款
	public function payment(){
		$user_id=$_SESSION['home']['uid'];
		$position="p";
		$this->assign('wei',$position);
		$time=I('get.time');
		switch($time){
			case 1:$starttime=strtotime('-7 days');$endtime=time();break;
			case 2:$starttime=strtotime('-1 month');$endtime=time();break;
			case 3:$starttime=strtotime('-3 month');$endtime=time();break;
			case 4:$starttime=strtotime('-12 month');$endtime=time();break;
		}
		if($time){
			$where['add_time'] = array(array('gt',$starttime),array('lt',$endtime));
			$order=M('order_info')->order('order_id desc')->where("order_status = 1 && user_id = '$user_id'")->where($where)->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("order_status = 1 && user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		$this->assign('order',$order);
		$this->assign('time',$time);
		$this->display();
	}
	
	//待发货
	public function shipment(){
		$user_id=$_SESSION['home']['uid'];
		$position="s";
		$this->assign('wei',$position);
		$time=I('get.time');
		switch($time){
			case 1:$starttime=strtotime('-7 days');$endtime=time();break;
			case 2:$starttime=strtotime('-1 month');$endtime=time();break;
			case 3:$starttime=strtotime('-3 month');$endtime=time();break;
			case 4:$starttime=strtotime('-12 month');$endtime=time();break;
		}
		if($time){
			$where['add_time'] = array(array('gt',$starttime),array('lt',$endtime));
			$order=M('order_info')->order('order_id desc')->where("order_status = 2 && user_id = '$user_id'")->where($where)->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("order_status = 2 && user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		$this->assign('order',$order);
		$this->assign('time',$time);
		$this->display();
	}
	
	//待收货
	public function receipt(){
		$user_id=$_SESSION['home']['uid'];
		$position="r";
		$this->assign('wei',$position);
		$time=I('get.time');
		switch($time){
			case 1:$starttime=strtotime('-7 days');$endtime=time();break;
			case 2:$starttime=strtotime('-1 month');$endtime=time();break;
			case 3:$starttime=strtotime('-3 month');$endtime=time();break;
			case 4:$starttime=strtotime('-12 month');$endtime=time();break;
		}
		if($time){
			$where['add_time'] = array(array('gt',$starttime),array('lt',$endtime));
			$order=M('order_info')->order('order_id desc')->where("order_status = 3 && user_id = '$user_id'")->where($where)->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("order_status = 3 && user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		$this->assign('order',$order);
		$this->assign('time',$time);
		$this->display();
	}
	
	//订单收货
	public function shouhuo(){
		$order_id=I('post.order_id');
		$result=M('order_info')->where("order_id = '$order_id'")->setField('order_status','4');
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//待评价,已完成
	public function appraise(){
		$user_id=$_SESSION['home']['uid'];
		$position="e";
		$this->assign('wei',$position);
		$time=I('get.time');
		switch($time){
			case 1:$starttime=strtotime('-7 days');$endtime=time();break;
			case 2:$starttime=strtotime('-1 month');$endtime=time();break;
			case 3:$starttime=strtotime('-3 month');$endtime=time();break;
			case 4:$starttime=strtotime('-12 month');$endtime=time();break;
		}
		if($time){
			$where['add_time'] = array(array('gt',$starttime),array('lt',$endtime));
			$order=M('order_info')->order('order_id desc')->where("order_status = 4 && user_id = '$user_id'")->where($where)->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("order_status = 4 && user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		//dump($order);
		$this->assign('order',$order);
		$this->assign('time',$time);
		$this->display();
	}
	
	//评价
	public function appraise_xq(){
		if(I('post.')){
			if($_FILES['comment_img']['error']==0){
				$upload = new \Think\Upload();
				$upload->maxSize = 3145728;
				$upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
				$upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
				$upload->savePath  =     'home/'.CONTROLLER_NAME.'/'; // 设置附件上传（子）目录
				$upload->saveName  =array('uniqid',time().'_'.mt_rand());
				$info = $upload->upload();
				if($info){
					$data['comment_img']=$info['comment_img']['savepath'].$info['comment_img']['savename'];
					$data['user_id']=$_SESSION['home']['uid'];
					$data['goods_id']=I('post.goods_id');
					$data['comment_content']=I('post.comment_content');
					$data['comment_time']=time();
					$data['star']=(I('post.pj1')+I('post.pj2')+I('post.pj3')+I('post.pj4'))/4;
					$result=M('goods_comment')->add($data);
					if($result){
						$goods_id=I('post.goods_id');
						$order_id=I('post.order_id'); 
						M('order_goods')->where("order_id = '$order_id' && goods_id = '$goods_id'")->setField('p_status','2');
						$this->redirect('Myorder/appraise');
					}
				}
			}
		}else{
			$order_id=I('get.order_id');
			$goods_id=I('get.goods_id');
			$orderinfo=M('order_info')->where("order_id = '$order_id'")->find();
			$goods=M('order_goods')->where("order_id = '$order_id' && goods_id = '$goods_id'")->find();
			$this->assign('orderinfo',$orderinfo);
			$this->assign('goods',$goods);
			$this->display();
		}
	}

	//订单详情
	public function order_xq(){
		$order_id=I('get.order_id');
		$orderinfo=M('order_info')->where("order_id = '$order_id'")->find();
		$res=M('order_goods')->where("order_id = '$order_id'")->select();
		$orderinfo['goods']=$res;
		//dump($orderinfo);
		$this->assign('orderinfo',$orderinfo);
		$this->display();
	}
	
/* 	//完成
	public function complete(){
		$position="c";
		$this->assign('wei',$position);
		$order=M('order_info')->order('order_id desc')->where("order_status = 5")->select();
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		$this->assign('order',$order);
		$this->display();
	} */
	
}