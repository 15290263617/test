<?php
namespace Home\Controller;

use Think\Controller;

class IndexController extends PublicController {
    public function index(){
		//dump(session());
		//$_SESSION['home']['type']=3;
		$position="in";
		$this->assign('wei',$position);
		//分类商品
		$cate=M('goods_cate')->select();
		$goods=array();
		foreach($cate as $k => $v){
			$cat_id=$v['cat_id'];
			$result=M('goods')->where("cat_id = '$cat_id' && is_on_sale = '1' && g_type = '1'")->select();
			$goods[$k]['goods']=$result;
		}
		$this->assign('goods',$goods);
		
		//热销推荐
		$goods_best=M('goods')->where("is_best = '1' && is_on_sale = '1' && g_type = '1'")->select();
		$this->assign('goods_best',$goods_best);
		
		$this->display();
	}
}