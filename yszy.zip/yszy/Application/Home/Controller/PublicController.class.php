<?php
namespace Home\Controller;
use Think\Controller;
class PublicController extends Controller {

	public function _initialize(){
		$uid=$_SESSION['home']['uid'];
		//dump($uid);
		//用户基本信息
		$userinfo=M('user_info')->where("user_id = '$uid'")->find();
		$this->assign('userinfo',$userinfo);
		//导航
		$enum=M('sys_enum')->where("egroup = '1'")->select();
		$this->assign('enum',$enum);
		//dump($enum);
		
		//分类
		$cate=M('goods_cate')->select();
		$this->assign('cate',$cate);
		
		//购物车数量
		$car_num=M('car')->where("user_id = '$uid' && status = '0'")->count();
		$this->assign('car_num',$car_num);
		
		//各订单状态数量
		//待付款
		$payment_num=M('order_info')->where("order_status = '1' && user_id = '$uid'")->count();
		//待发货
		$shipment_num=M('order_info')->where("order_status = '2' && user_id = '$uid'")->count();
		//待收货
		$receipt_num=M('order_info')->where("order_status = '3' && user_id = '$uid'")->count();
		//待评价
		$appraiset_num=M('order_info')->where("order_status = '4' && user_id = '$uid'")->count();
		//已完成
		$complete_num=M('order_info')->where("order_status = '5' && user_id = '$uid'")->count();
		$this->assign('payment_num',$payment_num);
		$this->assign('shipment_num',$shipment_num);
		$this->assign('receipt_num',$receipt_num);
		$this->assign('appraiset_num',$appraiset_num);
		$this->assign('complete_num',$complete_num);
		
		//文章分类
		$article_cat=M('article_cat')->select();
		foreach($article_cat as $k => $v){
			$cat_id=$v['cat_id'];
			$article=M('article')->where("cat_id = '$cat_id'")->select();
			$article_cat[$k]['article']=$article;
		}
		$this->assign('article_cat',$article_cat);
		
		//友情链接
		$friend_link=M('sys_enum')->where("egroup = 10")->select();
		$this->assign('friend_link',$friend_link);
		
		//系统常量
		$logo1=M('sys_enum')->where("id = 4")->getField('evalue');
		$logo2=M('sys_enum')->where("id = 5")->getField('evalue');
		$tel=M('sys_enum')->where("id = 7")->getField('evalue');
		$weixin=M('sys_enum')->where("id = 6")->getField('evalue');
		$copyright=M('sys_enum')->where("id = '14'")->getField('evalue');
		$this->assign('logo1',$logo1);
		$this->assign('logo2',$logo2);
		$this->assign('tel',$tel);
		$this->assign('weixin',$weixin);
		$this->assign('copyright',$copyright);
		
		//主页banner
		$index_banner=M('ads')->order('sort asc')->where("position_id = '0'")->select();
		$this->assign('index_banner',$index_banner);
		
		//主页热销推荐图
		$hot_banner=M('ads')->order('sort asc')->where("position_id = '2'")->find();
		$this->assign('hot_banner',$hot_banner);
		
		//运费
		$yunfei=M('sys_enum')->where("id = '15'")->getField('evalue');
		$this->assign('yunfei',$yunfei);

	}

	//文章
	public function article(){
		$id=I('get.id');
		$article=M('article')->where("article_id = '$id'")->find();
		$this->assign('article',$article);
		$this->assign('id',$id);
		$this->display();
	}

	//联系客户
	public function service(){
		$result=M('sys_enum')->where("egroup = '12'")->select();
		$this->assign('result',$result);
		$this->display();
	}
	
	//绑定手机号
    public function bdsjh(){
			$phone=I('get.phone');
			$this->redirect('Weixin/Weixin/user_auth',array('phone'=>$phone));
	}
	
	//扫码登录
    public function smdl(){
			$this->redirect('Weixin/Weixin/user_autha');
	}

	
	
	
	
	
}