<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Home\Controller;

use Think\Controller;
header("Content-type: text/html; charset=utf-8"); 
/**
 * 微信native方式支付
 * @author Echomod-fst
 */
class WxczController extends Controller {

    /**
     * 初始化
     */
    public function _initialize() {
        //引入WxPayPubHelper
        vendor('WxPayPubHelper.WxPayPubHelper');
    }

	public function typesel() {
        $cz_sn=I('post.cz_sn');
		$type=M('cz_order')->where("cz_sn='$cz_sn'")->getField('status');
		$return['status']=$type;
		$this->ajaxReturn($return);
    }
	
    public function index() {
		//导航
		$enum=M('sys_enum')->where("egroup = '1'")->select();
		$this->assign('enum',$enum);
		
		//购物车数量
		$car_num=M('car')->where("user_id = '$uid' && status = '0'")->count();
		$this->assign('car_num',$car_num);
		
		//友情链接
		$friend_link=M('sys_enum')->where("egroup = 10")->select();
		$this->assign('friend_link',$friend_link);
		
		//系统常量
		$logo1=M('sys_enum')->where("id = 4")->getField('evalue');
		$logo2=M('sys_enum')->where("id = 5")->getField('evalue');
		$tel=M('sys_enum')->where("id = 7")->getField('evalue');
		$weixin=M('sys_enum')->where("id = 6")->getField('evalue');
		$copyright=M('sys_enum')->where("id = '14'")->getField('evalue');
		$this->assign('logo1',$logo1);
		$this->assign('logo2',$logo2);
		$this->assign('tel',$tel);
		$this->assign('weixin',$weixin);
		$this->assign('copyright',$copyright);
		
		//文章分类
		$article_cat=M('article_cat')->select();
		foreach($article_cat as $k => $v){
			$cat_id=$v['cat_id'];
			$article=M('article')->where("cat_id = '$cat_id'")->select();
			$article_cat[$k]['article']=$article;
		}
		$this->assign('article_cat',$article_cat);
		
        //使用统一支付接口
        $unifiedOrder = new \UnifiedOrder_pub();

		//$order_id=I('get.order_id');
		//$orderinfo=M('order_info')->where("order_id = '$order_id'")->find();
		/* $goods=M('order_goods')->where("order_id = '$order_id'")->select();
		foreach($goods as $k => $v){
			$arr[$k]=$v['goods_name'].'*'.$v['goods_number'];
		}
		$data=implode(',',$arr);
		dump($data); */
		//dump($orderinfo);exit;
        //设置统一支付接口参数
        //设置必填参数
        //appid已填,商户无需重复填写
        //mch_id已填,商户无需重复填写
        //noncestr已填,商户无需重复填写
        //spbill_create_ip已填,商户无需重复填写
        //sign已填,商户无需重复填写
        $unifiedOrder->setParameter("body", "豫商纸业商城"); //商品描述
        //自定义订单号，此处仅作举例
        $timeStamp = time();
        $out_trade_no = I('get.cz_sn');
		$res=M('cz_order')->where("cz_sn = '$out_trade_no'")->find();
		//dump($res);return;
		//dump($out_trade_no);return;
        $unifiedOrder->setParameter("out_trade_no", $out_trade_no); //商户订单号 
        $totalfee = $res['money'];
        $unifiedOrder->setParameter("total_fee", $totalfee*100); //总金额
		
		 
        $unifiedOrder->setParameter("notify_url", C('WxPayConf_pub.NOTIFY_URL1')); //通知地址 
        $unifiedOrder->setParameter("trade_type", "NATIVE"); //交易类型
        //非必填参数，商户可根据实际情况选填
        //$unifiedOrder->setParameter("sub_mch_id","XXXX");//子商户号  
        //$unifiedOrder->setParameter("device_info","XXXX");//设备号 
        //$unifiedOrder->setParameter("attach","XXXX");//附加数据 
        //$unifiedOrder->setParameter("time_start","XXXX");//交易起始时间
        //$unifiedOrder->setParameter("time_expire","XXXX");//交易结束时间 
        //$unifiedOrder->setParameter("goods_tag","XXXX");//商品标记 
        //$unifiedOrder->setParameter("openid","XXXX");//用户标识
        //$unifiedOrder->setParameter("product_id","XXXX");//商品ID
        //获取统一支付接口结果
        $unifiedOrderResult = $unifiedOrder->getResult();
        //商户根据实际情况设置相应的处理流程
        if ($unifiedOrderResult["return_code"] == "FAIL") {
		
            //商户自行增加处理流程
            echo "通信出错：" . $unifiedOrderResult['return_msg'] . "<br>";
		
        } elseif ($unifiedOrderResult["result_code"] == "FAIL") {
            //商户自行增加处理流程
            echo "错误代码：" . $unifiedOrderResult['err_code'] . "<br>";
            echo "错误代码描述：" . $unifiedOrderResult['err_code_des'] . "<br>";
        } elseif ($unifiedOrderResult["code_url"] != NULL) {
            //从统一支付接口获取到code_url
            $code_url = $unifiedOrderResult["code_url"];
            //商户自行增加处理流程
            //......
        }
        $this->assign('total_fee', $totalfee);
        $this->assign('code_url', $code_url);
        $this->assign('unifiedOrderResult', $unifiedOrderResult);
        $this->totleheader="微信扫码支付";
		$this->assign('trade_no',$out_trade_no);
		
        $this->display();
    }

    public function notify() {
        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);

        //验证签名，并回应微信。
        //对后台通知交互时，如果微信收到商户的应答不是成功或超时，微信认为通知失败，
        //微信会通过一定的策略（如30分钟共8次）定期重新发起通知，
        //尽可能提高通知的成功率，但微信不保证通知最终能成功。
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL"); //返回状态码
            $notify->setReturnParameter("return_msg", "签名失败"); //返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS"); //设置返回码
        }
        $returnXml = $notify->returnXml();
        echo $returnXml;

        //==商户根据实际情况设置相应的处理流程，此处仅作举例=======
        //以log文件形式记录回调信息
        //     	$log_ = new Log_();
        //$log_name= __ROOT__."/Public/notify_url.log";//log文件路径
        //$this->log_result($log_name,"【接收到的notify通知】:\n".$xml."\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                //此处应该更新一下订单状态，商户自行增删操作
                //log_result($log_name,"【通信出错】:\n".$xml."\n");
            } elseif ($notify->data["result_code"] == "FAIL") {
                //此处应该更新一下订单状态，商户自行增删操作
                //log_result($log_name,"【业务出错】:\n".$xml."\n");
            } else {
                //此处应该更新一下订单状态，商户自行增删操作
                //log_result($log_name,"【支付成功】:\n".$xml."\n");
                $out_trade_no = $notify->data['out_trade_no'];
                if (!$this->checkorderstatus($out_trade_no)) {
                    $parameter['out_trade_no']=$out_trade_no;
                    $this->orderhandle($parameter);
                }
            }
            //商户自行增加处理流程,
            //例如：更新订单状态
            //例如：数据库操作
            //例如：推送支付完成信息
        }
    }

    public function checkorderstatus($ordid) {
		$ordstatus = M('cz_order')->where("cz_sn='{$ordid}'")->getField('status');
		if ($ordstatus>1) {
			return true;
		} else {
			return false;
		}
    }

//处理订单函数
//更新订单状态，写入订单支付后返回的数据
    public function orderhandle($parameter) {
        $ordid = $parameter['out_trade_no'];
        $data['pay_ways'] = 1; //微信支付
		$data['status'] = 2;
		$res=M('cz_order')->where("cz_sn='{$ordid}'")->save($data);
		//if($res){
			$cz_order=M('cz_order')->where("cz_sn = '{$ordid}'")->find();
			$user_id=$cz_order['user_id'];
			$money=$cz_order['money'];
			//改变余额
			$stock = M("user_info")->where("user_id=$user_id")->getField("money");
			$sj_stock = $stock + $money;
			$s_d = M("user_info")->where("user_id=$user_id")->setField("money", $sj_stock);
			$dat['true_name']=M('user_info')->where("user_id=$user_id")->getField("user_name");
			$dat['phone']=M('user')->where("user_id='$user_id'")->getField("phone");
			$dat['user_id']=$cz_order['user_id'];
			$dat['cz_type'] = 1;
			$dat['cz_money'] = $money;
			$dat['cz_time'] = time();
			$dat['status'] = 2;
			M('cz_record')->add($dat);
		//}
		

    }

}
