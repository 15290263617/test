<?php
namespace Home\Controller;

use Think\Controller;

class PersonalController extends PublicController {
	
	public function __construct(){
		parent::__construct();
		
		if($_SESSION['home']['islogin']==''){
			$this->redirect('/Home/Login/login');
		}
	
	}

	//我的资料
    public function index(){
		//dump($_SESSION);
		if(I('post.')){
			$uid=$_SESSION['home']['uid'];
			$result=M('user_info')->where("user_id = '$uid'")->save(I('post.'));
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$type=$_SESSION['home']['type'];
			$position="i";
			$this->assign('type',$type);
			$this->assign('wei',$position);
			$this->display();
		}
	}
	
	//头像设置
	public function txsz(){
		if($_FILES){
			$uid=$_SESSION['home']['uid'];
			if($_FILES['img']['error']==0);
				$upload = new \Think\Upload();// 实例化上传类
				$upload->maxSize   =     31457280 ;// 设置附件上传大小
				$upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
				$upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
				$upload->savePath  =     'home/'.CONTROLLER_NAME.'/'; // 设置附件上传（子）目录
				$upload->saveName  =array('uniqid',time().'_'.mt_rand());
				$info   =   $upload->upload();
				if(!$info){
					$this->error($upload->getError());
				}else{
					$data['head_img']="/Uploads/".$info['img']['savepath'].$info['img']['savename'];
					$result=M('user_info')->where("user_id = '$uid'")->save($data);
					if($result){
						$this->redirect('Personal/index');
					}
				}
		}else{
			$position="i";
			$this->assign('wei',$position);
			$this->display();
		}
	}

	//修改密码
	public function mmxg(){
		if(I('post.')){
			$uid=$_SESSION['home']['uid'];
			$oldpass=md5(I('post.oldpass'));
			$password=md5(I('post.password'));
			$res=M('user')->where("password = '$oldpass'")->find();
			if($res){
				$result=M('user')->where("user_id = '$uid'")->setField('password',$password);
				if($result){
					$return['status']=1;
				}else{
					$return['status']=0;
				}
			}else{
				$return['status']=2;
			}
			$this->ajaxReturn($return);
		}else{
			$position="m";
			$this->assign('wei',$position);
			$this->display();
		}
	}
	
	//我的地址
	public function address(){
		$uid=$_SESSION['home']['uid'];
		if(I('post.')){
			$data['user_id']=$uid;
			$data['address']=I('post.address');
			$data['address_xx']=I('post.address_xx');
			$data['location_p']=I('post.location_p');
			$data['location_c']=I('post.location_c');
			$data['location_a']=I('post.location_a');
			$data['consignee']=I('post.consignee');
			$data['mobile']=I('post.mobile');
			if(I('post.is_default')=='on'){
				$data['is_default']=1;
				M('user_address')->where("user_id = '$uid'")->setField('is_default',0);
			}else{
				$data['is_default']=0;
			}
			$result=M('user_address')->add($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$result=M('user_address')->where("user_id = '$uid'")->select();
			$this->assign('address',$result);
			$position="a";
			$this->assign('wei',$position);
			$this->display();
		}
	}
	
	//修改地址
	public function modadd(){
		$uid=$_SESSION['home']['uid'];
		if(I('post.')){
			$data['address_xx']=I('post.address_xx');
			$data['location_p']=I('post.location_p');
			$data['location_c']=I('post.location_c');
			$data['location_a']=I('post.location_a');
			$data['consignee']=I('post.consignee');
			$data['mobile']=I('post.mobile');
			if(I('post.is_default')=='on'){
				$data['is_default']=1;
				M('user_address')->where("user_id = '$uid'")->setField('is_default',0);
			}else{
				$data['is_default']=0;
			}
			$add_id=I('post.id');
			$result=M('user_address')->where("address_id = '$add_id'")->save($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$add_id=I('get.id');
			$result=M('user_address')->where("address_id = '$add_id'")->find();
			$this->assign('address',$result);
			$position="a";
			$this->assign('wei',$position);
			$this->display();
		}
	}
	
	//删除地址
	public function del(){
		$id=I('post.id');
		$result=M('user_address')->where("address_id = '$id'")->delete();
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//查询用户状态
	public function typesel(){//查询微信绑定状态
		$user_id=$_SESSION['home']['uid'];
		$type=M('user_info')->where("user_id='$user_id'")->getField('type');
		$_SESSION['home']['type']=$type;
		$return['status']=$type;
		$this->ajaxReturn($return);
	}
	
	public function czcg(){
		$order_sn=I('get.order_sn');
		$order_info=M('cz_order')->where("cz_sn='$order_sn'")->find();
		//dump($order_info);
		$pay_ways=$order_info['pay_ways'];
		switch($pay_ways){//支付方式，1，微信，2，支付宝，3，网银
			case 1:$order_info['pay_ways']="微信支付";break;
			case 2:$order_info['pay_ways']="支付宝支付";break;
			case 3:$order_info['pay_ways']="网银支付";break;
			default:break;
		}
		$this->assign('cz_order',$order_info);
		$this->display();
	}
	
	//我的帐号
	public function account(){
		$uid=$_SESSION['home']['uid'];
		$arr1=array();$arr2=array();
		$tx=M('tx_record')->where("user_id = '$uid' && status = 2")->select();
		$cz=M('cz_record')->where("user_id = '$uid' && status = 2")->select();
		foreach($tx as $key => $val){
			$arr1[$key]['money']=$val['tx_money'];
			$arr1[$key]['time']=$val['tx_time'];
			$arr1[$key]['status']=1;
		}
		foreach($cz as $k => $v){
			$arr2[$k]['money']=$v['cz_money'];
			$arr2[$k]['time']=$v['cz_time'];
			$arr2[$k]['status']=2;
		}
		$arr=array_merge($arr1,$arr2);
		foreach($arr as $ke => $va){
			$time[$ke]=$va['time'];
		}
		array_multisort($arr,SORT_DESC,SORT_NUMERIC);
		$this->assign('arr',$arr);
		$position="z";
		$this->assign('wei',$position);
		$this->display();
	}
	
	//充值
	public function cz(){
		$uid=$_SESSION['home']['uid'];
		if(I('post.')){
			$data['cz_sn']=$cz_sn="YSCZ".time().rand(10,99);
			$data['user_id']=$uid;
			$data['money']=I('post.money');
			$data['time']=time();
			$res=M('cz_order')->add($data);
			if($res){
				$return['cz_sn']=$cz_sn;
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	//提现
	public function tx(){
		if(I('post.')){
			$data['user_id']=$uid=$_SESSION['home']['uid'];
			$data['phone']=I('post.phone');
			$data['bank_name']=I('post.bank');
			$data['bank_number']=I('post.bank_number');
			$data['tx_money']=$tx_money=I('post.tx_money');
			$data['true_name']=I('post.true_name');
			$data['tx_time']=time();
			$money=M('user_info')->where('user_id = '.$uid)->getField('money');
			if($tx_money>$money){
				$return['status']=2;
			}else{
				$result=M('tx_record')->add($data);
				if($result){
					$a=$money-$tx_money;
					M('user_info')->where("user_id = '$uid'")->setField('money',$a);
					$return['status']=1;
				}else{
					$return['status']=0;
				}
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}