<?php
namespace Home\Controller;

use Think\Controller;

class LoginController extends PublicController {

	//登录
    public function login(){
		if(I('post.')){
			$phone=I('post.phone');
			$password=md5(I('post.password'));
			$result=M('user')->where("phone = '$phone'")->find();
			if($result){
				$res=M('user')->where("phone = '$phone' && password = '$password'")->find();
				if($res){
					$data['logintime']=time();
					$data['loginip']=get_client_ip();
					M('user_info')->where('user_id = '.$result['user_id'])->save($data);
					$type=M('user_info')->where('user_id = '.$result['user_id'])->getField('type');
					$_SESSION['home']['islogin']=1;
					$_SESSION['home']['uid']=$result['user_id'];
					$_SESSION['home']['type']=$type;
					$_SESSION['home']['phone']=I('post.phone');
					$return['status']=1;
				}else{
					$return['status']=2;
				}
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			layout(false);
			$this->display();
		}
	}
	
	//退出
	public function logout(){
		unset($_SESSION['home']);
		$this->redirect('Index/index');
	}
	
	//注册
	public function register(){
		if(I('post.')){
			$data['phone']=I('post.phone');
			$data['password']=md5(I('post.password'));
			$code=I('post.code');
			if($code==I('session.code')){
				$res=M('user')->where('phone = '.I('post.phone'))->find();
				if($res){
					$return['status']=2;
				}else{
					$result=M('user')->add($data);
					if($result){
						$dat['user_id']=$result;
						//$str_bh=time();
						//$abc=substr($str_bh,-4);
						//$dat['user_number']="CY".rand(10,99).$abc.rand(1000,9999);
						$dat['addtime']=time();
						$dat['joinip']=get_client_ip();
						$dat['logintime']=time();
						$dat['loginip']=get_client_ip();
						$res1=M('user_info')->add($dat);
						if($res1){
							$_SESSION['home']['islogin']=1;
							$_SESSION['home']['uid']=$result;
							$_SESSION['home']['phone']=I('post.phone');
							$_SESSION['home']['type']=1;
							$return['status']=1;
						}else{
							$return['status']=0;
						}
					}
				}
			}else{
				$return['status']=3;
			}
			$this->ajaxReturn($return);
		}else{
			layout(false);
			$this->display();
		}
	}
	
	//短信验证
	public function codephone(){
		$phone=I('post.phone');
		$sms=code($phone);
		if($sms==0){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}

	//验证码
	public function verify(){
		$Verify = new \Think\Verify();
		$Verify->length   = 4;
		$Verify->fontSize = 60;
		$Verify->useCurve = false;
		$Verify->codeSet = '0123456789';
		$Verify->entry();
	}

	//找回密码
	public function zhaohui(){
		if(I('post.')){
			$phone=I('post.phone');
			$code=I('post.code');
			if(!check_verify($code)){
				//验证码不对
				$return['status']=3;
			}else{
				$res=M('user')->where("phone = '$phone'")->find();
				if($res){
					$return['phone']=I('post.phone');
					$return['status']=1;
				}else{
					$return['status']=2;
				}
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	public function zhaohui2(){
		$this->display();
	}
	
	public function zhaohui3(){
		if(I('post.')){
			$phone=I('post.phone');
			$password=md5(I('post.password'));
			$result=M('user')->where("phone = '$phone'")->setField('password',$password);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
		
	}
	
	//验证手机是否存在
	public function yanzheng(){
		$phone=I('post.phone');
		$res=M('base_user')->where("phone = '$phone'")->find();
		if($res){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//发送手机验证码
	public function code(){
		$phone=I('phone');
		$sms=verify($phone);
		if($sms==0){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//验证码验证
	public function send(){
		$code=I('post.code');
		if($code==session('code')){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	
	
}