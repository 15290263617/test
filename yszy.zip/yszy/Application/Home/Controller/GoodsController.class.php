<?php
namespace Home\Controller;

use Think\Controller;

class GoodsController extends PublicController {
	
	
	public function goods(){
		//商品
		$enum_id=I('get.enum_id');
		$cate_id=I('get.cate_id');
		if(I('get.enum_id')==""){
			if(I('get.sort')==1){
				$goods=M('goods')->order('market_price asc')->where("cat_id = '$cate_id' && is_on_sale = '1' && g_type = '1'")->select();
			}else{
				$goods=M('goods')->where("cat_id = '$cate_id' && is_on_sale = '1' && g_type = '1'")->select();
			}
		}else{
			if(I('get.sort')==1){
				$goods=M('goods')->order('market_price asc')->where("enum_id = '$enum_id' && is_on_sale = '1' && g_type = '1'")->select();
			}else{
				$goods=M('goods')->where("enum_id = '$enum_id' && is_on_sale = '1' && g_type = '1'")->select();
			}
		}
		$this->assign('goods',$goods);
		$this->assign('enum_id',$enum_id);
		$this->assign('cate_id',$cate_id);
		$this->assign('sort',I('get.sort'));
		$this->display();
	}
	
    public function goods_xq(){
		//dump(session());
		//$_SESSION['home']['type']=2;
		$type=I('get.type');
		if($type){
			$_SESSION['angel']['type']=$type;
		}
		$id=I('get.goods_id');
		$goods=M('goods')->where("goods_id = '$id'")->find();
		//图集
		$goods_img=M('goods_img')->order('sort asc')->where("goods_id = '$id'")->select();
		$this->assign('goods_img',$goods_img);
		//dump($goods);
		$this->assign('goods',$goods);
		//热销榜单
		$goods_best=M('goods')->order('goods_id desc')->where("is_best = '1' && is_on_sale = '1' && g_type = '1'")->select();
		$this->assign('goods_best',$goods_best);
		//评价
		$goods_comment=M('goods_comment')->where("goods_id = '$id'")->select();
		$this->assign('goods_comment',$goods_comment);
		$this->assign('comment_num',count($goods_comment));
		//好评
		$good_comment=M('goods_comment')->where("goods_id = '$id' && star >3")->select();
		$this->assign('good_comment',$good_comment);
		$this->assign('good_num',count($good_comment));
		//中评
		$middle_comment=M('goods_comment')->where("goods_id = '$id' && (star =2 || star = 3)")->select();
		$this->assign('middle_comment',$middle_comment);
		$this->assign('middle_num',count($middle_comment));
		//差评
		$bad_comment=M('goods_comment')->where("goods_id = '$id' && star =1")->select();
		$this->assign('bad_comment',$bad_comment);
		$this->assign('bad_num',count($bad_comment));
		
		$this->display();
	}

	//添加购物车
	public function add(){
		$uid=$_SESSION['home']['uid'];
		$user_type=$_SESSION['home']['type'];
		$data['user_id']=$uid;
		$data['num']=I('post.num');
		$data['goods_id']=$goods_id=I('post.goods_id');
		$res=M('car')->where("goods_id = '$goods_id' && user_id = '$uid' && status = '0'")->find();
		if($res){
			$return['status']=2;
		}else{
			if($user_type==1 || $user_type==2){
				$market_price=get_goods_price(I('post.goods_id'));
			}else{
				if(get_goods_type(I('post.goods_id'))==1){
					$market_price=get_shop_price(I('post.goods_id'));
				}else{
					$market_price=get_goods_price(I('post.goods_id'));
				}
				
			}
			$data['xzmoney']=number_format($market_price*I('post.num'),2);
			$data['add_time']=time();
			$result=M('car')->add($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
		}
		$this->ajaxReturn($return);
	}

	//购物车
	public function car(){
		if($_SESSION['home']['islogin']==''){
			$this->redirect('/Home/Login/login');
		}
		$uid=$_SESSION['home']['uid'];
		$user_type=$_SESSION['home']['type'];
		$car=M('car')->where("user_id = '$uid' && status = '0'")->select();
		foreach($car as $k => $v){
			$car[$k]['g_type']=get_goods_type($v['goods_id']);
			if($user_type==1 || $user_type==2){
				$car[$k]['money']=$v['xzmoney'];
			}else{
				if(get_goods_type($v['goods_id'])==1){
					$car[$k]['money']=number_format($v['num']*get_shop_price($v['goods_id']),2);
				}else{
					$car[$k]['money']=$v['xzmoney'];
				}
			}
			$money+=$v['money'];
		}
		//dump($car);
		$this->assign('car',$car);
		$this->assign('user_type',$user_type);
		$this->assign('totalmoney',number_format($money,2));
		
		//热销榜单
		$goods_best=M('goods')->order('goods_id desc')->limit('0,5')->where("is_best = '1' && is_on_sale = '1' && g_type = '1' ")->select();
		$this->assign('goods_best',$goods_best);
		//dump($goods_best);
		$this->display();
	}
	
	//删除购物车
	public function car_del(){
		$car_id=I('post.car_id');
		$result=M('car')->where("car_id = '$car_id'")->delete();
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//提交
	public function tijao(){
		$car_id=I('post.car_id');
		$number=I('post.number');
		$return['status']=1;
		$return['car_id']=$car_id;
		$return['number']=$number;
		$this->ajaxReturn($return);
	}
	
	//结算
	public function jiesuan(){
		if($_SESSION['home']['islogin']==''){
			//$this->redirect('/Home/Login/login');
			$this->redirect('/Home/Login/login');
		}
		$uid=$_SESSION['home']['uid'];
		$user_type=$_SESSION['home']['type'];
		$car_id=I('get.car_id');
		$number=I('get.number');
		$carid=explode('-',$car_id);
		$num=explode('-',$number);
		for($i=0;$i<count($carid);$i++){
			$car[$i]=M('car')->where("car_id = '$carid[$i]'")->find();
			if($user_type==1 || $user_type==2){
				$goods_price=get_goods_price($car[$i]['goods_id']);
			}else{
				if(get_goods_type($car[$i]['goods_id'])==1){
					$goods_price=get_shop_price($car[$i]['goods_id']);
				}else{
					$goods_price=get_goods_price($car[$i]['goods_id']);
				}
				
			}
			$car[$i]['jiesuan_price']=number_format($num[$i]*$goods_price,2);
			$car[$i]['jiesuan_num']=$num[$i];
			$car[$i]['g_type']=get_goods_type($car[$i]['goods_id']);
			$totalmoney+=$car[$i]['jiesuan_price'];
		}
		$this->assign('car',$car);
		$this->assign('totalmoney',number_format($totalmoney,2));
		$address=M('user_address')->where("user_id = '$uid'")->select();
		$is_default=M('user_address')->where("user_id = '$uid' && is_default = '1'")->find();
		$this->assign('address',$address);
		$this->assign('add_id',$is_default['address_id']);
		$this->assign('user_type',$user_type);
		$this->display();
	}
	
	//下订单
	public function order(){
		$uid=$_SESSION['home']['uid'];
		$car_id=I('post.car_id');
		$number=I('post.number');
		$add_id=I('post.add_id');
		$address=M('user_address')->where("address_id = '$add_id'")->find();
		$totalmoney=I('post.totalmoney');
		$data['order_sn']="YSZY".time().rand(10,99);
		$data['user_id']=$uid;
		$data['consignee']=$address['consignee'];
		$data['address']=$address['city_addr'];
		$data['address_xx']=$address['address_xx'];
		$data['phone']=$address['mobile'];
		$data['order_money']=I('post.totalmoney');
		$data['yunfei']=I('post.yunfei');
		$data['add_time']=time();
		$data['buy_status']=1;
		$result=M('order_info')->add($data);
		if($result){
			$dat['order_id']=$result;
			$carid=explode('-',$car_id);
			$num=explode('-',$number);
			for($i=0;$i<count($carid);$i++){
				$dat['goods_id']=get_goods_id($carid[$i]);
				$dat['goods_sn']=get_goods_sn($carid[$i]);
				$dat['goods_name']=get_goods_namebycar_id($carid[$i]);
				$dat['market_price']=get_market_price($carid[$i]);
				$dat['goods_number']=$num[$i];
				$dat['xzmoney']=number_format($num[$i]*get_market_price($carid[$i]),2);
				$res=M('order_goods')->add($dat);
				M('car')->where("car_id = '$carid[$i]'")->setField('status','1');
				if($res){
					$return['status']=1;
					$return['order_id']=$result;
				}else{
					$return['status']=0;
				}
			}
		}
		$this->ajaxReturn($return);
	}
	
	public function fukuan(){
		//dump(session());
		if($_SESSION['home']['islogin']==''){
			$this->redirect('/Home/Login/login');
			//$this->redirect('/Home/Personal/index');
		}
		$order_id=I('get.order_id');
		$orderinfo=M('order_info')->where("order_id = '$order_id'")->find();
		//dump($orderinfo);
		$this->assign('orderinfo',$orderinfo);
		$this->display();
	}
	
	public function order_paid(){
		$order_sn=I('get.order_sn');
		$order_info=M('order_info')->where("order_sn='$order_sn'")->find();
		//dump($order_info);
		$pay_ways=$order_info['pay_ways'];
		switch($pay_ways){//支付方式，1，微信，2，支付宝，3，网银
			case 1:$order_info['pay_ways']="支付宝支付";break;
			case 2:$order_info['pay_ways']="微信支付";break;
			case 3:$order_info['pay_ways']="网银支付";break;
			case 4:$order_info['pay_ways']="余额支付";break;
			default:break;
		}
		$this->assign('cz_order',$order_info);
		$this->display();
	}
	
	//立即购买
	public function goumai(){
		$goods_id=I('post.goods_id');
		$return['status']=1;
		$return['goods_id']=I('post.goods_id');
		$return['num']=I('post.num');
		$this->ajaxReturn($return);
	}
	
	public function buy(){
		if($_SESSION['home']['islogin']==''){
			$this->redirect('/Home/Login/login');
			//$this->redirect('/Home/Personal/index');
		}
		$uid=$_SESSION['home']['uid'];
		$user_type=$_SESSION['home']['type'];
		$goods_id=I('get.goods_id');
		$num=I('get.num');
		$goods=M('goods')->where("goods_id = '$goods_id'")->find();
		if($user_type==1 || $user_type==2){
			$goods['totalmoney']=number_format($num*$goods['market_price'],2);
		}else{
			if($goods['g_type']==1){
				$goods['totalmoney']=number_format($num*get_shop_price($goods['goods_id']),2);
			}else{
				$goods['totalmoney']=number_format($num*$goods['market_price'],2);
			}
		}
		//dump($goods);
		$this->assign('num',$num);
		$this->assign('goods',$goods);
		$address=M('user_address')->where("user_id = '$uid'")->select();
		$is_default=M('user_address')->where("user_id = '$uid' && is_default = '1'")->find();
		$this->assign('address',$address);
		$this->assign('add_id',$is_default['address_id']);
		$this->assign('user_type',$user_type);
		$this->display();
	}
	
	public function xiadan(){
		$uid=$_SESSION['home']['uid'];
		$goods_id=I('post.goods_id');
		$goodsinfo=M('goods')->where("goods_id")->where("goods_id = '$goods_id'")->find();
		$num=I('post.num');
		$add_id=I('post.add_id');
		$address=M('user_address')->where("address_id = '$add_id'")->find();
		$totalmoney=I('post.totalmoney');
		$data['order_sn']="YSZY".time().rand(10,99);
		$data['user_id']=$uid;
		$data['consignee']=$address['consignee'];
		$data['address']=$address['city_addr'];
		$data['address_xx']=$address['location_p'].$address['location_c'].$address['location_a'];
		$data['phone']=$address['mobile'];
		$data['order_money']=I('post.totalmoney');
		$data['yunfei']=I('post.yunfei');
		$data['add_time']=time();
		$result=M('order_info')->add($data);
		if($result){
			$dat['order_id']=$result;
			$dat['goods_id']=$goods_id;
			$dat['goods_sn']=$goodsinfo['goods_sn'];
			$dat['goods_name']=$goodsinfo['goods_name'];
			$dat['market_price']=$goodsinfo['market_price'];
			$dat['goods_number']=$num;
			$dat['xzmoney']=$totalmoney;
			$res=M('order_goods')->add($dat);
			if($res){
				$return['status']=1;
				$return['order_id']=$result;
			}else{
				$return['status']=0;
			}
		}
		$this->ajaxReturn($return);
	}
	
	//余额付款
	public function pay(){
		$user_id=$_SESSION['home']['uid'];
		$order_id=I('post.id');
		$order_money=M('order_info')->where("order_id = '$order_id'")->getField('order_money');
		$user_money=M('user_info')->where("user_id = '$user_id'")->getField('money');
		if($order_money>$user_money){
			$return['status']=2;
		}else{
			$money=$user_money-$order_money;
			$res=M('user_info')->where("user_id = '$user_id'")->setField('money',$money);
			if($res){
				$data['pay_ways'] = 4; //余额支付
				$data['order_status'] = 2;
				M('order_info')->where("order_id ='$order_id'")->save($data);
				$user_type=M('user_info')->where("user_id = '$user_id'")->getField('type');
				$goods = M("order_goods")->where("order_id='$order_id'")->select();
				foreach($goods as $k => $v){
					$goods_id=$v['goods_id'];
					$num=$v['goods_number'];
					$stock = M("goods")->where("goods_id=$goods_id")->getField("goods_kucun");
					$sj_stock = $stock - $num; //减掉库存
					$s_d = M("goods")->where("goods_id=$goods_id")->setField("goods_kucun", $sj_stock);
					$g_type=M('goods')->where("goods_id=$goods_id")->getField("g_type");//购买礼包类型
					//成为创业天使
					if($user_type<3){
						if($g_type==2){//A
							M('user_info')->where("user_id = '$user_id'")->setField("type",3);
						}else if($g_type==3){//B
							M('user_info')->where("user_id = '$user_id'")->setField("type",4);
						}
					}
					//上级获利
					$recommend_id=M('user_info')->where("user_id = '$user_id'")->getField("recommend_id");//上级id
					if($recommend_id){//有上级
						$sj_type_id=M('user_info')->where("user_id = '$recommend_id'")->getField('type');//上级类型
						if($g_type==2){//A
							if($sj_type_id==3){//A型创业天使
								$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
								$money=$user_money+50;
								M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
							}else if($sj_type_id==4){//B型创业天使
								$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
								$money=$user_money+40;
								M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
							}
						}else if($g_type=3){//B
							if($sj_type_id==4){
								$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
								$money=$user_money+20;
								M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
							}
						}
					}
					
					
					/* if($user_type<3){//不是创业天使
						$g_type=M('goods')->where("goods_id=$goods_id")->getField("g_type");//购买礼包类型
						if($g_type==2){//A
							M('user_info')->where("user_id = '$user_id'")->setField("type",3);
							$recommend_id=M('user_info')->where("user_id = '$user_id'")->getField("recommend_id");//上级id
							if($recommend_id){//有上级
								$sj_type_id=M('user_info')->where("user_id = '$recommend_id'")->getField('type');//上级类型
								if($sj_type_id==3){//A型创业天使
									$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
									$money=$user_money+50;
									M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
								}else if($sj_type_id==4){//B型创业天使
									$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
									$money=$user_money+40;
									M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
								}
							}
						}else if($g_type==3){//B
							M('user_info')->where("user_id = '$user_id'")->setField("type",4);
							$recommend_id=M('user_info')->where("user_id = '$user_id'")->getField("recommend_id");
							if($recommend_id){
								$sj_type_id=M('user_info')->where("user_id = '$recommend_id'")->getField('type');
								if($sj_type_id==4){
									$user_money=M('user_info')->where("user_id = '$recommend_id'")->getField('money');
									$money=$user_money+20;
									M('user_info')->where("user_id = '$recommend_id'")->setField("money",$money);
								}
							}
						}
					} */
				}
				$return['status']=1;
			}else{
				$return['status']=0;
			}
		}
		$this->ajaxReturn($return);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}