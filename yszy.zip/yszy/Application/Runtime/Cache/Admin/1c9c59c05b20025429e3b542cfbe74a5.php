<?php if (!defined('THINK_PATH')) exit();?>
<link rel="stylesheet" href="/Public/admin/assets/css/bootstrap.css">
<script src="/Public/admin/assets/js/jquery-1.11.1.min.js"></script>
<script src="/Public/layer/layer.js"></script>
<div class="panel panel-default">
       
				<div class="panel-heading" style="padding:0px;">
<h3 class="panel-title"></h3>
				<!-- <div class="row" style="margin-left:90%;">
	<a href="<?php echo U('Ad/adspositionadd');?>"><button class="btn btn-success" >广告位添加</button></a>
			</div> -->
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped" id="example-2">
						<thead>
							<tr>
								<th>商品货号</th>
								<th>商品名称</th>
								<th>商品价格</th>
								<th>商品数量</th>
								<th>小计</th>
								<!-- <th>属性</th> -->
							</tr>
						</thead>
						
						<tbody class="middle-align">		
				
							<?php if(is_array($order_goods)): $i = 0; $__LIST__ = $order_goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$goods): $mod = ($i % 2 );++$i;?><tr>	
								<td><?php echo ($goods["goods_sn"]); ?></td>
								<td><?php echo ($goods["goods_name"]); ?></td>
								<td><?php echo ($goods["shop_price"]); ?></td>
								<td><?php echo ($goods["goods_number"]); ?></td>
								<td><?php echo ($goods["xzmoney"]); ?></td>
								<!-- <td><?php if(is_array($goods["attr_value"])): $i = 0; $__LIST__ = $goods["attr_value"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i; echo ($v); ?>&nbsp;&nbsp;<?php endforeach; endif; else: echo "" ;endif; ?></td> -->
							</tr><?php endforeach; endif; else: echo "" ;endif; ?>							
						</tbody>
					</table>
					<?php if($order_info["order_status"] == 1): ?><a class="btn btn-danger btn-sm btn-icon icon-left">
										未支付
					</a>
					<?php else: ?>
					<a class="btn btn-danger btn-sm btn-icon icon-left">
										已支付
					</a><?php endif; ?>
					<?php if($order_info["order_status"] == 3): ?><a class="btn btn-danger btn-sm btn-icon icon-left" >
									已发货	
					</a>
					<?php elseif($order_info["order_status"] == 2): ?>
					<a class="btn btn-danger btn-sm btn-icon icon-left" onclick="shipping_order(<?php echo ($order_info["order_id"]); ?>)" id="<?php echo ($order_info["order_id"]); ?>">
								发货		
					</a><?php endif; ?>
					<?php if($order_info["order_status"] == 5): ?><a class="btn btn-danger btn-sm btn-icon icon-left">
										已评价
					</a>
					<?php elseif($order_info["order_status"] == 4): ?>
					<a class="btn btn-danger btn-sm btn-icon icon-left">
										已签收
					</a><?php endif; ?>
				</div>
			</div>
<script>
function shipping_order(id){
  var order_id=id;
  //alert(order_id);
  $.ajax({
     type:"post",
	 url:"<?php echo U('Order/shipping_order');?>",
	 data:"order_id="+order_id,
	 success:function(msg){
	 //alert(msg.status);
	    if(msg.status==1){
		  layer.msg("发货成功");
		  $("#"+order_id).text("已发货");
		}else{
		  layer.msg("发货失败！");
		}
	 }
  });
}

</script>