<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="豫商纸业管理系统" />
        <meta name="author" content="豫商纸业管理系统" />	
        <title>豫商纸业管理系统</title>
        <link rel="stylesheet" href="/Public/admin/assets/css/bootstrap.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-core.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/fonts/linecons/css/linecons.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/fonts/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-forms.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-components.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-skins.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/custom.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/Css.css">
        <script src="/Public/admin/assets/js/jquery-1.11.1.min.js"></script>
        <!-- 	siqi -->
        <script src="/Public/admin/assets/js/bootbox/bootbox.min.js"></script>
        <script src="/Public/admin/assets/js/ckeditor/ckeditor.js"></script>
        <script src="http://apps.bdimg.com/libs/layer/2.0/layer.js" type="text/javascript"></script>
    </head>
    <body  class="page-body skin-navy">
        <div class="settings-pane">	
            <a href="#" data-toggle="settings-pane" data-animate="true"></a>
            <div class="settings-pane-inner">
                <div class="row">
                    <div class="col-md-4">
                        <div class="user-info">
                            <div class="user-image">
                               
                            </div>

                            <div class="user-details">

                                <h3>
                                    <a href="#"><?php echo ($a_d["name"]); ?></a>

                                    <!-- Available statuses: is-online, is-idle, is-busy and is-offline -->
                                    <span class="user-status is-online"></span>
                                </h3>



                                <div class="user-links">
                                    <a href="/User/index/tc" class="btn btn-orange">退出</a>
                                    <a  href="javascript:;" onclick="jQuery('#modal-10').modal('show', {backdrop: 'static'});" class="btn btn-success">修改密码</a>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="page-container">

            <div class="sidebar-menu toggle-others fixed">

                <div class="sidebar-menu-inner">	

                    <header class="logo-env">

                        <!-- logo -->
                        <div class="logo">
                            <a href="###" class="logo-expanded">
                                <!-- <img src="/Public/home/images/yslogo.png" width="120" alt="" /> -->
                                <!--<img src="/Public/admin/assets/images/logo@2x.png" width="80" alt="" />-->
                            </a>

                            <a href="###" class="logo-collapsed">
                                <img src="/Public/admin/assets/images/logo-collapsed@2x.png" width="40" alt="" />
                            </a>
                        </div>

                        <!-- This will toggle the mobile menu and will be visible only on mobile devices -->
                        <div class="mobile-menu-toggle visible-xs">
                            <a href="#" data-toggle="user-info-menu">
                                <i class="fa-bell-o"></i>
                                <span class="badge badge-success">7</span>
                            </a>

                            <a href="#" data-toggle="mobile-menu">
                                <i class="fa-bars"></i>
                            </a>
                        </div>

                        <!-- This will open the popup with user profile settings, you can use for any purpose, just be creative -->
                        <div class="settings-icon">
                            <a href="#" data-toggle="settings-pane" data-animate="true">
                                <i class="linecons-cog"></i>
                            </a>
                        </div>		

                    </header>


                    <ul id="main-menu" class="main-menu">
                        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
                        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
                        <li class="opened active">
                            <a href="<?php echo U('Index/index');?>">
                                <i class="fa fa-institution"></i>
                                <span class="title">系统主页 - System Main Page </span>
                            </a>
                        </li>
						<li>
                            <a href="#">
                                <i class="fa fa-wrench"></i>
                                <span class="title">系统管理 - System Manage</span>
                            </a>
                            <ul>
							
                                <li>
                                    <a href="<?php echo U('Sys/index');?>">
                                        <span class="title">系统配置 - Sys setting</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('Admin/index');?>">
                                        <span class="title">管理员列表 - Admin list</span>
                                    </a>
                                </li>
								
                                <li>
                                    <a href="<?php echo U('Sys/nav');?>">
                                        <span class="title">导航管理 - Nav setting</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo U('Sys/friend');?>">
                                        <span class="title">友情链接管理 - Friend Manage</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo U('Db/index');?>">
                                        <span class="title">数据库备份与还原 - Db manage</span>
                                    </a>
                                </li>
								
                            </ul>
                        </li>
                         <li>
                            <a href="#">
								<i class="fa fa-qq"></i>
                                <span class="title">用户管理 - User Manage</span>
                            </a>
                            <ul>
								
                                <li>
                                    <a href="<?php echo U('User/index');?>">
                                        <span class="title">会员列表 - User list</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('User/tx_record');?>">
                                        <span class="title">会员提现申请列表 - User tx list</span>
                                    </a>
                                </li>
								 <!-- <li>
                                    <a href="<?php echo U('User/scores');?>">
                                        <span class="title">积分设置 - User scores</span>
                                    </a>
                                </li> -->
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                 <i class="fa fa-slideshare"></i>
                                <span class="title">广告管理 - Ads Manage</span>
                            </a>
							<ul>
							  <li>
                                    <a href="<?php echo U('Ads/banner');?>">
                                        <span class="title">广告添加 - Ads Add</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('Ads/blist');?>">
                                        <span class="title">广告列表 - Ads List</span>
                                    </a>
                                </li>								
							</ul>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-tencent-weibo"></i>
                                <span class="title">文章管理 - Article Manage</span>
                            </a>
                            <ul>
							
                               <li>
                                    <a href="<?php echo U('Article/index');?>">
                                        <span class="title">文章列表 - Article list</span>
                                    </a>
									<a href="<?php echo U('Article/add');?>">
                                        <span class="title">文章添加 - Article add</span>
                                    </a>
									<a href="<?php echo U('Article/cate');?>">
                                        <span class="title">文章分类列表 - Article Cate list</span>
                                    </a>
									
                                </li>

                            </ul>
                        </li>

						 <li>
                            <a href="#">
                                <i class="fa fa-apple"></i>
                                <span class="title">商品管理 - Goods Manage</span>
                            </a>
                            <ul>                
                            <li>
                            <a href="<?php echo U('Goods/addgoods');?>" >
                               <span class="title">商品添加 - Goods add</span>
                            </a>
							 <a href="<?php echo U('Goods/glist');?>" >
                               <span class="title">商品列表 - Goods list</span>
                            </a>
							 <a href="<?php echo U('Goods/glblist');?>" >
                               <span class="title">礼包列表 - Gift list</span>
                            </a>
							<a href="<?php echo U('Goods/catelist');?>" >
                               <span class="title">商品分类列表 - Goods Cate list</span>
                            </a>
							 <!-- <a href="<?php echo U('Goods/glist');?>" >
                               <span class="title">商品评论列表 - Goods Comment list</span>
                            </a> -->
							<a href="<?php echo U('Goods/goods_record');?>" >
                               <span class="title">商品库存修改记录 - Goods Store Change record</span>
                            </a>
                            </li>   
                            </ul>
                        </li>
						<li>
                            <a href="#">
                                <i class="fa fa-file-text-o"></i>
                                <span class="title">订单管理 - Order Manage</span>
                            </a>
                            <ul>                
								<li>
									<a href="<?php echo U('Order/index');?>" >
									   <span class="title">订单列表 - Order list</span>
									</a>
								</li>   
                            </ul>
                        </li>
						<li>
							<a href="#">
								<i class="fa fa-ge"></i>
								<span class="title">SEO设置 - SEO Manage</span>
							</a>
							<ul>
								<li><a href="<?php echo U('Seo/index');?>"><span class="title">SEO网站设置 - SEO manage</span></a></li>
							</ul>
						</li>
						<!-- <li>
							<a href="#">
								<i class="fa fa-ge"></i>
								<span class="title">王国百科 - Baike Manage</span>
							</a>
							<ul>
								<li><a href="<?php echo U('Baike/index');?>"><span class="title">训练分类管理 - Type manage</span></a></li>
								<!--<li><a href="<?php echo U('Baike/add_art');?>"><span class="title">添加文章 - Add article</span></a></li>-->
								<!-- <li><a href="<?php echo U('Baike/article');?>"><span class="title">训练文章列表 - Article list</span></a></li>
								<li><a href="<?php echo U('Baike/m_article');?>"><span class="title">肌肉文章列表 - Article list</span></a></li>
							</ul>
						</li> --> 
                    </ul>
                </div>

            </div>
            <div class="main-content">
                <!-- User Info, Notifications and Menu Bar -->
                <nav class="navbar user-info-navbar" role="navigation">
				<!-- Left links for user info navbar -->
                    <ul class="user-info-menu left-links list-inline list-unstyled">

                        <li class="hidden-sm hidden-xs">
                            <a href="#" data-toggle="sidebar">
                                <i class="fa-bars"></i>
                            </a>
                        </li>
                    </ul>
                </nav> 
            
     <script type="text/javascript" src="/Public/ueditor/ueditor.config.js"></script>    
<script type="text/javascript" src="/Public/ueditor/ueditor.all.min.js"></script>
<div class="panel panel-default">
	<div class="panel-heading">
		<h3 class="panel-title">发布文章</h3>
	</div>
	<div class="panel-body">
           <div class="row">
			<div class="col-sm-1">
						<label class="control-label">文章分类</label>
			</div>
			<div class="col-sm-10">
						<div class="form-group">			
                        <select class="form-control" id="cat_id">
							<option value="">请选择</option>
							<?php if(is_array($type)): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v["cat_id"]); ?>"><?php echo ($v["cat_name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>                                              
						</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-sm-1">
						<label class="control-label">文章标题 </label>
			</div>
			<div class="col-sm-10">
						<div class="input-group">
						<span class="input-group-btn">
						<button class="btn btn-info" type="button">标题</button>
						</span>
						<input class="form-control no-left-border form-focus-info" type="text" id='title'>
						</div>
			</div>
		</div>
		<br>
		<!--	
		<div class="row">
			<div class="col-sm-1">
						<label class="control-label">文章摘要</label>
			</div>
			<div class="col-sm-10">
						<div class="input-group">
						<span class="input-group-btn">
						<button class="btn btn-info" type="button">摘要</button>
						</span>
						<input class="form-control no-left-border form-focus-info" type="text" id='abstracta'>
						</div>
			</div>
		</div>
		<br>
	
		<div class="row">
			<div class="col-sm-1">
				<label class="control-label">文章图片</label>
			</div>
			<div class="col-sm-11">
				<div class="input-group">
				<div class="col-sm-5"></div>
				<div class="col-sm-3">
					<input type="file" id="files" name='upload' data-url="<?php echo U('Article/upload');?>" style="width:200px">
				</div>
				</div>
			</div>
		</div>
		<br>
		-->
		<br>
		<div class="row">
			<div class="col-sm-1">
                <label class="control-label">文章内容</label>
			</div>
				<div class="col-sm-10">
					<div id="content" name="content"></div>
				</div>
        </div>
		<br>
		<div class="row">
			<div class="col-sm-2">

			</div>
			<div class="col-sm-4">
				<button class="btn btn-secondary" type="button" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="点击确定将发布文章内容" id='publish'>确定添加</button>
			</div>
			<div class="col-sm-4">
				
			</div>
		</div>
	</div>
</div>	
	<script src="/Public/admin/assets/js/jquery-ui/jquery-ui.min.js"></script>

	<script src="/Public/admin/assets/js/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/vendor/load-image.min.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/vendor/canvas-to-blob.min.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/jquery.iframe-transport.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/jquery.fileupload.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/jquery.fileupload-process.js"></script>
	
	<script src="/Public/admin/assets/js/jquery-file-upload/js/jquery.fileupload-ui.js"></script>


<script type="text/javascript">
  $(function () {
            //文件上传地址   
           //var url = 'http://localhost/index.php/upload/do_upload';   
           //初始化，主要是设置上传参数，以及事件处理方法(回调函数)   
           $('#files').val('');
           $('#files').fileupload({  
             autoUpload: true,//是否自动上传   
                //url: url,//上传地址   
               dataType: 'json',  
                done: function (e, data){
                    $('#files').parent().prev("div.col-sm-5").html('<img src="/Uploads/'+data.result.path+'" style="width:150px;height:75px;"  id="upload_pic" path="'+data.result.path+'"/>')
               },
               complete:function(){
                        }
            });  
        });
</script>
        <script>
            $('#publish').click(function(){
                var cat_id=$('#cat_id').val();
                var title=$('#title').val();
                //var abstracta=$('#abstracta').val();
                //var litpic=$('#upload_pic').attr('path');
                var content= UE.getEditor('content').getContent();
                if(cat_id==''||title==""||content==""){
                    layer.msg('填写选项不能为空',{icon: 2});
                    return false;
                }
               $.ajax({
               	type: "post",
            	url: "<?php echo U('Article/add_art');?>",
            	data: {
            		cat_id: cat_id,
            		title: title,
            		content: content
				},
            	dataType: 'json',
                   success:function(dat){
                       if(dat.status==1){
                           layer.msg('发布成功',{icon:1});
							setTimeout(function () {
								window.location.href="/index.php/Admin/Article/index";
							}, 1500);
                       }else{
                          layer.msg('发布失败',{icon:2});
                       }
                   }
               }) 
            });
           </script>
<script>
	var ue = UE.getEditor("content");
</script>	   
		   
		    
			<!-- 公共footer包 -->
			
			<footer class="main-footer sticky fixed footer-type-1">
				
				<div class="footer-inner">
				
					<!-- Add your copyright text here -->
					<div class="footer-text">
						 &copy; 2016 
						<strong>Lingshow</strong> 
						河南灵秀网络科技有限公司
					</div>

					<!-- 顶置按钮  -->
					<div class="go-up">
						<a href="#" rel="go-top">
							<i class="fa-angle-up"></i>
						</a>					
					</div>				
				</div>				
			</footer>
		</div>

	</div>
	<!-- 动态弹窗，内容由JS来决定 -->
		<!-- Modal 6 (Long Modal)-->
	<div class="modal fade" id="modal-6">
		<div class="modal-dialog">
			<div class="modal-content">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">用户详细信息</h4>
				</div>
				
				<div class="modal-body">
				
					
					
				</div>
				
				<div class="modal-footer">
					<button type="button" class="btn btn-orange" data-dismiss="modal">Close</button>
					
				</div>
			</div>
		</div>
	</div>
 <!-- Gallery Modal Image -->
	<div class="modal fade" id="gallery-image-modal">
		<div class="modal-dialog">
			<div class="modal-content">
				
				<div class="modal-gallery-image">
					<img src="/Public/admin/assets/images/album-image-full.jpg" class="img-responsive" />
				</div>
				
				
				
				<div class="modal-footer modal-gallery-top-controls">
					<button type="button" class="btn btn-xs btn-white" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
        <!--5  管理员密码修改框-->
<div class="modal fade" id="modal-10">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close q55" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">密码修改</h4>
            </div>
            <label for="field-1" style="margin-top: 2%;" class="control-label">请输入原始密码：</label>
            <input type="password" name="mm0" class="form-control mm0" style="width: 50%;" placeholder="密码 密码的长度大于5位" required="">

            <div class="modal-body">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="field-1" class="control-label">请输入密码：</label>
                            <input type="password" name="mm" class="form-control mm3" placeholder="密码 密码的长度大于5位" required="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="field-2" class="control-label">再次输入：</label>
                            <input type="password" name="mm1" class="form-control mm13" placeholder="确认密码" required="">
                        </div>
                    </div>
                        <input type="hidden" name="id" value=""/>
                   
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white q55" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-info q45" onclick="submit()">确定</button>
            </div>
        </div>
    </div>
</div>
        <script>
url = window.location.pathname + window.location.search;

$("#main-menu li ul li a[href='" + url + "']").parent().addClass("active");
$("#main-menu li ul li a[href='" + url + "']").parent().parent().parent().addClass("active opened active expanded has-sub");
            function submit(){
                var oldpwd=$(":input[name='mm0']").val();
                var newpwd=$(":input[name='mm']").val();
                var repwd=$(":input[name='mm1']").val();
                if(newpwd.length<6){
                    alert("输入密码的长度不能小于6位");
                    $(":input[name='mm']").focus();
                    return ;
                }
                var patt2 = new RegExp(/^([0-9A-Za-z]*)+$/g);
                var result = patt2.test(newpwd);
                if(result==false){
                    alert("输入的密码必须为数字或字母");
                    return ;
                }
                if(newpwd!=repwd){
                    alert("请重新确认密码");
                    $(":input[name='mm1']").focus();
                    return ;
                }else{
                    $.ajax({
                        'type':'post',
                        'data':'oldpwd='+oldpwd+"&newpwd="+newpwd+"&repwd="+repwd,
                        'dataType':'json',
                        'url':"/User/Index/edt",
                        'success':function(dat){
                            alert(dat.msg)
                        }
                    })
                }
            }
        </script>

	<!-- js核心包 -->
	<script src="/Public/admin/assets/js/bootstrap.min.js"></script>
	<script src="/Public/admin/assets/js/TweenMax.min.js"></script>
	<script src="/Public/admin/assets/js/resizeable.js"></script>
	<script src="/Public/admin/assets/js/joinable.js"></script>
	<script src="/Public/admin/assets/js/xenon-api.js"></script>
	<script src="/Public/admin/assets/js/xenon-toggles.js"></script>
	<!-- 特殊加载包 -->
	<link rel="stylesheet" href="/Public/admin/assets/css/fonts/meteocons/css/meteocons.css">
		<!-- 特殊加载包/提示包 -->
	<script src="/Public/admin/assets/js/toastr/toastr.min.js"></script>
		<!-- 特殊加载包/首页样式块包 -->
	<script src="/Public/admin/assets/js/xenon-widgets.js"></script>
		<!-- 特殊加载包/模板样式通用包 -->
	<script src="/Public/admin/assets/js/xenon-custom.js"></script>
</body>
</html>