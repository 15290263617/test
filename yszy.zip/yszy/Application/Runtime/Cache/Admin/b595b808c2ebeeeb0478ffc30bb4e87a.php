<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="豫商纸业管理系统" />
        <meta name="author" content="豫商纸业管理系统" />	
        <title>豫商纸业管理系统</title>
        <link rel="stylesheet" href="/Public/admin/assets/css/bootstrap.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-core.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/fonts/linecons/css/linecons.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/fonts/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-forms.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-components.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/xenon-skins.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/custom.css">
        <link rel="stylesheet" href="/Public/admin/assets/css/Css.css">
        <script src="/Public/admin/assets/js/jquery-1.11.1.min.js"></script>
        <!-- 	siqi -->
        <script src="/Public/admin/assets/js/bootbox/bootbox.min.js"></script>
        <script src="/Public/admin/assets/js/ckeditor/ckeditor.js"></script>
        <script src="http://apps.bdimg.com/libs/layer/2.0/layer.js" type="text/javascript"></script>
    </head>
    <body  class="page-body skin-navy">
        <div class="settings-pane">	
            <a href="#" data-toggle="settings-pane" data-animate="true"></a>
            <div class="settings-pane-inner">
                <div class="row">
                    <div class="col-md-4">
                        <div class="user-info">
                            <div class="user-image">
                               
                            </div>

                            <div class="user-details">

                                <h3>
                                    <a href="#"><?php echo ($a_d["name"]); ?></a>

                                    <!-- Available statuses: is-online, is-idle, is-busy and is-offline -->
                                    <span class="user-status is-online"></span>
                                </h3>



                                <div class="user-links">
                                    <a href="/User/index/tc" class="btn btn-orange">退出</a>
                                    <a  href="javascript:;" onclick="jQuery('#modal-10').modal('show', {backdrop: 'static'});" class="btn btn-success">修改密码</a>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="page-container">

            <div class="sidebar-menu toggle-others fixed">

                <div class="sidebar-menu-inner">	

                    <header class="logo-env">

                        <!-- logo -->
                        <div class="logo">
                            <a href="###" class="logo-expanded">
                                <!-- <img src="/Public/home/images/yslogo.png" width="120" alt="" /> -->
                                <!--<img src="/Public/admin/assets/images/logo@2x.png" width="80" alt="" />-->
                            </a>

                            <a href="###" class="logo-collapsed">
                                <img src="/Public/admin/assets/images/logo-collapsed@2x.png" width="40" alt="" />
                            </a>
                        </div>

                        <!-- This will toggle the mobile menu and will be visible only on mobile devices -->
                        <div class="mobile-menu-toggle visible-xs">
                            <a href="#" data-toggle="user-info-menu">
                                <i class="fa-bell-o"></i>
                                <span class="badge badge-success">7</span>
                            </a>

                            <a href="#" data-toggle="mobile-menu">
                                <i class="fa-bars"></i>
                            </a>
                        </div>

                        <!-- This will open the popup with user profile settings, you can use for any purpose, just be creative -->
                        <div class="settings-icon">
                            <a href="#" data-toggle="settings-pane" data-animate="true">
                                <i class="linecons-cog"></i>
                            </a>
                        </div>		

                    </header>


                    <ul id="main-menu" class="main-menu">
                        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
                        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
                        <li class="opened active">
                            <a href="<?php echo U('Index/index');?>">
                                <i class="fa fa-institution"></i>
                                <span class="title">系统主页 - System Main Page </span>
                            </a>
                        </li>
						<li>
                            <a href="#">
                                <i class="fa fa-wrench"></i>
                                <span class="title">系统管理 - System Manage</span>
                            </a>
                            <ul>
							
                                <li>
                                    <a href="<?php echo U('Sys/index');?>">
                                        <span class="title">系统配置 - Sys setting</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('Admin/index');?>">
                                        <span class="title">管理员列表 - Admin list</span>
                                    </a>
                                </li>
								
                                <li>
                                    <a href="<?php echo U('Sys/nav');?>">
                                        <span class="title">导航管理 - Nav setting</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo U('Sys/friend');?>">
                                        <span class="title">友情链接管理 - Friend Manage</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo U('Db/index');?>">
                                        <span class="title">数据库备份与还原 - Db manage</span>
                                    </a>
                                </li>
								
                            </ul>
                        </li>
                         <li>
                            <a href="#">
								<i class="fa fa-qq"></i>
                                <span class="title">用户管理 - User Manage</span>
                            </a>
                            <ul>
								
                                <li>
                                    <a href="<?php echo U('User/index');?>">
                                        <span class="title">会员列表 - User list</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('User/tx_record');?>">
                                        <span class="title">会员提现申请列表 - User tx list</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('User/cz_record');?>">
                                        <span class="title">会员充值记录列表 - User cz list</span>
                                    </a>
                                </li>
								 <!-- <li>
                                    <a href="<?php echo U('User/scores');?>">
                                        <span class="title">积分设置 - User scores</span>
                                    </a>
                                </li> -->
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                 <i class="fa fa-slideshare"></i>
                                <span class="title">广告管理 - Ads Manage</span>
                            </a>
							<ul>
							  <li>
                                    <a href="<?php echo U('Ads/banner');?>">
                                        <span class="title">广告添加 - Ads Add</span>
                                    </a>
                                </li>
								<li>
                                    <a href="<?php echo U('Ads/blist');?>">
                                        <span class="title">广告列表 - Ads List</span>
                                    </a>
                                </li>								
							</ul>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-tencent-weibo"></i>
                                <span class="title">文章管理 - Article Manage</span>
                            </a>
                            <ul>
							
                               <li>
                                    <a href="<?php echo U('Article/index');?>">
                                        <span class="title">文章列表 - Article list</span>
                                    </a>
									<a href="<?php echo U('Article/add');?>">
                                        <span class="title">文章添加 - Article add</span>
                                    </a>
									<a href="<?php echo U('Article/cate');?>">
                                        <span class="title">文章分类列表 - Article Cate list</span>
                                    </a>
									
                                </li>

                            </ul>
                        </li>

						 <li>
                            <a href="#">
                                <i class="fa fa-apple"></i>
                                <span class="title">商品管理 - Goods Manage</span>
                            </a>
                            <ul>                
                            <li>
                            <a href="<?php echo U('Goods/addgoods');?>" >
                               <span class="title">商品添加 - Goods add</span>
                            </a>
							 <a href="<?php echo U('Goods/glist');?>" >
                               <span class="title">商品列表 - Goods list</span>
                            </a>
							 <a href="<?php echo U('Goods/glblist');?>" >
                               <span class="title">礼包列表 - Gift list</span>
                            </a>
							<a href="<?php echo U('Goods/catelist');?>" >
                               <span class="title">商品分类列表 - Goods Cate list</span>
                            </a>
							 <!-- <a href="<?php echo U('Goods/glist');?>" >
                               <span class="title">商品评论列表 - Goods Comment list</span>
                            </a> -->
							<a href="<?php echo U('Goods/goods_record');?>" >
                               <span class="title">商品库存修改记录 - Goods Store Change record</span>
                            </a>
                            </li>   
                            </ul>
                        </li>
						<li>
                            <a href="#">
                                <i class="fa fa-file-text-o"></i>
                                <span class="title">订单管理 - Order Manage</span>
                            </a>
                            <ul>                
								<li>
									<a href="<?php echo U('Order/index');?>" >
									   <span class="title">订单列表 - Order list</span>
									</a>
								</li>   
                            </ul>
                        </li>
						<li>
							<a href="#">
								<i class="fa fa-ge"></i>
								<span class="title">SEO设置 - SEO Manage</span>
							</a>
							<ul>
								<li><a href="<?php echo U('Seo/index');?>"><span class="title">SEO网站设置 - SEO manage</span></a></li>
							</ul>
						</li>
						<!-- <li>
							<a href="#">
								<i class="fa fa-ge"></i>
								<span class="title">王国百科 - Baike Manage</span>
							</a>
							<ul>
								<li><a href="<?php echo U('Baike/index');?>"><span class="title">训练分类管理 - Type manage</span></a></li>
								<!--<li><a href="<?php echo U('Baike/add_art');?>"><span class="title">添加文章 - Add article</span></a></li>-->
								<!-- <li><a href="<?php echo U('Baike/article');?>"><span class="title">训练文章列表 - Article list</span></a></li>
								<li><a href="<?php echo U('Baike/m_article');?>"><span class="title">肌肉文章列表 - Article list</span></a></li>
							</ul>
						</li> --> 
                    </ul>
                </div>

            </div>
            <div class="main-content">
                <!-- User Info, Notifications and Menu Bar -->
                <nav class="navbar user-info-navbar" role="navigation">
				<!-- Left links for user info navbar -->
                    <ul class="user-info-menu left-links list-inline list-unstyled">

                        <li class="hidden-sm hidden-xs">
                            <a href="#" data-toggle="sidebar">
                                <i class="fa-bars"></i>
                            </a>
                        </li>
                    </ul>
                </nav> 
            
     
<script type="text/javascript" src="/Public/admin/index/common.js" charset="utf-8"></script> 
<link href="/Public/admin/index/skin_0.css" rel="stylesheet" type="text/css" id="cssfile2"> 
<style class="firebugResetStyles" type="text/css" charset="utf-8">
.w50pre,.w20pre,.w25pre,.w18pre,.w17pre,.w33pre,.w34pre,.w15pre,.w16pre,.w100pre {
height:40px;
}	
</style></head>
<body>
<div class="panel panel-default">
<div class="panel-body">
<div class="page">
  <div class="info-panel">
    <dl class="member">
      <dt>
        <div class="ico"><i></i></div>
		<span class="numm"><em id="statistics_member" style="font-family:Tahoma;font-style:normal;display:block;"><?php echo ($member); ?></em></span>
        <h3>会员</h3>
        <h5>普通用户/vip人数/创业天使</h5>
      </dt>
      <dd>
        <ul>
          <li class="w50pre normal"><a href="<?php echo U('User/index');?>">本月新增<em id="statistics_week_add_member" style="font-style:normal; background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($zmember); ?></em></a></li>
          <li class="w50pre normal"><a href="<?php echo U('User/index');?>">当前在线人员<em id="statistics_cashlist" style="font-style:normal; background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($zaix); ?></em></a></li>
        </ul>
      </dd>
    </dl>
    <dl class="shop">
      <dt>
        <div class="ico"><i></i></div><span class="numm"><em id="statistics_store" style="font-style:normal;"><?php echo ($badge); ?></em></span>
        <h3>广告个数</h3>
        <h5>当前成就数量&nbsp;&nbsp;</h5>
      </dt>
      <dd>
        <ul>
          <li class="w100pre normal"><a href="<?php echo U('User/badge');?>">会员达成成就个数<em id="statistics_circle_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($numbge); ?></em></a></li>
          
        </ul>
      </dd>
    </dl>
    
    <dl class="trade">
      <dt>
        <div class="ico"><i></i></div><span class="numm"><em id="statistics_order" style="font-style:normal;"><?php echo ($zsart); ?></em></span>
        <h3>网站文章</h3>
        <h5>网站文章/百科文章</h5>
      </dt>
      <dd>
        <ul>
          <li class="w50pre normal"><a href="<?php echo U('Article/index');?>">网站文章<em id="statistics_week_add_member" style="font-style:normal; background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($art); ?></em></a></li>
          <li class="w50pre normal"><a href="<?php echo U('Baike/article');?>">百科文章<em id="statistics_cashlist" style="font-style:normal; background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($zbkart); ?></em></a></li>
        </ul>
      </dd>
    </dl>
    <dl class="operation">
      <dt>
        <div class="ico"><i></i></div><span class="numm"><em id="statistics_order" style="font-style:normal;"><?php echo ($video); ?></em></span>
        <h3>网站商品</h3>
        <h5>网站视频数量</h5>
      </dt>
      <dd>
         <ul>
          <li class="w100pre normal"><a href="<?php echo U('Baike/m_article');?>">网站视频数量<em id="statistics_circle_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($video); ?></em></a></li>
          
        </ul>
      </dd>
    </dl>

   <!--      <dl class="cms">
      <dt>
        <div class="ico"><i></i></div><span class="numm"><em id="statistics_order" style="font-style:normal;"><?php echo ((isset($special["0"]) && ($special["0"] !== ""))?($special["0"]):0); ?></em></span>
        <h3>专场</h3>
        <h5>专场审核/限时拍发布</h5>
      </dt>
      <dd>
        <ul>
          <li class="w50pre normal"><a href="<?php echo U('Auction/special');?>">待审核专场<em id="statistics_cms_article_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ((isset($special["1"]) && ($special["1"] !== ""))?($special["1"]):0); ?></em></a></li>
          <li class="w50pre normal"><a href="<?php echo U('Auction/limit_special');?>">限时拍专场<em id="statistics_cms_picture_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ((isset($special["2"]) && ($special["2"] !== ""))?($special["2"]):0); ?></em></a></li>
        </ul>
      </dd>
    </dl> -->
    <dl class="circle">
      <dt>
        <div class="ico"><i></i></div>
        <h3>网站订单</h3>
        <h5>未回复网站留言/已回复网站留言</h5>
      </dt>
      <dd>
        <ul>
          <li class="w50pre normal"><a href="<?php echo U('Mail/index');?>">未回复网站留言<em id="statistics_cms_article_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($wsuggest); ?></em></a></li>
          <li class="w50pre normal"><a href="<?php echo U('Mail/index');?>">已回复网站留言<em id="statistics_cms_picture_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ($ysuggest); ?></em></a></li>
        </ul>
      </dd>
    </dl>
  <!--           <dl class="microshop">
      <dt>
        <div class="ico"><i></i></div><span class="numm"><em id="statistics_store" style="font-style:normal;display:block;height:22px"></em></span>
        <h3>推荐系统</h3>
        <h5>推荐/刺激消费</h5>
      </dt>
      <dd>
        <ul>
          <li class="w100pre normal"><a href="<?php echo U('User/recommen');?>">当前推荐人的个数<em id="statistics_circle_verify" style="font-style:normal;background-color:#75CCEF;border-radius:10px; color:#fff;padding:2px 4px; font-size:12px;text-align:center;"><?php echo ((isset($recom) && ($recom !== ""))?($recom):0); ?></em></a></li>
          
        </ul>
      </dd>
    </dl> -->
        <dl class="system">
      <dt>
        <div class="ico"><i></i></div>
        <h3></h3>
        <div class="ps-container" id="system-info">
          <ul>
            <li>系统信息</li>
            
            <li>WEB <span>Apache/2.4.10 (Win32) OpenSSL/0.9.8zb PHP/5.3.29</span></li>
            <li>PHP <span>5.3.29</span></li>
            <li>MYSQL <span>5.5.40</span></li>
          </ul>
        <div style="left: 0px; bottom: 3px; width: 459px; display: none;" class="ps-scrollbar-x-rail"><div style="left: 0px; width: 0px;" class="ps-scrollbar-x"></div></div><div style="top: 0px; right: 3px; height: 55px; display: inherit;" class="ps-scrollbar-y-rail"><div style="top: 0px; height: 23px;" class="ps-scrollbar-y"></div></div></div>
      </dt>
      <dd>
        <ul>
          <li class="w50pre none"><a href="/" target="_blank">进入网站<sub></sub></a></li>
          <li class="w50pre none"><a href="/User/index/tc">退出后台<sub></sub></a></li>
        </ul>
      </dd>
    </dl>
    <div class="clear"></div>
    <div class="system-info"></div>
  </div>
</div>
</div>
</div>
<script>
$(".member").click(function(){
  location.href="<?php echo U('Admin/User/index');?>";
});
$(".shop").click(function(){
  location.href="<?php echo U('Admin/Ads/blist');?>";
});
$(".trade").click(function(){
  location.href="<?php echo U('Admin/Article/index');?>";
});
$(".operation").click(function(){
  location.href="<?php echo U('Admin/Goods/glist');?>";
});
$(".circle").click(function(){
  location.href="<?php echo U('Admin/Order/index');?>";
});
$(".system").click(function(){
  location.href="<?php echo U('Admin/Sys/index');?>";
});


</script>
 
			<!-- 公共footer包 -->
			
			<footer class="main-footer sticky fixed footer-type-1">
				
				<div class="footer-inner">
				
					<!-- Add your copyright text here -->
					<div class="footer-text">
						 &copy; 2016 
						<strong>Lingshow</strong> 
						河南灵秀网络科技有限公司
					</div>

					<!-- 顶置按钮  -->
					<div class="go-up">
						<a href="#" rel="go-top">
							<i class="fa-angle-up"></i>
						</a>					
					</div>				
				</div>				
			</footer>
		</div>

	</div>
	<!-- 动态弹窗，内容由JS来决定 -->
		<!-- Modal 6 (Long Modal)-->
	<div class="modal fade" id="modal-6">
		<div class="modal-dialog">
			<div class="modal-content">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">用户详细信息</h4>
				</div>
				
				<div class="modal-body">
				
					
					
				</div>
				
				<div class="modal-footer">
					<button type="button" class="btn btn-orange" data-dismiss="modal">Close</button>
					
				</div>
			</div>
		</div>
	</div>
 <!-- Gallery Modal Image -->
	<div class="modal fade" id="gallery-image-modal">
		<div class="modal-dialog">
			<div class="modal-content">
				
				<div class="modal-gallery-image">
					<img src="/Public/admin/assets/images/album-image-full.jpg" class="img-responsive" />
				</div>
				
				
				
				<div class="modal-footer modal-gallery-top-controls">
					<button type="button" class="btn btn-xs btn-white" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
        <!--5  管理员密码修改框-->
<div class="modal fade" id="modal-10">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close q55" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">密码修改</h4>
            </div>
            <label for="field-1" style="margin-top: 2%;" class="control-label">请输入原始密码：</label>
            <input type="password" name="mm0" class="form-control mm0" style="width: 50%;" placeholder="密码 密码的长度大于5位" required="">

            <div class="modal-body">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="field-1" class="control-label">请输入密码：</label>
                            <input type="password" name="mm" class="form-control mm3" placeholder="密码 密码的长度大于5位" required="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="field-2" class="control-label">再次输入：</label>
                            <input type="password" name="mm1" class="form-control mm13" placeholder="确认密码" required="">
                        </div>
                    </div>
                        <input type="hidden" name="id" value=""/>
                   
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white q55" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-info q45" onclick="submit()">确定</button>
            </div>
        </div>
    </div>
</div>
        <script>
url = window.location.pathname + window.location.search;

$("#main-menu li ul li a[href='" + url + "']").parent().addClass("active");
$("#main-menu li ul li a[href='" + url + "']").parent().parent().parent().addClass("active opened active expanded has-sub");
            function submit(){
                var oldpwd=$(":input[name='mm0']").val();
                var newpwd=$(":input[name='mm']").val();
                var repwd=$(":input[name='mm1']").val();
                if(newpwd.length<6){
                    alert("输入密码的长度不能小于6位");
                    $(":input[name='mm']").focus();
                    return ;
                }
                var patt2 = new RegExp(/^([0-9A-Za-z]*)+$/g);
                var result = patt2.test(newpwd);
                if(result==false){
                    alert("输入的密码必须为数字或字母");
                    return ;
                }
                if(newpwd!=repwd){
                    alert("请重新确认密码");
                    $(":input[name='mm1']").focus();
                    return ;
                }else{
                    $.ajax({
                        'type':'post',
                        'data':'oldpwd='+oldpwd+"&newpwd="+newpwd+"&repwd="+repwd,
                        'dataType':'json',
                        'url':"/User/Index/edt",
                        'success':function(dat){
                            alert(dat.msg)
                        }
                    })
                }
            }
        </script>

	<!-- js核心包 -->
	<script src="/Public/admin/assets/js/bootstrap.min.js"></script>
	<script src="/Public/admin/assets/js/TweenMax.min.js"></script>
	<script src="/Public/admin/assets/js/resizeable.js"></script>
	<script src="/Public/admin/assets/js/joinable.js"></script>
	<script src="/Public/admin/assets/js/xenon-api.js"></script>
	<script src="/Public/admin/assets/js/xenon-toggles.js"></script>
	<!-- 特殊加载包 -->
	<link rel="stylesheet" href="/Public/admin/assets/css/fonts/meteocons/css/meteocons.css">
		<!-- 特殊加载包/提示包 -->
	<script src="/Public/admin/assets/js/toastr/toastr.min.js"></script>
		<!-- 特殊加载包/首页样式块包 -->
	<script src="/Public/admin/assets/js/xenon-widgets.js"></script>
		<!-- 特殊加载包/模板样式通用包 -->
	<script src="/Public/admin/assets/js/xenon-custom.js"></script>
</body>
</html>