<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0057)http://www.jshgwsc.com/admin/index.php?act=login&op=login -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>登录</title>

<link href="http://www.jshgwsc.com/admin/resource/font/css/font-awesome.min.css" rel="stylesheet">

<link href="/Public/admin/login/login.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="/Public/admin/login/jquery.js"></script>

<script type="text/javascript" src="/Public/admin/login/common.js"></script>

<script type="text/javascript" src="/Public/admin/login/jquery.tscookie.js"></script>

<script type="text/javascript" src="/Public/admin/login/jquery.validation.min.js"></script>

<script src="/Public/admin/login/jquery.supersized.min.js"></script>

<script src="/Public/admin/login/jquery.progressBar.js" type="text/javascript"></script>
<script src="http://apps.bdimg.com/libs/layer/2.0/layer.js" type="text/javascript"></script>
</head>
<body>

<div class="login-layout">

  <div class="top">

   <h5><em></em></h5>
    <h2>豫商纸业后台管理中心</h2>
    <h6>网站&nbsp;&nbsp;|&nbsp;&nbsp;设计</h6>

  </div>

   <form method="post" role="form" action="<?php echo U('Index/index');?>" id="login" class="login-form fade-in-effect">
      
    <div class="lock-holder">

      <div class="form-group pull-left input-username">

        

         <label>账号</label>

          <input name="username" id="username" autocomplete="off" type="text" class="input-text" value="" required="">

          

      </div>

      <!--<i class="fa fa-ellipsis-h dot-left"></i> <i class="fa fa-ellipsis-h dot-right"></i>-->

      <div class="form-group pull-right input-password-box">

           <label>密码</label>

                <input name="passwd" id="passwd" class="input-password" autocomplete="off" type="password" value="" required="" pattern="[\S]{6}[\S]*" title="密码不少于6个字符">

      </div>

    </div>

    <div class="avatar"><img src="/Public/admin/login/admin.png" alt=""></div>


    <div class="submit"> <span>

<div class="code">

        <div class="arrow"></div>

        <div class="code-img"><img src="<?php echo U('verify');?>" name="codeimage" id="codeimage" border="0"></div>

        <a href="JavaScript:void(0);" id="hide" class="close" title="关闭"><i></i></a><a href="JavaScript:void(0);" onclick="code($(this).attr('src'))" class="change" title="看不清,点击更换验证码" src="<?php echo U('verify');?>"><i></i></a> </div>

  <script>
 
            function code(verifyimg){
			
                if( verifyimg.indexOf('?')>0){
                    $("#codeimage").attr("src", verifyimg+'&random='+Math.random());
                }else{
                    $("#codeimage").attr("src", verifyimg.replace(/\?.*$/,'')+'?'+Math.random());
                }
            }
			$(function(){
			var role="<?php echo ($pand); ?>";
			if(role==1231){
			//layer.alert("对不起，该系统你无法访问");
			layer.alert("对不起，该用户不存在");
			$("#username").focus();
			$("#username").val('');
			$("#passwd").val('');
			}
			if(role==123){
			layer.alert("对不起，你输入的账号或密码不正确，请重新输入！");
			$("#username").focus();
			
			$("#passwd").val('');
			}
			
			$("input[name=tj]").click(function(){
					var as= $("form").find('#username').val();
				 	var as1= $("form").find('#passwd').val();
				 	var as2= $("form").find('#captcha').val();
					if(!as){$('#username').attr('placeholder','用户名不能为空');
					$("#username").focus();
					
					}
					if(!as1){$('#passwd').attr('placeholder','密码不能为空');$("#passwd").focus();
					}
					if(!as2){$('#captcha').attr('placeholder','验证码不能为空');$("#captcha").focus();
					}
					if(as&&as1&&as2){					
					$.post("<?php echo U('Index/verify');?>",{
					code:as2,
					},function(data){
					if(data==1){$("form").submit();}else{
						layer.alert("验证码输入不正确");
					}
					})
					}									
					})
					})
  </script>         
            
             <input name="captcha" type="text" required="" class="input-code" id="captcha" placeholder="输入验证" pattern="[A-z0-9]{4}" title="验证码为4个字符" autocomplete="off" value="">

      </span> <span>

      
      <input name="tj" class="input-button" type="button" value="登录">

      </span> </div>

      <div class="submit2"></div>

  </form>

  <div class="bottom">

</div>

</div>
<script>
$(document).keydown(function(e){
if(e.keyCode == 13) {
$("input[name=tj]").click();
}
});
</script>




<script>

$(function(){

        $.supersized({



        // 功能

        slide_interval     : 4000,    

        transition         : 1,    

        transition_speed   : 1000,    

        performance        : 1,    



        // 大小和位置

        min_width          : 0,    

        min_height         : 0,    

        vertical_center    : 0,    

        horizontal_center  : 1,    

        fit_always         : 0,    

        fit_portrait       : 1,    

        fit_landscape      : 0,    



        // 组件

        slide_links        : 'blank',    

        slides             : [    

                                 {image : '/Public/admin/login/1.jpg'},

                                 {image : '/Public/admin/login/2.jpg'},

                                 {image : '/Public/admin/login/3.jpg'},

								 {image : '/Public/admin/login/4.jpg'},

								 {image : '/Public/admin/login/5.jpg'}

                       ]



    });

	//显示隐藏验证码

    $("#hide").click(function(){

        $(".code").fadeOut("slow");

    });

    $("#captcha").focus(function(){

        $(".code").fadeIn("fast");

    });

    //跳出框架在主窗口登录

   if(top.location!=this.location)	top.location=this.location;

    $('#user_name').focus();

    if ($.browser.msie && ($.browser.version=="6.0" || $.browser.version=="7.0")){

        window.location.href='http://www.jshgwsc.com/admin/templates/default/ie6update.html';

    }

    $("#captcha").nc_placeholder();

	//动画登录

    $('.btn-submit').click(function(e){

            $('.input-username,dot-left').addClass('animated fadeOutRight')

            $('.input-password-box,dot-right').addClass('animated fadeOutLeft')

            $('.btn-submit').addClass('animated fadeOutUp')

            setTimeout(function () {

                      $('.avatar').addClass('avatar-top');

                      $('.submit').hide();

                      $('.submit2').html('<div class="progress"><div class="progress-bar progress-bar-success" aria-valuetransitiongoal="100"></div></div>');

                      $('.progress .progress-bar').progressbar({

                          done : function() {$('#form_login').submit();}

                      }); 

              },

          300);



          });



    // 回车提交表单

    $('#form_login').keydown(function(event){

        if (event.keyCode == 13) {

            $('.btn-submit').click();

        }

    });

});                                                



</script>

<ul id="supersized" class="quality" style="visibility: visible;">
<li class="slide-0"><a target="_blank"><img src="/Public/admin/login/1.jpg" style="width: 1920px; height: 1075.2px; left: 0px; top: -61px;"></a></li>
<li class="slide-1" style="visibility: visible; opacity: 1;"><a target="_blank"><img src="/Public/admin/login/2.jpg" style="width: 1920px; left: 0px; top: -128.5px; height: 1209.6px;"></a></li>
<li class="slide-2" style="visibility: visible; opacity: 1;"><a target="_blank"><img src="/Public/admin/login/3.jpg" style="width: 1920px; height: 1209.6px; left: 0px; top: -128.5px;"></a></li>
<li class="slide-3 prevslide" style="visibility: visible; opacity: 1;"><a target="_blank"><img src="/Public/admin/login/4.jpg" style="width: 1920px; height: 1075.2px; left: 0px; top: -61px;"></a></li>
<li class="slide-4 activeslide" style="visibility: visible; opacity: 1;"><a target="_blank"><img src="/Public/admin/login/5.jpg" style="width: 1920px; left: 0px; top: -61px; height: 1209.6px;"></a></li>
</ul></body></html>