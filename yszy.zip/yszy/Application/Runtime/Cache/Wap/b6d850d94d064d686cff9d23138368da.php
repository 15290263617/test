<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
<link href="/Public/Wap/css/account.css" rel="stylesheet" type="text/css">
<style>
	.code{
		display:block;
		float: left;
		width: 22%;
		margin-left: 2%;
		border: 1px solid #eee;
		background-color: #d0d0d0;
		color: #929292;
		font-size: 14px;
		text-align: center;
		height: 40px;
		line-height: 40px;
		border-radius: 4px;
	}
</style>
<body>
<div class="container">
	<div class="top">
        <p>我的账户</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="money">
    	<p>我的账户余额为：<span><?php echo ($userinfo["money"]); ?>元</span></p>
    </div>
    <div class="cashbox">
        <form>
            <div class="row">
                <span class="fill">选择提现账户：</span>
				<select id="bank">
                   <option value="建设银行">建设银行</option>
					<option value="中国银行">中国银行</option>
					<option value="中国农业银行">中国农业银行</option>
					<option value="中国工商银行">中国工商银行</option>
					<option value="邮政储蓄银行">邮政储蓄银行</option>
					<option value="招商银行">招商银行</option>
					<option value="交通银行">交通银行</option>
					<option value="招商银行">招商银行</option>
					<option value="广发银行">广发银行</option>
                </select>
            </div>
            <div class="row">
                <span class="fill">银行卡号：</span>
                <input id="bank_number" type="text">
            </div>
            <div class="row">
                <span class="fill">真实姓名：</span>
                <input id="true_name" type="text" placeholder="持卡人姓名" >
            </div>
			<div class="row">
                <span class="fill">手机号：</span>
                <input id="phone" type="text" placeholder="填写在银行预留的手机号">
            </div>
            <div class="row">
                <span class="fill">申请提现金额：</span>
                <input id="tx_money" type="text">
            </div>
            <div class="row">
                <span class="fill">短信验证码：</span>
                <input id="code" style="width:36%;">
				<input class="code" type="text" value="获取短信验证码"/>
            </div>
            <div class="bttn">
            	<span>申请提现</span>
            </div>
        </form>
    </div>
</div>

</body>
</html>

<script>
	//获取验证码
	$(".code").click(function(){
		var phone=$("#phone").val();
		var tm=$('.code').val();
		if(!/^1[3|4|5|7|8]\d{9}$/.test(phone)){
			layer.msg("手机号不符合要求！",{icon:2});
			return false;
		}
		if(tm==0 || tm=="获取短信验证码"){
			$.ajax({
				'type':'post',
				'url':"<?php echo U('Home/Login/code');?>",
				'data':{phone:phone},
				'dataType':'json',
				'success':function(dat){
					if(dat.status==1){
						layer.alert('发送成功！');
						var countdown=60;
						gettime();
					}else{
						layer.alert('发送失败！');
						return false;
				   }
				}
			})
		}
	})
	
	//倒计时的显示
	var countdown=60;
	function gettime() {
		if (countdown == 0) {
			$(".code").removeAttr("disabled");
			$('.code').val('发送验证码');
			countdown=60;
			return; 
		} else {
			$('.code').val("重新发送(" + countdown + ")");
			$('.code').attr("disabled",true); 
			countdown--; 
		}
		 setTimeout(function(){
			gettime();
		},1000) 
	}

	//申请提现
	$(".bttn span").click(function(){
		var bank=$("#bank").val();
		var bank_number=$("#bank_number").val();
		var tx_money=$("#tx_money").val();
		var true_name=$("#true_name").val();
		var phone=$("#phone").val();
		var code=$("#code").val();
		if(bank_number==""){
			layer.msg("银行卡号不能为空！",{icon:2});
			return false;
		}else if(true_name==""){
			layer.msg("真实姓名不能为空！",{icon:2});
			return false;
		}else if(!/^1[3|4|5|7|8]\d{9}$/.test(phone)){
			layer.msg("手机号不符合要求！",{icon:2});
			return false;
		}else if(tx_money==""){
			layer.msg("提现金额不能为空！",{icon:2});
			return false;
		}else if(code==""){
			layer.msg("验证码不能为空！",{icon:2});
			return false;
		}
		$.post("<?php echo U('Home/Personal/tx');?>",{'bank':bank,'bank_number':bank_number,'tx_money':tx_money,'true_name':true_name,'phone':phone,'code':code},function(data){
			if(data.status==1){
				layer.msg("申请提现成功，请等待处理",{icon:1});
			}else if(data.status==2){
				layer.msg("余额不足",{icon:2});
			}else{
				layer.msg("申请失败",{icon:2});
			}
		});
	})
</script>