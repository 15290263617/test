<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
    <link href="/Public/Wap/css/center.css" rel="stylesheet" type="text/css">
<body>
<div class="container" style="padding-bottom:60px;">
    <div class="top">
        <p>个人中心</p>
    </div>
    <div class="bannerbox">
        <img src="/Public/Wap/images/center_02.png" class="banner">
    </div>
    <div class="dd">
        <div class="all">
            <h4>我的订单</h4>
            <a href="<?php echo U('Personal/dingdan');?>">查看全部订单</a>
        </div>
        <div class="four">
            <div class="one">
                <a href="<?php echo U('Personal/dingdan',array('status'=>1));?>">
                    <div class="imgbox"><img src="/Public/Wap/images/center_05.png"><?php if($payment_num): ?><span><?php echo ($payment_num); ?></span><?php endif; ?></div>
                    <p>待付款</p>
                </a>
            </div>
            <div class="one">
                <a href="<?php echo U('Personal/dingdan',array('status'=>2));?>"">
                    <div class="imgbox"><img src="/Public/Wap/images/center_07.png"><?php if($shipment_num): ?><span><?php echo ($shipment_num); ?></span><?php endif; ?></div>
                    <p>待发货</p>
                </a>
            </div>
            <div class="one">
                <a href="<?php echo U('Personal/dingdan',array('status'=>3));?>"">
                    <div class="imgbox"><img src="/Public/Wap/images/center_09.png"><?php if($receipt_num): ?><span><?php echo ($receipt_num); ?></span><?php endif; ?></div>
                    <p>待收货</p>
                </a>
            </div>
            <div class="one">
                <a href="<?php echo U('Personal/dingdan',array('status'=>4));?>"">
                    <div class="imgbox"><img src="/Public/Wap/images/center_11.png"><?php if($appraiset_num): ?><span><?php echo ($appraiset_num); ?></span><?php endif; ?></div>
                    <p>已完成</p>
                </a>
            </div>
        </div>
    </div>
    <div class="menu">
        <div class="mm"><a href="<?php echo U('Public/account');?>"><img src="/Public/Wap/images/center_18.png">我的账户</a></div>
        <div class="mm"><a href="<?php echo U('Personal/center_data');?>"><img src="/Public/Wap/images/center_21.png">个人资料</a></div>
        <div class="mm"><a href="center_dizhi.html"><img src="/Public/Wap/images/center_23.png">收货地址管理</a></div>
    </div>
    <div class="menu">
        <div class="mm"><a href="<?php echo U('Index/index');?>"><img src="/Public/Wap/images/center_25.png">创业天使商城<span>进入店铺</span></a></div>
    </div>
</div>
<div class="navbox">
    <ul>
        <li <?php if($wei == i): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Index/index');?>">
                <img src="/Public/Wap/images/index_45.png" class="img1">
                <img src="/Public/Wap/images/index_42.png" class="img2">
                <span>首页</span>
            </a>
        </li>
        <li <?php if($wei == a): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Angel/index');?>">
                <img src="/Public/Wap/images/index_48.png" class="img1">
                <img src="/Public/Wap/images/index_50.png" class="img2">
                <span>我要创业</span>
            </a>
        </li>
        <li>
            <a href="<?php echo U('Buycar/buycar');?>">
                <img src="/Public/Wap/images/index_54.png" class="img1">
                <img src="/Public/Wap/images/index_52.png" class="img2">
                <span>购物车</span>
            </a>
        </li>
        <li <?php if($wei == c): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Personal/center');?>">
                <img src="/Public/Wap/images/index_57.png" class="img1">
                <img src="/Public/Wap/images/index_55.png" class="img2">
                <span>个人中心</span>
            </a>
        </li>
    </ul>
</div>
</body>
</html>