<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <style>
        .bdsj{width:100%;height:100%;overflow:hidden;}
        .bdsj p{width:60%;margin:auto;font-size:14px;color:#bb2729;padding-top:100px;}
        .bdsj .input{width:60%; margin:10px auto;}
        .bdsj .input input{width:100%;height:30px;line-height:30px;}
        .bdsj .submit{margin:10px auto;width:30%;}
        .bdsj .submit input{width:100%;height:32px;background-color:#bb2729;color:#fff;border:none;border-radius:5px;margin-top:20px;cursor:pointer;}
    </style>
	<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="bdsj">
        <p>请输入PC端要绑定的手机号和密码</p>
		<form action="<?php echo U('Public/bdsjh');?>" method="post">
        <div class="input">
            <input type="text" name="phone" placeholder="请输入要绑定的手机号">
			<br><br>
			<input type="text" name="password" placeholder="请输入要绑定的密码">
        </div>
        <div class="submit">
            <input type="submit" value="确认">
        </div>
		</form>
    </div>
</body>
</html>