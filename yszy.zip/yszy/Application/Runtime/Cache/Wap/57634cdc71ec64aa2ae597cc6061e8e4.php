<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <script src="/Public/layer/layer.js"></script>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/dingdan.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
    <script>
        $(function(){
            $(".type li").click(function(){
                $(".type li").removeClass("choosed")
                $(this).toggleClass("choosed")
            });
        })
    </script>
</head>

<body>
<div class="container">
    <div class="top">
        <p>确认订单</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="dizhi">
        <h3>收货地址</h3>
        <?php if(is_array($address)): foreach($address as $key=>$v): ?><div class="biao">
                
                    <h4><span><?php echo ($v["consignee"]); ?></span><span><?php echo ($v["mobile"]); ?></span></h4>
                    <p><?php echo ($v["location_p"]); echo ($v["location_c"]); echo ($v["location_a"]); ?></p>
                    <input type="hidden" value="<?php echo ($v["address_id"]); ?>" id="kkk" />
                    <p><?php echo ($v["address_xx"]); ?></p>
                        <?php if($v['is_default'] == 1): ?><span class="default"  tid="<?php echo ($v["address_id"]); ?>">默认地址</span>
                        <?php else: ?>
                            <b　tid="<?php echo ($v["address_id"]); ?>" ><font color="red">改为默认地址</font></b><?php endif; ?>
                        <a href="/index.php/Wap/Personal/center_dizhigl/type/3/goods_id/<?php echo ($_GET['goods_id']); ?>/num/<?php echo ($_GET['num']); ?>/address_id/<?php echo ($v["address_id"]); ?>">
                            <span>修改地址</span>
                        </a>
            </div><?php endforeach; endif; ?>
<script>
   $(".biao b").click(function(){
    var add_id=$(this).attr("id");
        $.post("<?php echo U('Buycar/xiu');?>",{'add_id':add_id},function(data){
            if(data.status==1){
                alert("修改成功");
                location.href="";
            }else{
                alert("修改失败");
            }
        });

        })
</script>
        <div class="jia">
            <a href="/index.php/Wap/Personal/center_dizhiadd/type/3/goods_id/<?php echo ($_GET['goods_id']); ?>/num/<?php echo ($_GET['num']); ?>"><p><img src="/Public/Wap/images/p_add.png">添加收货地址</p></a>
        </div>
    </div>

    <div class="shangpin">
        <h3 class="dian">创业天使商城</h3>
        <div class="check">
            <div class="goodscar">
                <img src="/Public/Wap/images/buy_06.png" class="proimg">
                <div class="gtext">
                    <h4><?php echo ($goods["goods_name"]); ?></h4>
                    <p class="money">
                        <span><?php if($goods["g_type"] == 1): if($user_type == 1 || $user_type == 2): ?><b>￥<?php echo (get_goods_price($goods["goods_id"])); ?></b>
							<?php else: ?>
								<b>￥<?php echo (get_shop_price($goods["goods_id"])); ?></b><?php endif; ?>
						<?php else: ?>
							<b>￥<?php echo (get_goods_price($goods["goods_id"])); ?></b><?php endif; ?></span>
                    </p>
                </div>
            </div>
            <span class="num">x<?php echo ($num); ?></span>
        </div>
        <div class="feiyong">
            <p class="hang">商品金额：<span>¥<?php echo ($allmoney); ?></span></p>
            <p class="hang">快递费：<span>¥</span><span id="yunfei"><?php if($allmoney < 100): echo ($yunfei); ?>.00<?php else: ?>0.00<?php endif; ?></span></p>
            <input type="hidden" id="add_id"　value="<?php echo ($add_id); ?>"></input>
            <p class="hang">满<span>99</span>元免快递费</p>
            <textarea placeholder="你对订单有什么特殊说明，可以在此备注" id="order_content"></textarea>
            <p class="he">合计：<span>￥</span><span class="totalmoney">
            <?php if($allmoney<99){ echo $allmoney + $yunfei;}else{ echo $allmoney;} ?>
            </span></p>
        </div>
    </div>
    <p><font color="red">请核对以上信息，确认无误后点击“提交订单”</font></p>
    <br/>
    <br/>
    <br/>
    <br/>

</div>
<div class="submitbtn">提交订单</div>
<!--提交订单1end-->
<script>
    $(".submitbtn").click(function(){
        var add_id='<?php echo ($add_id); ?>';
        var goods_id="<?php echo ($_GET['goods_id']); ?>";
        var num='<?php echo ($num); ?>';
        var order_content=$('#order_content').val();
        var totalmoney=$(".totalmoney").text();
        var yunfei=$('#yunfei').text();
        if(add_id==""){
//            layer.msg("收货地址能不能为空，请选择收货地址",{icon:2});
            alert("收货地址能不能为空，请选择收货地址");
            return;
        }
        $.post("<?php echo U('Buycar/xiadan');?>",{'add_id':add_id,'goods_id':goods_id,'order_content':order_content,'num':num,'totalmoney':totalmoney,'yunfei':yunfei},function(data){
//            alert(data);return false;
            if(data.status==1){
//                layer.msg('下单成功',{icon:1});
                alert("下单成功");
                location.href="/Wap/Buycar/pay/order_id/"+data.order_id;
            }else{
//                layer.msg('下单失败',{icon:2});
                alert("下单失败");
            }
        });
    })
</script>
</body>
</html>