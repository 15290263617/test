<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
<style>
.bdcg7{width:100%;height:100%;overflow:hidden;}
.bdcg7 img{width:100px;height:100px;display:block;margin:30% auto 0 auto;}
.bdcg7 p{color:#ff0000;font-size:1.2em;text-align:center;padding:0% 5%;}
</style>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="bdcg7">
	<img src="/Public/Wap/images/ddbvbgh.jpg">
    <p>绑定成功！</p>
</div>
</body>
</html>