<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
    <link href="/Public/Wap/css/center.css" rel="stylesheet" type="text/css">

    <script src="/Public/Wap/js/region_select.js" type="text/jscript"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>

<style>
.bttn input {
    width: 100px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    color: #fff;
    background-color: #e8040e;
    margin: 50px auto;
    display: block;
}
</style>
<body>
<div class="container">
    <div class="top">
        <p>个人资料</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="databox">
		<form  name="myfrom" id="myform1" method="post" action="<?php echo U('Personal/head_img');?>" enctype="multipart/form-data">
        <div class="portrait">
			<?php if($userinfo['head_img']): ?><img src="<?php echo ($userinfo["head_img"]); ?>" alt="" class="photo">
			<?php else: ?>	
				<img src="/Public/Wap/images/buy_06.png" alt="" class="photo"><?php endif; ?>
            <div class="pright">
                <p>登录名：<?php echo (get_three_phone(getphone($userinfo["user_id"]))); ?></p>
                <div class="uploading">
                    <input  id="up" name="img" type="file" onchange="javascript:setlitpic();">
                    <i>修改头像</i>
                </div>
            </div>
        </div>
		</form>
		<script>
				function setlitpic(){
					document.getElementById("myform1").submit();
				}
				
			</script>
        <div class="xinxi">
			<form action="<?php echo U('Personal/center_data');?>" method="post" enctype="multipart/form-data">
                <ul class="approve">
                    <li><span><i>*</i>昵称：</span><input name="nick_name" value="<?php echo ($userinfo["nick_name"]); ?>" type="text"></li>
                    <li><span>真实姓名：</span><input name="user_name" value="<?php echo ($userinfo["user_name"]); ?>" type="text"></li>
                    <li><span><i>*</i>绑定微信：</span><input type="text"  name="weixin" value="<?php echo ($userinfo["weixin"]); ?>"></li>
                    <li><span><i>*</i>性别：</span><label><input class="sex1" type="radio" name="sex" value="1" <?php if($userinfo['sex'] == 1): ?>checked<?php endif; ?> >男</label><label><input class="sex1" type="radio" name="sex" value="2" <?php if($userinfo['sex'] == 2): ?>checked<?php endif; ?> >女</label></li>
                    <li><span><i>*</i>生日：</span>
                        <select name="year7"></select>
                        <select name="month7"></select>
                        <select name="day7"></select>
                    </li>
                    <li><span><i>*</i>居住地：</span>
                        <select name="location_p" id="location_p"></select>
                        <select name="location_c" id="location_c"></select>
                        <select name="location_a" id="location_a"></select>
                    </li>
                </ul>
                <div class="bttn">
					<input type="submit" value="提交">
                </div>
            </form>
        </div>
        <script>
            new PCAS('location_p', 'location_c', 'location_a', "<?php echo ($userinfo["location_p"]); ?>", "<?php echo ($userinfo["location_c"]); ?>", "<?php echo ($userinfo["location_a"]); ?>");
            new YMDselect('year7','month7','day7',<?php echo ($userinfo["year"]); ?>,<?php echo ($userinfo["month"]); ?>,<?php echo ($userinfo["day"]); ?>);
        </script>

    </div>
</div>
</body>
</html>