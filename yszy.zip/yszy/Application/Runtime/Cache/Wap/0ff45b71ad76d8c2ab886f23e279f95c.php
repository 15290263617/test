<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/prolist.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/Wap/css/lightbox.css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/jquery.SuperSlide.2.1.1.js"></script>
    <script src="/Public/layer/layer.js"></script>
    <script src="/Public/Wap/js/lightbox.js"></script>
    <script>
        $(function(){
            $(".buybox").click(function(){
                $(".pop").show()
            })
            $(".closebtn").click(function(){
                $(".pop").hide()
            })
        })


        $(function(){
            $(".jisuan .jia").click(function(){
                var n=$(".num").val();
                n++;
                $(".num").val(n);
            })
            $(".jisuan .jian").click(function(){
                var n=$(".num").val();
                if(n<2){
                    n==1;
                }else{
                    n--;
                    $(".num").val(n);
                }
            })
        })
    </script>
</head>

<body>
<div class="container">
    <div class="top">
        <p>创业天使</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="bannerbox" id="focus">
        <div class="banner">
            <div class="lunbo">
                <?php if(is_array($goods_img)): foreach($goods_img as $key=>$e): ?><img src="/Uploads/<?php echo ($e["img_url"]); ?>" alt=""><?php endforeach; endif; ?>
            </div>
            <div class="circle">
                <?php if(is_array($goods_img)): foreach($goods_img as $key=>$e): ?><span class="on"></span><?php endforeach; endif; ?>

            </div>
        </div>
    </div>
    <script type="text/javascript">
        TouchSlide({slideCell:"#focus",titCell:".circle span",mainCell:".banner .lunbo", effect:"left", autoPlay:true});
    </script>
    <div class="proxq">
        <h4><?php echo ($goods_xq["goods_name"]); ?></h4>
        <div class="thing">
            <p class="money"><span>¥ <?php echo ($goods_xq["market_price"]); ?></span></p>
            <div class="share"><div class="bdsharebuttonbox"><a class="bds_more" href="#" data-cmd="more"></a><a title="分享到QQ空间" class="bds_qzone" href="#" data-cmd="qzone"></a><a title="分享到新浪微博" class="bds_tsina" href="#" data-cmd="tsina"></a><a title="分享到腾讯微博" class="bds_tqq" href="#" data-cmd="tqq"></a><a title="分享到人人网" class="bds_renren" href="#" data-cmd="renren"></a><a title="分享到微信" class="bds_weixin" href="#" data-cmd="weixin"></a></div></div>
        </div>
        <script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
        </script>
        <div class="specifications">
            <div class="sp"><span>规格：</span><p><?php echo ($goods_xq["goods_discribe"]); ?><br><?php echo ($goods_xq["goods_spec"]); ?></p></div>
            <div class="sp"><span>品牌：</span><p><?php echo (get_brand_name($goods_xq["brand_id"])); ?></p></div>
            <div class="sp"><span>运费：</span><p>¥ <?php echo ($yunfei); ?></p></div>
            <div class="sp"><span>全网销量：</span><p><?php echo (get_buy_num($goods_xq["goods_id"])); ?></p></div>
        </div>
    </div>
	<style>
		.content.unidter img{max-width:100%;}
	</style>
    <div class="main">
        <div class="hd">
            <span>商品详情</span>
            <span>商品评价</span>
        </div>
        <div class="bd">
            <div class="content unidter">
                <?php echo ($goods_xq["goods_content"]); ?>
            </div>
            <div class="content">
                <ul class="comment">
                <?php if($uu == 66): if(is_array($comment)): foreach($comment as $key=>$r): ?><li>
                        <h4 class="user"><?php echo (getname($r["user_id"])); ?></h4>
                        <p class="say"><?php echo ($r["comment_content"]); ?></p>
                        <p class="xinxi"><span><?php echo ($r["comment_time"]); ?></span><span><?php echo ($r["cat_name"]); ?>,<?php echo (get_goods_spec($r["goods_id"])); ?></span></p>
                    </li><?php endforeach; endif; ?>
                <?php else: ?>
                    <li>
                        <h3 class="user"><font size="5">暂无评论</font></h3>
                    </li><?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        jQuery(".main").slide({titCell:".hd span",mainCell:".bd"});
    </script>

    <div class="column">
        <p>更多商品</p>
    </div>
    <div class="listgroup">
        <?php if(is_array($good)): foreach($good as $key=>$t): ?><div class="listitem">
                <a href="<?php echo U('Goods/proxq');?>?goods_id=<?php echo ($t["goods_id"]); ?>">
                    <img src="/Uploads/<?php echo ($t["goods_img"]); ?>" alt="" class="propic">
                    <h4 class="name"><?php echo ($t["goods_name"]); ?></h4>
                    <p class="abstract"><?php echo ($t["goods_spec"]); ?></p>
                    <p class="price"><?php echo ($t["market_price"]); ?></p>
                    <span class="buycar"><img src="/Public/Wap/images/index_32.png"></span>
                </a>
            </div><?php endforeach; endif; ?>

    </div>
    <p class="more"><a href="<?php echo U('Goods/prolist');?>?type=<?php echo ($type); ?>">查看更多</a></p>
   <div class="footer">
    <p class="link"><a href="<?php echo U('Index/index');?>">店铺主页</a>|<a href="<?php echo U('Public/help');?>">客服中心</a>|<a href="#">更多服务</a></p>
    <p class="copy">Copyright © 2015 FengQ.All Rights Reserved <br>
        豫ICP备15040786号-3 河南豫商纸业有限公司版权所有<br>
        技术支持：<a href="http://www.cccuu.com/">灵秀网络科技</a></p>
</div>

    <div class="option">
        <div class="oleft">
            <img src="/Public/Wap/images/calculate.png">
            <span class="num"><?php echo ($car_num); ?></span>
            <a href="<?php echo U('Buycar/buycar');?>" class="gopay">去结算</a>
        </div>
        <!--<a href="<?php echo U('Buycar/check');?>" class="buynow">立即购买</a>-->
        <a class="buynow">立即购买</a>
        <a class="buybox">加入购物车</a>
    </div>
    <script>




    </script>
</div>
<!--加入购物车弹出框-->
<div class="pop">
    <div class="lean_overlay"></div>
    <div id="buybox">
        <span class="closebtn"><img src="/Public/Wap/images/buy_03.png"></span>
        <div class="goods">
            <img src="/Uploads/<?php echo ($goods_img[0]["img_url"]); ?>" alt="" class="proimg">
            <div class="gtext">
                <h4><?php echo ($goods_xq["goods_name"]); ?></h4>
                <p class="money"><span>¥ <?php echo ($goods_xq["market_price"]); ?></span></p>
            </div>
            <div class="clearfix"></div>
            <div class="shu">
                <span>购买数量</span>
                <input type="hidden" id="kucun" value="<?php echo ($goods["goods_kucun"]); ?>"/>
                <input type="hidden" id="uid" value="<?php echo ($_SESSION['uid']); ?>"/>
                <div class="jisuan" id="jisuan">
                    <span class="jian"><img src="/Public/Wap/images/buy_13.png"></span>
                    <input type="text" id="number" class="num" onkeyup="shuru(this)" value="1">
                    <span class="jia"><img src="/Public/Wap/images/buy_11.png"></span>
                </div>
            </div>
            <a  class="addpro" id="addpro">加入购物车</a>
        </div>
    </div>
    <script>
        var jisuan=$("#jisuan");
        var ys_jia=jisuan.children(".jia");
        var ys_jian=jisuan.children(".jian");
        var ys_input=jisuan.children("input");
        var kucun=$('#kucun').val();
        ys_jia.click(function(){
            var n=ys_input.val();
            n++
            ys_input.val(n);
            if(n>50){
                layer.msg("库存不足",{icon:2});
                $("#number").val(kucun);
                return;
            }
        })
        ys_jian.click(function(){
            var n=ys_input.val();
            if(n>1){
                n--;
                ys_input.val(n);
            }else{
                layer.msg("数量最少是一个",{icon:2});
                return;
            }
        })
        //输入数量
        function shuru(v){
            var s_num=$(v).val();
            if(!s_num){
                $(v).val(1);
            }
            var stock=$('#kucun').val();
            if(parseInt(s_num)>parseInt(stock)){
                if(stock==0){
                    $(v).val(1);
                }else{
                    $(v).val(stock);
                }
            }
            if(parseInt(s_num)<1){
                $(v).val(1);
            }
            //正则判断
            var patt1 = new RegExp(/^([0-9]*)+$/g);
            var result = patt1.test(s_num);
            if(result==false){
                $(v).val(1);
            }

        }
        function change(){
            var number=$('#number').val();
            var kucun=$('#kucun').val();
            if(/\D/g.test(number)){
                $("#number").val('1');
                layer.msg("输入的必须是数字",{icon:2});
                return false;
            }else if(number>kucun){
                $("#number").val(kucun);
                layer.msg("库存不足",{icon:2});
                return false;
            }else if(number<1){
                $("#number").val('1');
                layer.msg("数量最少是一个",{icon:2});
                return false;
            }
        }
        //加入购物车
        $("#addpro").click(function(){
            var goods_id=<?php echo ($_GET['goods_id']); ?>;
			var num=$('#number').val();
			var uid=$("#uid").val();
			//if(uid==""){
				//layer.msg("请先登录再添加购物车",{icon:2});
				//setTimeout(function () {
					//window.location.href="<?php echo U('Wap/Buycar/buycar');?>";
				//}, 1800);
				//return;
			//}
			$.post("<?php echo U('Goods/add');?>",{'goods_id':goods_id,'num':num},function(data){
				if(data.status==1){
					layer.msg('加入购物车成功',{icon:1});
					setTimeout(function () {
                        window.location.href="/index.php/Wap/Goods/proxq.html?goods_id="+goods_id;
                    }, 1500);
				}else if(data.status==2){
					layer.msg('此商品已加入购物车',{icon:2});
				}
				else{
					layer.msg('加入购物车失败',{icon:2});
				}
			});
        })
        //立即购买
        $(".option .buynow").click(function(){
            var goods_id='<?php echo ($_GET['goods_id']); ?>';
        var num=$('#number').val();
        var uid=$("#uid").val();
        //if(uid==""){
           // layer.msg("请先登录再购买商品",{icon:2});
            //setTimeout(function () {
               //window.location.href="<?php echo U('Wap/Buycar/buycar');?>";
            //}, 1800);
            //return;
        //}
        $.post("<?php echo U('Buycar/goumai');?>",{'goods_id':goods_id,'num':num},function(data){
            if(data.status==1){
                window.location.href="/Wap/Buycar/check/goods_id/"+data.goods_id+"/num/"+data.num;
            }
        });
        })

    </script>
</div>
</body>
</html>