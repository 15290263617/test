<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
    <link href="/Public/Wap/css/center.css" rel="stylesheet" type="text/css">
    <script src="/Public/Wap/js/region_select.js" type="text/jscript"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>

<body>
<div class="container">
    <div class="top">
        <p>添加收货地址</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="databox">
        <p class="tit">添加收货地址</p>
        <div class="xinxi">
            <form action="" method="">
                <ul class="approve">
                    <li><span>收货区域：</span>
                        <select name="location_p" id="location_p"></select>
                        <select name="location_c" id="location_c"></select>
                        <select name="location_a" id="location_a"></select>
                    </li>
                    <li><span>详细地址：</span><input type="text" name="address_xx" placeholder="填写详细地址"></li>
                    <li><span>收货人：</span><input type="text" name="consignee" placeholder="填写收货人真实姓名">
                        <div class="clearfix"></div>
                        <p>收货人请使用真实姓名，方便收货！</p>
                    </li>
                    <li><span>联系方式：</span><input type="text" name="mobile" placeholder="填写联系电话"></li>
                </ul>
                <p class="set"><label><input type="checkbox">设置成默认地址</label></p>
                <div class="bttn1">
                    <span id="add">保存</span>
					<input type="hidden" id="type" value="<?php echo ($_GET['type']); ?>">
					<input type="hidden" id="car_id" value="<?php echo ($_GET['car_id']); ?>">
					<input type="hidden" id="goods_id" value="<?php echo ($_GET['goods_id']); ?>">
					<input type="hidden" id="num" value="<?php echo ($_GET['num']); ?>">
                    <span style="border:1px solid #c6c6c6; background-color:#fff; color:#333;">取消</span>
                </div>
            </form>
        </div>
        <script>
            new PCAS('location_p', 'location_c', 'location_a', '河南省', '郑州市', '金水区');
            new YMDselect('year7','month7','day7',2011,1,1);
        </script>

    </div>
</div>
</body>
</html>
			<script>
				$("#add").click(function(){
					var location_p = $('[name="location_p"]').val();
					var location_c = $('[name="location_c"]').val();
					var location_a = $('[name="location_a"]').val();
					//var address=location_p+location_c+location_a;
					var address_xx = $('[name="address_xx"]').val();
					var consignee = $('[name="consignee"]').val();
					var mobile = $('[name="mobile"]').val();
					var is_default=$('input:checkbox:checked').val();
					if(address_xx==""){
                        layer.msg("请填写详细地址！",{icon:2});
                        return;
                    }else if(address_xx.length>20){
						layer.msg("收货地址过长，请控制在20字以内！",{icon:2});
						return;
					}else if(consignee==""){
                        layer.msg("请填写收货人姓名！",{icon:2});
                        return;
                    }else if(consignee.length>10){
						layer.msg("收货人姓名过长，请控制在10字以内！",{icon:2});
						return;
					}else if(!/^1[3|4|5|7|8]\d{9}$/.test(mobile)){
                        layer.msg("联系电话不符合要求",{icon:2});
                        return;
                    }
					$.post("<?php echo U('Personal/center_dizhiadd');?>",{'location_p':location_p,'location_c':location_c,'location_a':location_a,'address_xx':address_xx,'consignee':consignee,'mobile':mobile,'is_default':is_default},function(data){
						if(data.status==1){
							layer.msg('添加成功',{icon:1});
							var type=$("#type").val();
							var car_id=$("#car_id").val();
							var num=$("#num").val();
							var goods_id=$("#goods_id").val();
								
								if(type==1){
									window.location.href="<?php echo U('Buycar/check1');?>?car_id="+car_id;
								}else if(type==2){
									window.location.href="<?php echo U('Personal/center_dizhi');?>"; 
								}else if(type==3){
									window.location.href="/index.php/Wap/Buycar/check/goods_id/"+goods_id+"/num/"+num+".html";
								}
							
						}else{
							layer.msg('添加失败',{icon:2});
						}
					});
				})
			</script>