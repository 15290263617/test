<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/prolist.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
</head>

<body>
<div class="container">
    <div class="top">
        <p>创业天使</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="bannerbox" id="focus">
        <div class="banner">
            <div class="lunbo">
                <?php if(is_array($index_banner)): $i = 0; $__LIST__ = $index_banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><img src="/Uploads/<?php echo ($val["ad_code"]); ?>" alt=""><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="circle">
                <span class="on"></span>
                <?php $__FOR_START_29196__=1;$__FOR_END_29196__=$banner_num;for($i=$__FOR_START_29196__;$i < $__FOR_END_29196__;$i+=1){ ?><span></span><?php } ?>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        TouchSlide({slideCell:"#focus",titCell:".circle span",mainCell:".banner .lunbo", effect:"left", autoPlay:true});
    </script>
    <div class="search">
        <input placeholder="商品搜索：请输入商品关键字">
    </div>
    <div class="column1">
        <img src="/Public/Wap/images/prolist_08.png">
    </div>
    <div class="listgroup">
        <?php if(is_array($list)): foreach($list as $key=>$w): ?><div class="listitem">
                <a href="<?php echo U('Goods/proxq');?>?goods_id=<?php echo ($w["goods_id"]); ?>">
                    <img src="/Uploads/<?php echo ($w["goods_img"]); ?>" alt="" class="propic">
                    <h4 class="name"><?php echo ($w["goods_name"]); ?></h4>
                    <p class="abstract"><?php echo ($w["goods_spec"]); ?></p>
                    <p class="price"><?php echo ($w["market_price"]); ?></p>
                    <span class="buycar"><img src="/Public/Wap/images/index_32.png"></span>
                </a>
            </div><?php endforeach; endif; ?>

    </div>
    <div class="footer">
    <p class="link"><a href="<?php echo U('Index/index');?>">店铺主页</a>|<a href="<?php echo U('Public/help');?>">客服中心</a>|<a href="#">更多服务</a></p>
    <p class="copy">Copyright © 2015 FengQ.All Rights Reserved <br>
        豫ICP备15040786号-3 河南豫商纸业有限公司版权所有<br>
        技术支持：<a href="http://www.cccuu.com/">灵秀网络科技</a></p>
</div>
</div>
</body>
</html>