<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
<link href="/Public/Wap/css/start.css" rel="stylesheet" type="text/css">


<body>
<div class="container">
	<div class="top">
        <p>创业天使</p>
    </div>
    <div class="package">
    	<img src="/Uploads/<?php echo ($angel_banner["ad_code"]); ?>" class="bg">
        
    </div>
    <div class="package">
    	<a href="<?php echo U('Goods/proxq',array('goods_id'=>$a_id));?>"><img src="/Uploads/<?php echo ($libao1["ad_code"]); ?>" class="bg"></a>
        
    </div>
    <div class="package">
    	<a href="<?php echo U('Goods/proxq',array('goods_id'=>$b_id));?>"><img src="/Uploads/<?php echo ($libao2["ad_code"]); ?>" class="bg"></a>
    </div>
	<?php if(is_array($libao3)): foreach($libao3 as $key=>$libao): ?><div class="package">
    	<img src="/Uploads/<?php echo ($libao["ad_code"]); ?>" class="bg">
    </div><?php endforeach; endif; ?>
</div>
<div class="navbox">
    <ul>
        <li <?php if($wei == i): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Index/index');?>">
                <img src="/Public/Wap/images/index_45.png" class="img1">
                <img src="/Public/Wap/images/index_42.png" class="img2">
                <span>首页</span>
            </a>
        </li>
        <li <?php if($wei == a): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Angel/index');?>">
                <img src="/Public/Wap/images/index_48.png" class="img1">
                <img src="/Public/Wap/images/index_50.png" class="img2">
                <span>我要创业</span>
            </a>
        </li>
        <li>
            <a href="<?php echo U('Buycar/buycar');?>">
                <img src="/Public/Wap/images/index_54.png" class="img1">
                <img src="/Public/Wap/images/index_52.png" class="img2">
                <span>购物车</span>
            </a>
        </li>
        <li <?php if($wei == c): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Personal/center');?>">
                <img src="/Public/Wap/images/index_57.png" class="img1">
                <img src="/Public/Wap/images/index_55.png" class="img2">
                <span>个人中心</span>
            </a>
        </li>
    </ul>
</div>
</body>
</html>