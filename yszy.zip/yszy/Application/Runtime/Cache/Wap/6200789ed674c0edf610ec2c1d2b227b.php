<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
</head>
<link href="/Public/Wap/css/start.css" rel="stylesheet" type="text/css">
<body>
<div class="container">
	<div class="top">
        <p>创业天使</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="title1">
    	<p><span>创业天使一</span></p>
        <img src="/Uploads/<?php echo ($libao1_xq["ad_code"]); ?>">
    </div>
    <div class="pro">
    	<ul>
			<?php if(is_array($goods)): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
            	<a href="/Wap/Goods/proxq.html?goods_id=<?php echo ($v["goods_id"]); ?>">
                    <img src="/Uploads/<?php echo ($v["goods_img"]); ?>" alt="">
                    <span class="ming"><?php echo ($v["goods_name"]); ?></span>
                    <p class="price">￥<b><?php echo ($v["market_price"]); ?></b>元</p>
                </a>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>
<div class="navbox">
    <ul>
        <li <?php if($wei == i): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Index/index');?>">
                <img src="/Public/Wap/images/index_45.png" class="img1">
                <img src="/Public/Wap/images/index_42.png" class="img2">
                <span>首页</span>
            </a>
        </li>
        <li <?php if($wei == a): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Angel/index');?>">
                <img src="/Public/Wap/images/index_48.png" class="img1">
                <img src="/Public/Wap/images/index_50.png" class="img2">
                <span>我要创业</span>
            </a>
        </li>
        <li>
            <a href="<?php echo U('Buycar/buycar');?>">
                <img src="/Public/Wap/images/index_54.png" class="img1">
                <img src="/Public/Wap/images/index_52.png" class="img2">
                <span>购物车</span>
            </a>
        </li>
        <li <?php if($wei == c): ?>class="current"<?php endif; ?> >
            <a href="<?php echo U('Personal/center');?>">
                <img src="/Public/Wap/images/index_57.png" class="img1">
                <img src="/Public/Wap/images/index_55.png" class="img2">
                <span>个人中心</span>
            </a>
        </li>
    </ul>
</div>
</body>
</html>