<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/dingdan.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
    <script src="/Public/Wap/layer/layer.js" type="text/javascript"></script>
    <!-- <script src="/Public/Home/js/base.js" type="text/javascript"></script> -->
</head>

<body>
<div class="container">
    <div class="top">
        <p>购物车</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <style type="text/css">
    #del_all{
        text-decoration: none;
    }
    </style>
    <div class="shang">
        <ul class="shop-tit">
            <li class="sh-xuan"><input type="checkbox" id="nbr" onclick="control_click()"></li>
            <li class="sh-dian">创业天使商城</li>
            <li class="sh-del" ><a href="javascript:;" id="del_all">删除</a></li>
        </ul>

        <ul class="shop-list">
        <?php if($car): if(is_array($car)): foreach($car as $key=>$y): ?><li class="xs" aid="<?php echo ($y["car_id"]); ?>" >
                <input type="checkbox" name="ck[]" carid="<?php echo ($y["car_id"]); ?>" value="<?php echo ($y["car_id"]); ?>" onclick="news_click()">
                <div class="goodscar">
                    <img src="/Uploads/<?php echo (get_goods_img($y["goods_id"])); ?>" class="proimg">
                    <div class="gtext">
                        <h4><?php echo ($y["goods_name"]); ?></h4>
                        <p class="money">
                            <span money="<?php echo ($y["xzmoney"]); ?>" id="item_<?php echo ($y["car_id"]); ?>">¥ <?php echo ($y["xzmoney"]); ?> </span>
                        </p>
                    </div>
                </div>
                <inp
                <span class="num">x<?php echo ($y["num"]); ?></span>
            </li><?php endforeach; endif; ?>
        <?php else: ?>
        <div  class="shopp_product">
          <span style="margin-left:100px;font-size:16px">
          购物车是空的！
          </span>
        </div><?php endif; ?>    
        </ul>
    </div>
</div>
<div class="gopay">
    <label><input type="checkbox" id="nbr" onclick="control_click()">全选</label>
    <p class="hejip">合计(不含运费)：<span id="All">￥ 0.00 </span></p>
    <div class="paybtn"><a class="jiesuan">去结算</a></div>
</div>
<script>
$(function(){
    $(".jiesuan").click(function(){
   var num="";
   $(".xs").each(function(){
          var p=$(this);
          if (p.children().is(":checked")) {
            num+=p.attr('aid')+'-';//以逗号连接所有选中的checkbox
          }
      });
      if (num=="") {alert("您什么都没有选择呢");return false};
 
    $.post("<?php echo U('Buycar/tijao');?>",{'num':num},function(data){
          if(data.status==1){
            window.location.href="/Index.php/Wap/Buycar/check1/car_id/"+data.car_id+".html"; 
          }
        });
  });  
});
</script>

<script type="text/javascript">
 $(function(){
    $("#del_all").click(function(){
      var num="";

      $(".xs").each(function(){
          var p=$(this);
          if (p.children().is(":checked")) {
            num+=p.attr('aid')+'-';//以逗号连接所有选中的checkbox
          }
      });
      if (num=="") {alert("您什么都没有选择呢");return false};
      var r=confirm("确认删除吗");
      if (r==true){
      }else{
        return false;
      }       
      $.post("<?php echo U('Buycar/do_delete');?>",{num:num},function(data){
        if (data>0) {alert("删除成功");location.reload()}else{
          alert("失败");alert(data);
        }
    })
  });  

});
</script>
<script type="text/javascript">
$(function(){
   totalmoney();
})
    //获取被选定的"商品复选框"的总数
    function getCheckedNum(){
        var count = 0;
        var newsEles = document.getElementsByName('ck[]');
        for(var i=0;i<newsEles.length;i++){
            if(newsEles[i].checked){
                count++;
            }
        }
        return count;
    }
    //"控制复选框"控制"商品复选框"
    function control_click(){
        var ctlBoxEle = document.getElementById('nbr');
        var newsEles = document.getElementsByName('ck[]');
        for(var i=0;i<newsEles.length;i++){
            newsEles[i].checked = ctlBoxEle.checked;
        }
        totalmoney();
    }
    //"商品复选框"控制"控制复选框"
    function news_click(){
        var ctlBoxEle = document.getElementById('nbr');
        var newsEles = document.getElementsByName('ck[]');
        ctlBoxEle.checked = newsEles.length == getCheckedNum();
        totalmoney();
    }
     function totalmoney() {
        var len = $("input[name='ck[]']:checked").length;
        if (len == 0) {
            $("#All").html('￥0.00');
        } else {
            var all_money = 0.00;
            for (i=0;i<len; i++) {
                var ids = $("input[name='ck[]']:checked").eq(i).val();
                var price = $('#item_'+ids).attr('money');
                //var num = $('#item_'+ids).val();
                 all_money += parseFloat(price);
            }
            $("#All").html('￥'+all_money.toFixed(2));
        }
    }

</script>

</body>
</html>