<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <script src="/Public/layer/layer.js"></script>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/dingdan.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
    <script>
        $(function(){
            $(".type li").click(function(){
                $(".type li").removeClass("choosed")
                $(this).toggleClass("choosed")
            });
        })
    </script>
</head>

<body>
<div class="container">
    <div class="top">
        <p>确认订单</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="dizhi">
        <h3>收货地址</h3>
        <?php if(is_array($address)): foreach($address as $key=>$v): ?><div class="biao">
               
                    <h4><span><?php echo ($v["consignee"]); ?></span><span><?php echo ($v["mobile"]); ?></span></h4>
                    <p><?php echo ($v["location_p"]); echo ($v["location_c"]); echo ($v["location_a"]); ?></p>
                    <input type="hidden" value="<?php echo ($v["address_id"]); ?>" id="kkk" />
                    <p><?php echo ($v["address_xx"]); ?></p>
					<?php if($v['is_default'] == 1): ?><span class="default"  id="<?php echo ($v["address_id"]); ?>"　tid="<?php echo ($v["address_id"]); ?>">默认地址</span>
                    <?php else: ?>
                        <b id="<?php echo ($v["address_id"]); ?>" tid="<?php echo ($v["address_id"]); ?>"><font color="red">改为默认地址</font></b><?php endif; ?>
                        <a href="/index.php/Wap/Personal/center_dizhigl/type/1/car_id/<?php echo ($_GET['car_id']); ?>/address_id/<?php echo ($v["address_id"]); ?>.html">
                            <span>修改地址</span>
                        </a>
            </div><?php endforeach; endif; ?>
<script>
$(".biao b").click(function(){
	var add_id=$(this).attr("id");
	// alert(id);
	 $.post("<?php echo U('Buycar/xiu');?>",{'add_id':add_id},function(data){
            if(data.status==1){
                alert("修改成功");
                location.href="";
            }else{
                alert("修改失败");
            }
        });
})

</script>
        <div class="jia">
            <a href="<?php echo U('Personal/center_dizhiadd',array('type'=>1,'car_id'=>I('get.car_id')));?>"><p><img src="/Public/Wap/images/p_add.png">添加收货地址</p></a>
        </div>
    </div>

    <div class="shangpin">
        <h3 class="dian">创业天使商城</h3>
        <?php if($nump): if(is_array($nump)): foreach($nump as $key=>$u): ?><div class="check">
            <div class="goodscar">
                <img src="/Public/Wap/images/buy_06.png" class="proimg">
                <div class="gtext">
                    <h4><?php echo ($u["goods_name"]); ?></h4>
                    <p class="money">
                        <span><?php if($u["g_type"] == 1): if($user_type == 1 || $user_type == 2): ?><b>￥<?php echo (get_goods_price($u["goods_id"])); ?></b>
							<?php else: ?>
								<b>￥<?php echo (get_shop_price($u["goods_id"])); ?></b><?php endif; ?>
						<?php else: ?>
							<b>￥<?php echo (get_goods_price($u["goods_id"])); ?></b><?php endif; ?></span>
                    </p>
                </div>
            </div>
            <span class="num">x<?php echo ($u["num"]); ?></span>

        </div>
        <div class="feiyong">
            <p class="hang">小计：<span>¥<?php echo ($u["xzmoney"]); ?></span></p>
        </div><?php endforeach; endif; ?>
      <?php else: ?>
      没有要确认的订单<?php endif; ?>
        <div class="feiyong">
            <!-- <p class="hang">商品金额：<span>¥<?php echo ($u["totalmoney"]); ?></span></p> -->
            <p class="hang">快递费（满<span>99</span>元免快递费）：<span>¥</span><span id="yunfei"><?php if($allmoney < 100): echo ($yunfei); ?>.00<?php else: ?>0.00<?php endif; ?></span></p>
            <!-- <p class="hang">满<span>99</span>元免快递费</p> -->
            <textarea placeholder="你对订单有什么特殊说明，可以在此备注" id="order_content"></textarea>
            <p class="he">合计：<span>￥</span><span class="totalmoney">
			<?php if($allmoney<99){ echo $allmoney + $yunfei;}else{ echo $allmoney;} ?>
            </span></p>
        </div>
    </div>
    <p><font color="red">请核对以上信息，确认无误后点击“提交订单”</font></p>
    <br/>
    <br/>
    <br/>
    <br/>

</div>
<div class="submitbtn">提交订单</div>
<!--提交订单1end-->
<script>
    $(".submitbtn").click(function(){
        var add_id='<?php echo ($add_id); ?>';
        var car_id="<?php echo ($_GET['car_id']); ?>";
        var totalmoney=$(".totalmoney").text();
        var yunfei=$('#yunfei').text();
        if(add_id==""){ 
            alert("收货地址能不能为空，请选择收货地址");
            return;
        }
	$.post("<?php echo U('Buycar/order');?>",{'add_id':add_id,'car_id':car_id,'totalmoney':totalmoney,'yunfei':yunfei},function(data){
            if(data.status==1){
                alert("下单成功");
                location.href="/Wap/Buycar/pay/order_id/"+data.order_id;
            }else{
                alert("下单失败");
            }
        });
    })
</script>
</body>
</html>