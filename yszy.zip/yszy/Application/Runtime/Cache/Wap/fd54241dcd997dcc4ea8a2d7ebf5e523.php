<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
<link href="/Public/Wap/css/dingdan.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery.SuperSlide.2.1.1.js"></script>


<body>
<div class="container">
	<div class="top">
        <p>我的订单</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="dingdan">
    <div class="hd">
        <ul>
            <li style="cursor:pointer;" status="0" <?php if($status == ''): ?>class="on"<?php endif; ?> >全部</li>
            <li style="cursor:pointer;" status="1" <?php if($status == '1'): ?>class="on"<?php endif; ?> >待付款</li> 
            <li style="cursor:pointer;" status="2" <?php if($status == '2'): ?>class="on"<?php endif; ?> >待发货</li>
            <li style="cursor:pointer;" status="3" <?php if($status == '3'): ?>class="on"<?php endif; ?> >待收货</li>
            <li style="cursor:pointer;" status="4" <?php if($status == '4'): ?>class="on"<?php endif; ?> >已完成</li>
        </ul>
    </div>
	<script>
		$(".hd ul li").click(function(){
			var status=$(this).attr('status');
			if(status==0){
				location.href="/index.php/Wap/Personal/dingdan.html"; 
			}else{
				location.href="/index.php/Wap/Personal/dingdan/status/"+status+".html"; 
			}
			

		})
	</script>
    <div class="bd">
    	<div class="change">
		<?php if($order): if(is_array($order)): $i = 0; $__LIST__ = $order;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="piece">
                <div class="title">
                    <span class="tleft">下单日期：<?php echo (date("Y-m-d",$vo["add_time"])); ?></span>
                    <span class="tright"><?php echo (get_order_status($vo["order_status"])); ?></span>
                </div>
				<?php if(is_array($vo["goods"])): $i = 0; $__LIST__ = $vo["goods"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="pro">
						<img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>">
						<div class="text">
							<p class="commodity"><?php echo (get_goods_name($v["goods_id"])); ?></p>
							<?php if($vo["order_status"] == 4): if($v["p_status"] == 1): ?><p class="shuxing"><span style="width:66px;height:24px;float:right;border-radius:5px;border:1px solid #e41839;text-align:center;font-size:14px;color:#fff;background-color:#e41839"><a style="color:#fff" href="<?php echo U('Personal/comment',array('order_id'=>$vo['order_id'],'goods_id'=>$v['goods_id']));?>">评价</a></span></p><?php endif; endif; ?>
							<p class="clearfix"></p>
							<div class="heji"><p>共<?php echo ($v["goods_number"]); ?>件商品  合计：¥<?php echo ($v["xzmoney"]); ?></p></div>
						</div>
					</div><?php endforeach; endif; else: echo "" ;endif; ?>
                <div class="caozuo">
					<?php if($vo["order_status"] == 1): ?><span class="red"><a href="<?php echo U('Buycar/pay',array('order_id'=>$vo['order_id']));?>">立即付款</a></span>
						<span class="del del1" onclick="quxiao(<?php echo ($vo["order_id"]); ?>)" >删除订单</span>
					<?php elseif($vo["order_status"] == 2): ?>
					<?php elseif($vo["order_status"] == 3): ?>
						<span style="cursor:pointer;" class="red" href="javascript:void(0)" onclick="shouhuo(<?php echo ($vo["order_id"]); ?>)">确认收货</span>
						<span class="del"><a href="<?php echo U('Personal/dingdanxq',array('order_id'=>$vo['order_id']));?>">查看详情</a></span>
					<?php elseif($vo["order_status"] == 4): ?>
						<!-- <span class="red"><a href="<?php echo U('Personal/comment',array('order_id'=>$vo['order_id']));?>">评价</a></span> -->
						<span class="del del1" onclick="quxiao(<?php echo ($vo["order_id"]); ?>)">删除订单</span><?php endif; ?>
                </div>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
		<?php else: ?>
			<div style="margin:30px 30px">您还没有订单，请先去购买商品！</div><?php endif; ?>
        </div>
    </div>
    </div>	
</div>
	<script type="text/javascript">
		//取消订单
		function quxiao(order_id){
			layer.confirm("你确定要删除吗？", {
				btn: ['确定','取消'] //按钮
			}, function(){
				$.post("<?php echo U('Personal/quxiao');?>",{'order_id':order_id},function(data){
					if(data.status==1){
						layer.msg("取消订单成功,",{icon:1});
						setTimeout(function () {
							window.location.href="/Wap/Personal/dingdan";
						}, 1500);
					}
				});
			});
		}
		//确认收货
		function shouhuo(order_id){
			layer.confirm("你确定要删除吗？", {
				btn: ['确定','取消'] //按钮
			}, function(){
				$.post("<?php echo U('Personal/shouhuo');?>",{'order_id':order_id},function(data){
					if(data.status==1){
						layer.msg("确认收货成功,",{icon:1});
						setTimeout(function () {
							window.location.href="/Wap/Personal/dingdan/status/4.html";
						}, 1500);
						
					}
				});
			});
		}
	</script>
</body>
</html>