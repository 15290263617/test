<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,JavaScript">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>创业天使</title>
    <link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
    <link href="/Public/Wap/css/dingdan.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Public/Wap/js/TouchSlide.1.1.source.js"></script>
    <script>
        $(function(){
            $(".type li").click(function(){
                $(".type li").removeClass("choosed")
                $(this).toggleClass("choosed")
            });
        })
    </script>
</head>
<body>
<div class="container">
    <div class="shangpin">
        <h3 class="dian">订单提交成功，现在只差最后一步啦！</h3>
        <div class="check">
            <div class="goodscar">
                <div class="gtext">
                    <h4><font size="4.5">订单金额：</font>￥<font size="4" color="red"><?php echo ($orderinfo["order_money"]); ?></font></h4>
      
                    <h4><font size="4.5">运费：</font>￥<font size="4" color="red"><?php echo ($orderinfo["yunfei"]); ?></font></h4>
                </div>
            </div>
        </div>
    </div>
    <div class="zhifu">
        <p class="choose">支付方式：</p>
        <ul class="type">
            <li attr="y">
                <div class="yue">
                    <h4>账户余额</h4>
                    <p>¥<?php echo ($userinfo["money"]); ?></p>
                </div>
                <div class="ttext">
                    <h5>账户余额支付</h5>
                    <p>这里的钱都是我赚到的</p>
                </div>
            </li>
            <li attr="z">
                <img src="/Public/Wap/images/type1.png">
                <div class="ttext">
                    <h5>支付宝支付</h5>
                    <p>推荐有支付宝账号的用户使用</p>
                </div>
            </li>
            <li attr="w">
                <img src="/Public/Wap/images/type2.png">
                <div class="ttext">
                    <h5>微信支付</h5>
                    <p>推荐安装微信5.0及以上版本的用户使用</p>
                </div>
            </li>
            <li attr="y">
                <img src="/Public/Wap/images/type3.png">
                <div class="ttext">
                    <h5>在线支付</h5>
                    <p>推荐有支付宝账号的用户使用</p>
                </div>
            </li>
        </ul>
    </div>
</div>
<input type="hidden" value="" id="type"/>
<div class="submitbtn">确认支付</div>
</body>
</html>
<script>
	$(".type li").click(function(){
		var type=$(this).attr("attr");
		$("#type").val(type);
	})
	
	$(".submitbtn").click(function(){
		var type=$("#type").val();
		var order_id=<?php echo ($_GET['order_id']); ?>;
		if(type=='w'){
			location.href="/Wap/WxPay/js_api_call/order_id/"+order_id;
		}
	})
</script>