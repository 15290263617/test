<?php if (!defined('THINK_PATH')) exit();?>

<div style="height:800px;">
    <div align="center" id="qrcode" style="font-size:18px;color:green;padding:50px 0 0 0"></div>
    <div align="center" id=tupian>
        <p style="color:#ff0000;font-weight:bold;font-size:16px;">订单金额：￥<?php echo ($total_fee); ?></p>
		<img src="/Public/Home/images/weixin.jpg">
    </div>
	<style>
		#tupian img{width:200px;height:140px;}
	</style>
	<script>
		$(function(){
			var x=$("#qrcode");
			var xq=x.find("img");
			xq.width(300);
			xq.height(300);
		})
	</script>
</div>
  

    <script src="/Public/js/qrcode.js"></script>
    <script>
        if(<?php echo $unifiedOrderResult["code_url"] != NULL; ?>)
        {
            var url = "<?php echo $code_url;?>";
            //参数1表示图像大小，取值范围1-10；参数2表示质量，取值范围'L','M','Q','H'
            var qr = qrcode(10, 'M');
            qr.addData(url);
            qr.make();
            var wording=document.createElement('p');
            wording.innerHTML = "微信安全支付，请扫我";
            var code=document.createElement('DIV');
            code.innerHTML = qr.createImgTag();
            var element=document.getElementById("qrcode");
            element.appendChild(wording);
            element.appendChild(code);
        }
    </script>