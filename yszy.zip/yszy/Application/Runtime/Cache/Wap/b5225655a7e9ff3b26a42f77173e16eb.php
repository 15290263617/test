<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
	<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
</head>
<script>
$(function(){
  wx.config({
    debug:false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: '<?php echo $signPackage["timestamp"];?>',
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline']
  });
})
</script>
<script> 
wx.ready(function () {
var uid=<?php echo (session('uid')); ?>;
   wx.onMenuShareTimeline({
        title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid, 
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
    });
   wx.onMenuShareAppMessage({

    title: '创业天使',
        link: 'http://www.chuangyepaper.com/index.php/Wap/Band/index?gtype=1&tjid='+uid,
        desc: '创业天使商城',
        imgUrl: 'http://www.chuangyepaper.com/Uploads/ads/2016-04-25/571dea8b359b7.jpg',
        success: function () {
            layer.alert('分享成功了');
            
        }
        //cancel: function () {
            //alert('分享失败');
        //}
});
});

</script>
<link href="/Public/Wap/css/account.css" rel="stylesheet" type="text/css">

<script>
$(function(){
	$(".type li").click(function(){
		$(".type li").removeClass("choosed")
		$(this).toggleClass("choosed")
	});
})
</script>


<body>
<div class="container">
	<div class="top">
        <p>我的账户</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="money">
    	<p>我的账户余额为：<span><?php echo ($userinfo["money"]); ?>元</span></p>
    </div>
    <div class="rechargebox">
    	<div class="row">
        	<span>请输入充值金额：</span>
            <input type="text" id="money"/>
        </div>
        <p class="choose">请选择支付方式：</p>
        <ul class="type">
        	<li attr="z">
                <img src="/Public/Wap/images/type1.png">
                <div class="ttext">
                    <h5>支付宝支付</h5>
                    <p>推荐有支付宝账号的用户使用</p>
                </div>
            </li>
        	<li attr="w">
                <img src="/Public/Wap/images/type2.png">
                <div class="ttext">
                    <h5>微信支付</h5>
                    <p>推荐安装微信5.0及以上版本的用户使用</p>
                </div>
            </li>
        	<li attr="y">
                <img src="/Public/Wap/images/type3.png">
                <div class="ttext">
                    <h5>在线支付</h5>
                    <p>推荐有支付宝账号的用户使用</p>
                </div>
            </li>
        </ul>
        <div class="bttn">
		<input type="hidden" value="" id="type"/>
        <span class="submitbtn">充值</span>
        </div>
    </div>
</div>
</body>
</html>
<script>
	$(".type li").click(function(){
		var type=$(this).attr("attr");
		$("#type").val(type);
	})
	
	$(".submitbtn").click(function(){
		var type=$("#type").val();
		var money=$("#money").val();
		if(money==""){
			layer.msg("充值金额不能为空",{icon:2});
			return;
		}
		if(type=='w'){
			$.post("<?php echo U('Personal/cz');?>",{'money':money},function(data){
				window.location.href="/Wap/Wxcz/js_api_call/cz_sn/"+data.cz_sn;
			});
		}
	})
</script>