<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML,CSS,JavaScript">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>创业天使</title>
<link href="/Public/Wap/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/Public/Wap/css/base.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/Public/Wap/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/Public/Wap/js/bootstrap.min.js"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>
	<script src="/Public/layer/layer.js"></script>
</head>
    <link href="/Public/Wap/css/center.css" rel="stylesheet" type="text/css">
    <script src="/Public/Wap/js/region_select.js" type="text/jscript"></script>
    <script src="/Public/Wap/js/YMDClass.js" type="text/jscript"></script>

<body>
<div class="container">
    <div class="top">
        <p>收货地址管理</p>
        <a href="javascript:history.go(-1)" class="goback"><img src="/Public/Wap/images/prolist_03.png"></a>
    </div>
    <div class="databox">
        <ul>
		<?php if(is_array($address)): $i = 0; $__LIST__ = $address;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li class="piece">
                <a href="<?php echo U('Personal/center_dizhigl',array('type'=>2,'address_id'=>$v['address_id']));?>">
                    <p class="name">
                        <span class="span1"><?php echo ($v["consignee"]); ?></span>
                        <span class="span2"><?php echo ($v["mobile"]); ?></span>
                    </p>
                    <p class="add"><?php if($v["is_default"] == 1): ?><span>[默认]</span><?php endif; echo ($v["location_p"]); echo ($v["location_c"]); echo ($v["location_a"]); echo ($v["address_xx"]); ?></p>
                </a>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="jia">
        <a href="<?php echo U('Personal/center_dizhiadd',array('type'=>2));?>"><p><img src="/Public/Wap/images/p_add.png">添加收货地址</p></a>
    </div>
</div>
</body>
</html>