<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 <link rel="stylesheet" type="text/css" href="/Public/home/css/personal_center.css">
<script src="/Public/home/js/region_select.js" type="text/javascript"></script>
<script src="/Public/home/js/YMDClass.js" type="text/javascript"></script>
<script src="/Public/home/js/center.js"></script>
<!--我的资料-->
<div class="personal_center">
		<div class="pc_left" id="pc_left">
  		<ul>
        	<li style="background-image:url(/Public/home/images/li1.png)"><a>账户设置</a>
            	<dl class="sub_nav">
                	<dd  <?php if($wei == i): ?>class="currt0"<?php endif; ?>><a <?php if($wei == i): ?>class="currt1"<?php endif; ?>  href="<?php echo U('Personal/index');?>">我的资料</a></dd>
                    <dd <?php if($wei == m): ?>class="currt0"<?php endif; ?>><a <?php if($wei == m): ?>class="currt1"<?php endif; ?> href="<?php echo U('personal/mmxg');?>">修改密码</a></dd>
                </dl>
            </li>
            <li <?php if($wei == o || $wei == p || $wei == s || $wei == r || $wei == e): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li2.png)"><a <?php if($wei == o): ?>class="currt1"<?php endif; ?> href="<?php echo U('Myorder/index');?>">我的订单</a></li>
            <li <?php if($wei == a): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li3.png)"><a <?php if($wei == a): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/address');?>">收货地址</a></li>
            <li <?php if($wei == z): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/count2.png)"><a <?php if($wei == z): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/account');?>">我的账户</a></li>
        </ul>
    </div>
    <div class="pc_right">
    	<div class="datum">
        	<h2>我的资料</h2>
            <div class="datum_title">
            	<a class="xsj" href="<?php echo U('Personal/index');?>" style="color:#010101;">基本资料<i></i></a>
                <a href="<?php echo U('Personal/txsz');?>">头像设置</a>
            </div>
            <div class="userName">
                <div class="images">
				<?php if($userinfo['head_img']): ?><img src="<?php echo ($userinfo["head_img"]); ?>" alt="头像">
				<?php else: ?>
					<img src="/Public/home/images/preview2.jpg" alt="头像"><?php endif; ?>
				</div>
                <span>登录名：<?php echo (get_three_phone(getphone($userinfo["user_id"]))); ?></span>
            </div>
            <form onsubmit="return false;" id="xiugai">
            <ul class="datum_con">
            	<li><b>昵称：</b><input type="text" name="nick_name" value="<?php echo ($userinfo["nick_name"]); ?>"></li>
                <li><b>真实姓名：</b><input type="text" name="user_name" value="<?php echo ($userinfo["user_name"]); ?>"></li>
				<input type="hidden" id="ttype" value="<?php echo ($_SESSION['home']['type']); ?>">
                <li><b>绑定微信：</b><!-- <input type="text" name="weixin" value="<?php echo ($userinfo["weixin"]); ?>"><p style="color:#959595;font-size:12px;clear: both;padding-left:194px;background:url('images/xxxxx.png') no-repeat 170px 3px;"> --><?php if($_SESSION['home']['type']==1): ?><img style="width:120px;height:120px;float:left;" src="http://qr.topscan.com/api.php?&text=http://www.chuangyepaper.com/index.php/Home/Public/bdsjh?phone=<?php echo ($_SESSION['home']['phone']); ?>"><span style="display:block;width:160px;float:left;padding:60px 0 0 0;">请打开微信扫一扫<br>绑定微信号</span><?php else: ?>
				<span>您的微信已绑定</span><?php endif; ?></li>
                <li><b>性别：</b><p><input class="d1" type="radio" name="sex" value="1" <?php if($userinfo['sex'] == 1): ?>checked<?php endif; ?> >男</p><p><input class="d1" type="radio" name="sex" value="2" <?php if($userinfo['sex'] == 2): ?>checked<?php endif; ?> >女</p></li>
                <li><b>生日：</b>
                	<select name="year"></select>
                    <select name="month"></select>
                    <select name="day"></select>
                </li>
                <li><b>居住地：</b>
                	<select name="location_p" id="location_p"></select>
                    <select name="location_c" id="location_c"></select>
                    <select name="location_a" id="location_a"></select>
                </li>
                <li class="tijiao"><input type="submit" value="提交"></li>
            </ul>
            </form>
    <script type="text/javascript">
		new PCAS('location_p', 'location_c', 'location_a', "<?php echo ($userinfo["location_p"]); ?>", "<?php echo ($userinfo["location_c"]); ?>", "<?php echo ($userinfo["location_a"]); ?>");
		new YMDselect('year','month','day',<?php echo ($userinfo["year"]); ?>,<?php echo ($userinfo["month"]); ?>,<?php echo ($userinfo["day"]); ?>);
	</script>
        </div>
    </div>
</div>
	<script type="text/javascript">
		$(function(){
			var type=$("#ttype").val();
			if(type==1){
				int=self.setInterval(function typesel(){
					
					$.post(
						"<?php echo U('Personal/typesel');?>",
						{'type':1},
						function(data){
							if(data.status==2){
								window.location.reload();//刷新当前页面.
							}
						}                   
					)
				}
				,2000);
			}
		})

		$(".tijiao").click(function(){
			var nick_name = $('[name="nick_name"]').val();
			var user_name = $('[name="user_name"]').val();
			var weixin = $('[name="weixin"]').val();
			var sex = $('[name="sex"]:checked').val();
			var year = $('[name="year"]').val();
			var month = $('[name="month"]').val();
			var day = $('[name="day"]').val();
			var location_p = $('[name="location_p"]').val();
			var location_c = $('[name="location_c"]').val();
			var location_a = $('[name="location_a"]').val();
			//var birth=year+"-"+month+"-"+day;
			//var address=location_p+"-"+location_c+"-"+location_a;
			//alert(address);return;
			$.post("<?php echo U('Personal/index');?>",{'nick_name':nick_name,'user_name':user_name,'weixin':weixin,'sex':sex,'year':year,'month':month,'day':day,'location_p':location_p,'location_c':location_c,'location_a':location_a},function(data){
				if(data.status==1){
					layer.msg('修改成功',{icon:1});
				}else{
					layer.msg('修改失败',{icon:2});
				}
			});
		})
	</script>



 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>