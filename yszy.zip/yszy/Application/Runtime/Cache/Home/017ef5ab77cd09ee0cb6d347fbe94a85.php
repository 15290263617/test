<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 
<link rel="stylesheet" type="text/css" href="/Public/home/css/personal_center.css">

<script src="/Public/home/js/YMDClass.js" type="text/jscript"></script>

<script src="/Public/home/js/center.js" type="text/jscript"></script>

<!--我的资料-->
<div class="dqwz">当前位置：<a href="<?php echo U('Personal/index');?>">个人中心</a> > <a href="<?php echo U('Myorder/index');?>">我的订单</a> > 
		<?php if($orderinfo["order_status"] == 1): ?><a href="<?php echo U('Myorder/payment');?>">待付款</a>
		<?php elseif($orderinfo["order_status"] == 2): ?>
			<a href="<?php echo U('Myorder/shipment');?>">待发货</a>
		<?php elseif($orderinfo["order_status"] == 3): ?>
			<a href="<?php echo U('Myorder/receipt');?>">待收货</a>
		<?php elseif($orderinfo["order_status"] == 4): ?>
			<a href="<?php echo U('Myorder/appraise');?>">已完成</a><?php endif; ?>
</div>
<div class="stay">
	<div class="stay_left">
    	<dl class="lineItem">
        	<dd>订单号:<p>   <?php echo ($orderinfo["order_sn"]); ?></p></dd>
            <dd>下单时间:<p>   <?php echo (date("Y-m-d H:i:s",$orderinfo["add_time"])); ?></p></dd>
            <dd>支付方式:<p style="font-family:Microsoft YaHei">线上支付</p></dd>
        </dl>
        <dl class="cost">
            <dd>运费:<b><font>￥</font>20</b></dd>
            <dd>实付款:<i><?php echo ($orderinfo["order_money"]); ?><font>￥</font></i></dd>
        </dl>
        <dl class="address">
        	<dd>收货人:<b><?php echo ($orderinfo["consignee"]); ?></b></dd>
            <dd>手机号:<b><?php echo (get_four_phone($orderinfo["phone"])); ?></b></dd>
            <dd>收货地址:<b><?php echo ($orderinfo["address"]); echo ($orderinfo["address_xx"]); ?></b></dd>
        </dl>
    </div>
    <div class="stay_right">
		<?php if($orderinfo["order_status"] == 1): ?><div class="state" style="background-image:url(/Public/home/images/state11.png)"></div>
			 <div class="state_con">
				 <h6>当前订单状态：订单已提交，等待您付款</h6>
				 <!-- <p>您还剩余    <span class="remaining"><span>4</span>天<span>13</span>时<span>9</span>分<span>40</span>秒 </span>完成本次交易的付款，逾期未付款，订单将自动取消。</p> -->
				 <br><br>
				 <a class="ljfk" href="<?php echo U('Goods/fukuan',array('order_id'=>$orderinfo['order_id']));?>">立即付款</a>
				 <a class="qxdd" href="javascript:void(0)" onclick="quxiao(<?php echo ($orderinfo["order_id"]); ?>)">取消订单</a>
			 </div>
		<?php elseif($orderinfo["order_status"] == 2): ?>
			 <div class="state" style="background-image:url(/Public/home/images/state22.png)"></div>
			 <div class="state_con">
				 <h6>当前的订单状态:配货中、请耐心等待</h6>
				 <p>若您对商品有任何疑问或不解，可以联系客服<a class="state_con_qq" href="#"></a>或拨打客服电话：<i>400-888-6666</i></p>
			 </div>
		<?php elseif($orderinfo["order_status"] == 3): ?>
			 <div class="state" style="background-image:url(/Public/home/images/state33.png)"></div>
			 <div class="state_con">
				 <h6 class="h6">当前订单状态：卖家已发货</h6>
				 <p class="p1">1.如果没有收到货，或收到货后出现问题，您可以联系卖家协商解决。<i>400-666-8888</i></p>
				 <p class="p2">2.如果卖家没有履行应尽的承诺，您可以“投诉维权”</p>
				 <a class="qrsh">确认收货</a>
			 </div>
		 <?php elseif($orderinfo["order_status"] == 4): ?>
			 <div class="state" style="background-image:url(/Public/home/images/state55.png)"></div>
			 <div class="state_con">
       		 <h6 class="h6">当前订单状态：已完成</h6>
             <p class="p1">1.如果没有收到货，或收到货后出现问题，您可以联系卖家协商解决。<i>400-666-8888</i></p>
             <p class="p2">2.如果卖家没有履行应尽的承诺，您可以“投诉维权”</p>
			 <p style="color:#0ab1ca;margin-top:20px;">快去评论一下吧</p>
         </div><?php endif; ?>
        <script>
		//取消订单
			function quxiao(order_id){
				$.post("<?php echo U('Myorder/quxiao');?>",{'order_id':order_id},function(data){
					if(data.status==1){
						layer.msg("取消订单成功,",{icon:1});
						window.location.href="/Home/Myorder/index";
					}
				});
			}
		</script>

         <div class="merchandise">
         	<table style="width:100%;">
            	<tr>
                	<th style="width:40%">商品信息</th>
                    <th style="width:20%">售价</th>
                    <th style="width:20%">数量</th>
                    <th style="width:20%">实付金额</th>
					<?php if($orderinfo["order_status"] == 4): ?><th style="width:20%">评价</th><?php endif; ?>
                </tr>
				<?php if(is_array($orderinfo["goods"])): $i = 0; $__LIST__ = $orderinfo["goods"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                	<td class="t1"><a href="productxq.html">
                    	<img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>" alt="">
                        <p><?php echo ($v["goods_name"]); ?><span><?php echo (get_goods_spec($v["goods_id"])); ?></span></span></p>
                    </a></td>
                    <td><b>¥<?php echo (get_goods_price($v["goods_id"])); ?></b></td>
                    <td><b><?php echo ($v["goods_number"]); ?></b></td>
                    <td><i>¥<?php echo ($v["xzmoney"]); ?></i></td>
					<?php if($orderinfo["order_status"] == 4): if($v["p_status"] == 1): ?><td><a class="appraise" style="display:inline-block;width:95px;height:29px;border:solid 1px #e5e5e5;text-align:center;line-height:29px;background-color:#fafafa;margin-top:10px;color:#333333;" href="<?php echo U('Myorder/appraise_xq',array('order_id'=>$orderinfo['order_id'],'goods_id'=>$v['goods_id']));?>">评价</a></td>
					<?php else: ?>
					<td>已评价<td/><?php endif; endif; ?>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
            </table>
         </div>
    </div>
</div>
 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>