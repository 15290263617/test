<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 


<!--产品详情start-->
<div class="productxq_nav">
    <a href="<?php echo U('Index/index');?>">首页</a> >
    <a href="<?php echo U('Goods/goods',array('cate_id'=>$goods['cat_id']));?>"><?php echo (get_cate_name($goods["cat_id"])); ?></a> >
    <a href=""><?php echo (get_enum_name($goods["enum_id"])); ?></a>
</div>
<div class="productxq">
    <div class="productxq_left">
        <div class="p_l_top">
            <div class="p_l_top_left">
                <div class="view" id="view"><img src="/Uploads/<?php echo ($goods_img["0"]["img_url"]); ?>" alt="窗口图片"></div>
                <div class="view_list">
                    <ul>
					<?php if(is_array($goods_img)): $i = 0; $__LIST__ = $goods_img;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><li><img src="/Uploads/<?php echo ($val["img_url"]); ?>" alt="图片列表"></li><?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </div>
            <div class="p_l_top_right">
                <h2><?php echo ($goods["goods_name"]); ?></h2>
                <div class="jiage"><p>价格：<i>￥<?php echo ($goods["market_price"]); ?></i> </p>
				<?php if($goods["g_type"] == 1): ?><p class="cpx">创业天使价格：<i>¥<?php echo (get_shop_price($goods["goods_id"])); ?></i></p><?php endif; ?>
				</div>
				<dl>
                    <dd>
                        <b>配送范围</b>
                        <p><?php echo ($goods["pfanw"]); ?></p>
                    </dd>
                    <dd>
                        <b>品&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;牌</b>
                        <p><?php echo (get_brand_name($goods["brand_id"])); ?></p>
                    </dd>
                    <dd>
                        <b>数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;量</b>
						<input type="hidden" id="kucun" value="<?php echo ($goods["goods_kucun"]); ?>"/>
						<input type="hidden" id="uid" value="<?php echo ($_SESSION['home']['uid']); ?>"/>
                        <div class="ys_number" id="ys_number">
                            <a class="jian"></a>
                            <input type="text" id="number" onkeyup="shuru(this)" value="1">
                            <a class="jia"></a>
                        </div>
                    </dd>
                </dl>
                <div class="handle">
                    <a class="buy">立即购买</a>
                    <a class="join">加入购物车</a>
                </div>
				<script>
					var ys_number=$("#ys_number");
					var ys_jia=ys_number.children(".jia");
					var ys_jian=ys_number.children(".jian");
					var ys_input=ys_number.children("input");
					var kucun=$('#kucun').val();
					ys_jia.click(function(){
						var n=ys_input.val();
						n++
						ys_input.val(n);
						if(n>50){
							layer.msg("库存不足",{icon:2});
							$("#number").val(kucun);
							return;
						}
					})
					ys_jian.click(function(){
						var n=ys_input.val();
						if(n>1){
							n--;
							ys_input.val(n);
						}else{
							layer.msg("数量最少是一个",{icon:2});
							return;
						}
					})
					//输入数量
					function shuru(v){
						var s_num=$(v).val();
						if(!s_num){
							$(v).val(1);
						}
						var stock=$('#kucun').val();
						if(parseInt(s_num)>parseInt(stock)){
							if(stock==0){
								$(v).val(1);
							}else{
								$(v).val(stock);
							}
						}
						if(parseInt(s_num)<1){
							$(v).val(1);
						}
						//正则判断
						var patt1 = new RegExp(/^([0-9]*)+$/g);
								var result = patt1.test(s_num);
								if(result==false){
									$(v).val(1);
								}
					   
					}
					function change(){
						var number=$('#number').val();
						var kucun=$('#kucun').val();
						if(/\D/g.test(number)){
							$("#number").val('1');
							layer.msg("输入的必须是数字",{icon:2});
							return false;
						}else if(number>kucun){
							$("#number").val(kucun);
							layer.msg("库存不足",{icon:2});
							return false;
						}else if(number<1){
							$("#number").val('1');
							layer.msg("数量最少是一个",{icon:2});
							return false;
						}
					}
					//加入购物车
					$(".handle .join").click(function(){
						var goods_id=<?php echo ($_GET['goods_id']); ?>;
						var num=$('#number').val();
						var uid=$("#uid").val();
						if(uid==""){
							layer.msg("请先登录再添加购物车",{icon:2});
							setTimeout(function () {
                                window.location.href="<?php echo U('Login/login');?>";
                            }, 1800);
							return;
						}
						$.post("<?php echo U('Goods/add');?>",{'goods_id':goods_id,'num':num},function(data){
							if(data.status==1){
								$(".tishibox").show();
								//window.location.href="<?php echo U('Goods/car');?>";
							}else if(data.status==2){
								$(".atishibox").show();
							}else{
								layer.msg('加入购物车失败',{icon:2});
							}
						});
					})
					//立即购买
					$(".handle .buy").click(function(){
						var goods_id=<?php echo ($_GET['goods_id']); ?>;
						var num=$('#number').val();
						var uid=$("#uid").val();
						if(uid==""){
							layer.msg("请先登录再购买商品",{icon:2});
							setTimeout(function () {
                                window.location.href="<?php echo U('Login/login');?>";
                            }, 1800);
							return;
						}
						$.post("<?php echo U('Goods/goumai');?>",{'goods_id':goods_id,'num':num},function(data){
							if(data.status==1){
								window.location.href="/Home/Goods/buy/goods_id/"+data.goods_id+"/num/"+data.num;
							}
						});
					})
				</script>
                <div class="share">
                    <span>分享：</span>
                    <div class="bdsharebuttonbox">
                        <a href="#" class="bds_more" data-cmd="more"></a>
                        <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                        <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                        <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
                        <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
                        <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="p_l_bottom" id="p_l_bottom">
            <ul class="p_l_b_title">
                <li class="this">图文详情<b></b></li>
                <li>用户评价<i>（<?php echo ($comment_num); ?>）</i><b></b></li>
            </ul>
            <div class="nr1 nr">
                <?php echo ($goods["goods_content"]); ?>
            </div>
            <div class="nr2 nr">
                <div class="nr2_top" id="nr2_top">
                    <dl>
                        <dt>商品评价</dt>
                        <dd class="d1"><span></span></dd>
                        <dd class="d2"><i all="<?php echo ($comment_num); ?>" hp="<?php echo ($good_num); ?>">00%</i>好评</dd><!--all为所有评价，hp为好评的数量，百分比JS自动计算出来。-->
                        <dd class="d3">共<b><?php echo ($comment_num); ?></b>条评论</dd>
                    </dl>
                </div>
                <div class="reviews">
                    <ul class="reviews_title" id="reviews_title">
                        <li class="this">全部评价<i>（<?php echo ($comment_num); ?>）</i></li>
                        <li>好评<i>（<?php echo ($good_num); ?>）</i></li>
                        <li>中评<i>（<?php echo ($middle_num); ?>）</i></li>
                        <li>差评<i>（<?php echo ($bad_num); ?>）</i></li>
                    </ul>
                    <div class="reviews_con">
                        <div class="table1">
                        <table cellpadding="0" cellspacing="0">
                            <tr>
                                <th class="t1">评价心得</th>
                                <th class="t2">满意度</th>
                                <th class="t2">商品信息</th>
                                <th class="t2">评价用户</th>
                            </tr>
							<?php if(is_array($goods_comment)): $i = 0; $__LIST__ = $goods_comment;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><tr>
                                <td class="t1"><?php echo ($val["comment_content"]); ?>
								<div class="images">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                        </div>
								</td>
                                <td class="t2">
                                    <div class="pingfen" rel=<?php echo ($val["star"]); ?>><span></span></div><!--rel为单个商品评分。只有1-5分。超出则return；-->
                                </td>
                                <td class="t2">
                                    <b><?php echo (get_goods_name($val["goods_id"])); ?></b>
                                    <b><?php echo (get_goods_spec($val["goods_id"])); ?></b>
                                </td>
                                <td class="t2">
                                    <b><?php echo (getname($val["user_id"])); ?></b>
                                    <b><?php echo (date("Y-m-d H:i:s",$val["comment_time"])); ?></b>
                                </td>
                            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                        </table>
                        
                    </div>
                        <div class="table1">
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <th class="t1">评价心得</th>
                                    <th class="t2">满意度</th>
                                    <th class="t2">商品信息</th>
                                    <th class="t2">评价用户</th>
                                </tr>
								<?php if(is_array($good_comment)): $i = 0; $__LIST__ = $good_comment;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                   <td class="t1">
                                        <?php echo ($v["comment_content"]); ?>
                                        <div class="images">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                        </div>
                                    </td>
                                    <td class="t2">
                                        <div class="pingfen" rel=<?php echo ($v["star"]); ?>><span></span></div>
                                    </td>
                                    <td class="t2">
                                        <b><?php echo (get_goods_name($v["goods_id"])); ?></b>
										<b><?php echo (get_goods_spec($v["goods_id"])); ?></b>
                                    </td>
                                    <td class="t2">
                                         <b><?php echo (getname($v["user_id"])); ?></b>
										<b><?php echo (date("Y-m-d H:i:s",$v["comment_time"])); ?></b>
                                    </td>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                            </table>
                        </div>
                        <div class="table1">
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <th class="t1">评价心得</th>
                                    <th class="t2">满意度</th>
                                    <th class="t2">商品信息</th>
                                    <th class="t2">评价用户</th>
                                </tr>
                                <?php if(is_array($middle_comment)): $i = 0; $__LIST__ = $middle_comment;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                                    <td class="t1">
                                        <?php echo ($vo["comment_content"]); ?>
                                        <div class="images">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                        </div>
                                    </td>
                                    <td class="t2">
                                        <div class="pingfen" rel=<?php echo ($vo["star"]); ?>><span></span></div>
                                    </td>
                                    <td class="t2">
                                        <b><?php echo (get_goods_name($vo["goods_id"])); ?></b>
										<b><?php echo (get_goods_spec($vo["goods_id"])); ?></b>
                                    </td>
                                    <td class="t2">
                                         <b><?php echo (getname($vo["user_id"])); ?></b>
										<b><?php echo (date("Y-m-d H:i:s",$vo["comment_time"])); ?></b>
                                    </td>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                            </table>
                        </div>
                        <div class="table1">
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <th class="t1">评价心得</th>
                                    <th class="t2">满意度</th>
                                    <th class="t2">商品信息</th>
                                    <th class="t2">评价用户</th>
                                </tr>
                                <?php if(is_array($bad_comment)): $i = 0; $__LIST__ = $bad_comment;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$va): $mod = ($i % 2 );++$i;?><tr>
                                    <td class="t1">
                                        <?php echo ($va["comment_content"]); ?>
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                            <img src="/Public/home/images/saidan.jpg" alt="晒单图片">
                                        </div>
                                    </td>
                                    <td class="t2">
                                        <div class="pingfen" rel=<?php echo ($va["star"]); ?>><span></span></div>
                                    </td>
                                    <td class="t2">
                                        <b><?php echo (get_goods_name($va["goods_id"])); ?></b>
										<b><?php echo (get_goods_spec($va["goods_id"])); ?></b>
                                    </td>
                                    <td class="t2">
                                        <b><?php echo (getname($va["user_id"])); ?></b>
										<b><?php echo (date("Y-m-d H:i:s",$va["comment_time"])); ?></b>
                                    </td>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="productxq_right">
        <div class="hoTranking">
            <h2>热销榜单</h2>
            <div class="hoTranking_con" id="hoTranking_con">
                <ul>
				<?php if(is_array($goods_best)): $i = 0; $__LIST__ = $goods_best;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li><a href="<?php echo U('Goods/goods_xq',array('goods_id'=>$v['goods_id']));?>">
                        <div class="images"><img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>" alt="产品图片"></div>
                        <div class="texts">
                            <span class="span1"><?php echo ($v["goods_name"]); ?></span>
                            <span><?php echo (get_goods_spec($v["goods_id"])); ?></span>
                        </div>
                        
						<div class="cost">
                            <i>¥<?php echo (get_goods_price($v["goods_id"])); ?></i>
                            <p class="cp">创业天使价格：<i>¥<?php echo (get_shop_price($v["goods_id"])); ?></i></p>
                            <p class="al">已有<b><?php echo (get_buy_num($v["goods_id"])); ?></b>人购买</p>
                        </div>
                    </a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<script>
    window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdPic":"","bdStyle":"0","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
</script>
<!--产品详情end-->
<!--tipbox-->
<div class="tishibox">
	<div class="tishi">
        <h3>宝贝已经成功加入购物车</h3>
        <p>您可以到<a href="<?php echo U('Goods/car');?>">购物车</a>查看</p>
        <a class="guanbi">关闭</a>
    </div>
</div>
<div class="atishibox">
	<div class="tishi">
        <h3>宝贝已存在</h3>
        <p>您可以到<a href="<?php echo U('Goods/car');?>">购物车</a>查看</p>
        <a class="guanbi">关闭</a>
    </div>
</div>
<!--tipbox-->
<script>
	$(function(){
		$(".tishibox a").click(function(){
			$(".tishibox").hide();
		})
		$(".atishibox a").click(function(){
			$(".atishibox").hide();
		})
	})
</script>
 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>