<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 <link rel="stylesheet" type="text/css" href="/Public/home/css/personal_center.css">
<script src="/Public/home/js/YMDClass.js" type="text/jscript"></script>
<script src="/Public/home/js/center.js" type="text/jscript"></script>
<!--我的资料-->
<div class="personal_center">
		<div class="pc_left" id="pc_left">
  		<ul>
        	<li style="background-image:url(/Public/home/images/li1.png)"><a>账户设置</a>
            	<dl class="sub_nav">
                	<dd  <?php if($wei == i): ?>class="currt0"<?php endif; ?>><a <?php if($wei == i): ?>class="currt1"<?php endif; ?>  href="<?php echo U('Personal/index');?>">我的资料</a></dd>
                    <dd <?php if($wei == m): ?>class="currt0"<?php endif; ?>><a <?php if($wei == m): ?>class="currt1"<?php endif; ?> href="<?php echo U('personal/mmxg');?>">修改密码</a></dd>
                </dl>
            </li>
            <li <?php if($wei == o || $wei == p || $wei == s || $wei == r || $wei == e): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li2.png)"><a <?php if($wei == o): ?>class="currt1"<?php endif; ?> href="<?php echo U('Myorder/index');?>">我的订单</a></li>
            <li <?php if($wei == a): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li3.png)"><a <?php if($wei == a): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/address');?>">收货地址</a></li>
            <li <?php if($wei == z): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/count2.png)"><a <?php if($wei == z): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/account');?>">我的账户</a></li>
        </ul>
    </div>
    <div class="pc_right" id="pc_right">
    	<div class="order">
        	<ul class="order_title" id="order_title">
            	

<li <?php if($wei == o): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/index');?>">全部订单</a></li>
<li <?php if($wei == p): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/payment');?>">待付款<i><?php echo ($payment_num); ?></i></a></li>
<li <?php if($wei == s): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/shipment');?>">待发货<i><?php echo ($shipment_num); ?></i></a></li>
<li <?php if($wei == r): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/receipt');?>">待收货<i><?php echo ($receipt_num); ?></i></a></li>
<li <?php if($wei == e): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/appraise');?>">已完成<i><?php echo ($appraiset_num); ?></i></a></li>
<!-- <li <?php if($wei == c): ?>class="currt6""<?php endif; ?> ><a href="<?php echo U('Myorder/complete');?>">已完成<i><?php echo ($complete_num); ?></i></a></li> -->
            </ul>
            <div class="orderSeek" id="orderSeek">
            	<div class="orderSeek_left">
                	<input class="sr" type="text" id="order_sn" placeholder="输入订单号进行搜索">
                    <input class="dj" type="submit" onclick="selectorder();" value="订单搜索">
                </div>
                <div class="orderSeek_right">
                	<b>订单时间</b>
                    <div style="margin-top:4px" class="orderSeek_select">
                        <select style="height:30px;width:200px" id="ddtime" onchange="changetime();">
							<option>请选择</option>
                        	<option value="1" <?php if($time == 1): ?>selected="selected"<?php endif; ?>>最近一周</option>
                        	<option value="2" <?php if($time == 2): ?>selected="selected"<?php endif; ?>>最近一月</option>
                            <option value="3" <?php if($time == 3): ?>selected="selected"<?php endif; ?>>最近三月</option>
                            <option value="4" <?php if($time == 4): ?>selected="selected"<?php endif; ?>>最近一年</option>
                        </select>
                    </div>
                </div>
            </div>
			<script>
				function selectorder(){
					$(".orderBox").hide();
					var order_sn=$("#order_sn").val();
					$("#order"+order_sn).show();
				}
				function changetime(){
					var time=$("#ddtime").val();
						location.href="/Home/Myorder/receipt?time="+time;

				}
			</script>
            <ul class="kinds">
            	<li class="one">货品详情</li>
                <li>实付款（元）</li>
                <li>订单状态</li>
                <li>操作 </li>
            </ul>
			<?php if(is_array($order)): $i = 0; $__LIST__ = $order;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="orderBox" id="order<?php echo ($vo["order_sn"]); ?>">
            	<div class="orderBox_top">
                	<div class="orderNumber">订单号：<b><?php echo ($vo["order_sn"]); ?></b></div>
                    <div class="orderData">下单时间：<b><?php echo (date("Y-m-d H:i",$vo["add_time"])); ?></b></div>
                </div>
				
                <ul class="orderBox_bottom">
				<?php if(is_array($vo["goods"])): $i = 0; $__LIST__ = $vo["goods"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li class="ob_1">
                    	<a class="c1" href="<?php echo U('Goods/goods_xq',array('goods_id'=>$v['goods_id']));?>"><img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>" alt=""></a>
                        <dl>
                        	<dd><a href="<?php echo U('Goods/goods_xq',array('goods_id'=>$v['goods_id']));?>"><?php echo (get_goods_name($v["goods_id"])); ?></a></dd>
                        </dl>
                    </li>
                    <li class="ob_2">
                    	<i>￥<?php echo ($v["xzmoney"]); ?></i>
                        <p>（含运费8.00）</p>
                        <p>共<b><?php echo ($v["goods_number"]); ?></b>款</p>
                    </li>
                    <li class="ob_3">
						<?php if($vo["order_status"] == 99): else: ?>
                    	<p><?php echo (get_order_status($vo["order_status"])); ?></p>
                        <a href="<?php echo U('Myorder/order_xq',array('order_id'=>$vo['order_id']));?>">订单详情</a><?php endif; ?>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
                    <li class="ob_4">
							<a class="payment" href="javascript:void(0)" onclick="shouhuo(<?php echo ($vo["order_id"]); ?>)">确认收货</a>

                    </li>
				
                </ul>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
            <script>
				//取消订单
				function quxiao(order_id){
					$.post("<?php echo U('Myorder/quxiao');?>",{'order_id':order_id},function(data){
						if(data.status==1){
							layer.msg("取消订单成功,",{icon:1});
							window.location.href="/Home/Myorder/index";
						}
					});
				}
				//确认收货
				function shouhuo(order_id){
					layer.confirm("你确定要删除吗？", {
						btn: ['确定','取消'] //按钮
					}, function(){
						$.post("<?php echo U('Personal/shouhuo');?>",{'order_id':order_id},function(data){
							if(data.status==1){
								layer.msg("确认收货成功,",{icon:1});
								setTimeout(function () {
									window.location.href="/Wap/Personal/dingdan/status/4.html";
								}, 1500);
							}
						});
					});
				}
			</script>
        </div>
    </div>
</div>
 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>