<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 
<link rel="stylesheet" type="text/css" href="/Public/home/css/personal_center.css">
<script src="/Public/home/js/center.js" type="text/javascript"></script>

<!--我的资料-->
<div class="personal_center">
		<div class="pc_left" id="pc_left">
  		<ul>
        	<li style="background-image:url(/Public/home/images/li1.png)"><a>账户设置</a>
            	<dl class="sub_nav">
                	<dd  <?php if($wei == i): ?>class="currt0"<?php endif; ?>><a <?php if($wei == i): ?>class="currt1"<?php endif; ?>  href="<?php echo U('Personal/index');?>">我的资料</a></dd>
                    <dd <?php if($wei == m): ?>class="currt0"<?php endif; ?>><a <?php if($wei == m): ?>class="currt1"<?php endif; ?> href="<?php echo U('personal/mmxg');?>">修改密码</a></dd>
                </dl>
            </li>
            <li <?php if($wei == o || $wei == p || $wei == s || $wei == r || $wei == e): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li2.png)"><a <?php if($wei == o): ?>class="currt1"<?php endif; ?> href="<?php echo U('Myorder/index');?>">我的订单</a></li>
            <li <?php if($wei == a): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/li3.png)"><a <?php if($wei == a): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/address');?>">收货地址</a></li>
            <li <?php if($wei == z): ?>class="currt0"<?php endif; ?> style="background-image:url(/Public/home/images/count2.png)"><a <?php if($wei == z): ?>class="currt1"<?php endif; ?> href="<?php echo U('Personal/account');?>">我的账户</a></li>
        </ul>
    </div>
    <div class="pc_right">
    	<div class="datum">
        	<h2>密码修改</h2>
            <ul class="changePassword">
            	<li><b>原始密码：</b><input id="oldpass" type="password"></li>
                <li><b>新密码：</b><input id="newpass" type="password"></li>
                <li><b>确认密码：</b><input id="repass" type="password"></li>
                <li class="tijiao"><input type="submit"></li>
            </ul>
        </div>
    </div>
</div>
<script>
	$(".tijiao input").click(function(){
		var oldpass=$("#oldpass").val();
		var newpass=$("#newpass").val();
		var repass=$("#repass").val();
		var length=newpass.length;
		if(oldpass==""){
			layer.msg("原始密码不能为空！",{icon:2});
			return false;
		}else if (oldpass==newpass){
			layer.msg("新密码不能和原始密码一样！",{icon:2});
			return false;
		}else if(newpass==""){
			layer.msg("新密码不能为空！",{icon:2});
			return false;
		}else if(length>20 || length<6){
			layer.msg("密码由6-20位组成！",{icon:2});
			return false;
		}else if(/^[0-9]+$/.test(newpass)){
			layer.msg("密码不能是纯数字!",{icon:2});
			return false;
		}else if(!/^[0-9a-z_!@#$%^&\*()~+|]*$/i.test(newpass)){
			layer.msg("密码由数字和字母组成",{icon:2});
			return false;
		}else if(newpass!==repass){
			layer.msg("两次密码输入不一致！",{icon:2});
			return false;
		}
		$.post("<?php echo U('Personal/mmxg');?>",{'oldpass':oldpass,'password':newpass},function(data){
			if(data.status==1){
				layer.msg('修改成功',{icon:1});
				window.location.href='<?php echo U('Personal/index');?>';
			}else{
				layer.msg('原始密码不正确',{icon:2});
			}
		});
		
		
		
		
	})
</script>
 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>