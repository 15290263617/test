<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>创业天使商城</title>
<link rel="stylesheet" type="text/css" href="/Public/Home/css/public.css">
<link rel="stylesheet" type="text/css" href="/Public/Home/css/base.css">
<script src="/Public/Home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/Home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/Home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
</head>
<style>
	.yan{
		display:block;
		float:right;
		width:110px;
		height:36px;
		line-height:36px;
		text-align:center;
		border:1px solid #bfbfbf;
		background-color:#d0d0d0;
		border-radius:4px;
		color:#929292;
		cursor:pointer;
		margin-left:8px;
	}
</style>
<body>
<div class="login_header">
    <div class="l_h_left"><a href="<?php echo U('Index/index');?>">&nbsp;</a></div>
    <div class="l_h_right"></div>
</div>
<div class="login_con">
    <div class="login_mode">
        <h6>欢迎注册<span>已注册可<a href="<?php echo U('Login/login');?>">直接登录</a></span></h6>
        <div class="input"><input type="text" id="phone" placeholder="输入手机号码"></div>
        <div class="input"><input type="password" id="password" placeholder="密码由6-20位字母，数字和符号组合"></div>
        <div class="input"><input type="password" id="repass" placeholder="请再次输入上面的密码"></div>
        <div class="dxyzm"><input style="float:left;" type="text" id="code"  placeholder="短信验证码">
		<input class="yan" style="background-color:green;color:#fff;" onclick="code();" value="获取短信验证码">
		</div>
        <div class="nowLogin"><input id="ljzc8" type="submit" value="立即注册"></div>
        <div class="deal"><input type="checkbox">我已阅读并接受<a>《创业天使服务条款》</a>。</div>
    </div>
</div>
<script>
	//发送验证码
	function code(){
		var phone=$('#phone').val();
		var tm=$('.yan').val();
		if(!/^1[3|4|5|8]\d{9}$/.test(phone)){
			layer.alert("手机号不符合要求");
			return false;
		}
		if(tm==0 || tm=="获取短信验证码"){
			$.ajax({
				'type':'post',
				'url':"<?php echo U('Login/code');?>",
				'data':{phone:phone},
				'dataType':'json',
				'success':function(dat){
					if(dat.status==1){
						layer.alert('发送成功！');
						var countdown=60;
						gettime();
					}else{
						layer.alert('发送失败！');
						return false;
				   }
				}
			})
		}
	}

	//倒计时的显示
	var countdown=60;
	function gettime() {
		if (countdown == 0) {
			$(".yan").removeAttr("disabled");
			$(".yan").css({"background-color":"green","color":"#fff"});
			$('.yan').val('获取短信验证码');
			countdown=60;
			return; 
		} else {
			$('.yan').val("重新发送(" + countdown + ")");
			$(".yan").css({"background-color":"#d0d0d0","color":"#333333"});
			$('.yan').attr("disabled",true); 
			countdown--; 
		}
		 setTimeout(function(){
			gettime();
		},1000) 
	}

$("#ljzc8").click(function(){
	var deal=$(".deal input").attr('checked');
	var phone=$("#phone").val();
	var password=$("#password").val();
	var repass=$("#repass").val();
	var code=$("#code").val();
	var length=password.length;
	
	if(code==""){
		layer.alert('验证码不能为空');
		return false;
    }
	if(!/^1[3|4|5|7|8]\d{9}$/.test(phone)){
		layer.msg("手机号不符合要求！",{icon:2});
		return false;
	}
	if(password==""){
		layer.msg("密码不能为空！",{icon:2});
		return false;
	}else if(length>20 || length<6){
		layer.msg("密码由6-20位组成！",{icon:2});
		return false;
	//}else if(/^[0-9]+$/.test(password)){
		//layer.msg("密码不能是纯数字!",{icon:2});
		//return false;
	}else if(!/^[0-9a-z_!@#$%^&\*()~+|]*$/i.test(password)){
		layer.msg("密码由数字和字母组成",{icon:2});
		return false;
	}else if(password!==repass){
		layer.msg("两次密码输入不一致！",{icon:2});
		return false;
	}else if(deal==undefined){
		layer.msg("请同意服务条款",{icon:2});
		return false;
	}
	$.post("<?php echo U('Login/register');?>",{'phone':phone,'password':password,'code':code},function(data){
		if(data.status==1){
			layer.msg("注册成功",{icon:1});
			var url='<?php echo U('Index/index');?>';
			window.location.href=url;
		}else if(data.status==2){
			layer.msg("手机号已经注册过，请不要重新注册！",{icon:2});
		}else if(data.status==3){
			layer.msg('验证码输入错误！',{icon:2});
		}else{
			layer.msg("注册失败",{icon:2});
		}
	});
})
</script>
<div class="login_footer">Copyright © 2015 FengQ.All Rights Reserved | 豫ICP备15040786号-3 郑州豫商纸业版权所有   <a href="http://www.cccuu.com">技术支持：灵秀科技</a></div>
</body>
</html>