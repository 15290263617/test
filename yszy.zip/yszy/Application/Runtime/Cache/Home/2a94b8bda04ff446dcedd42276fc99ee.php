<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- <title>创业天使商城</title> -->
<?php
 $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo C('WEB_SITE_TITLE');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>
<link rel="stylesheet" type="text/css" href="/Public/home/css/base.css">
<link rel="stylesheet" type="text/css" href="/Public/home/css/public.css">
<script src="/Public/home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/home/js/jquery.kkPages.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/home/css/Css.css">
</head>

<body>
<!--头部-->
<div class="header_out">
    <div class="header">
        
        <div class="header_right" id="header_right">
            <ul>
                <li>
				<?php if($_SESSION['home']['islogin']): ?><a style="margin-right:20px" href="<?php echo U('Personal/index');?>">
					<?php if($userinfo['nick_name']): echo ($userinfo["nick_name"]); ?>
					<?php else: ?>
						<?php echo ($_SESSION['home']['phone']); endif; ?>
					</a>
					<a href="<?php echo U('Login/logout');?>">退出</a>
				<?php else: ?>
					<a href="<?php echo U('Login/login');?>">请登陆</a><?php endif; ?>
				</li>
                <li><a href="<?php echo U('Login/register');?>">注册</a></li>
                <li><a href="<?php echo U('Myorder/index');?>">我的订单</a></li>
                <li><a 
				<?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Goods/car');?>"
				<?php else: ?>
					href="<?php echo U('Login/login');?>"<?php endif; ?>
				>我的购物车（<i><?php echo ($car_num); ?></i>）</a></li>
                <li class="service">
                    <dl>
                        <dt><a>客户服务</a></dt>
                        <dd><a href="<?php echo U('Public/service');?>">联系客服</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">帮助中心</a></dd>
                    </dl>
                </li>
                <li class="more">
                    <dl>
                        <dt><a>更多</a></dt>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">关于我们</a></dd>
                        <dd><a href="<?php echo U('Public/article',array('id'=>'1'));?>">品牌招商</a></dd>
                        <dd><a href="#" onclick="javascript:AddFavorite();">收藏本站</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>
</div>
<script>
		function AddFavorite(title, url) {
            try {
                //IE
                window.external.addFavorite(url, title);
            }
            catch (e) {
                try {
                    //Firedox
                    window.sidebar.addPanel(title, url, "");
                }
                catch (e) {
                    layer.alert("抱歉，您所使用的浏览器无法完成此操作。加入收藏失败，请使用Ctrl+D进行添加");
                }
            }
        }
</script>
<!--头部结束-->
<!--导航-->
<div class="header2_out">
    <div class="header2">
        <div class="logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo1); ?>" alt="网站LoGo"></a></div>
        <div class="nav">
            <ul>
                <li <?php if($wei == in): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Index/index');?>">首页</a></li>
				<?php if(is_array($enum)): $i = 0; $__LIST__ = $enum;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li <?php if($v["id"] == $enum_id): ?>class="this"<?php endif; ?> ><a href="<?php echo U('Goods/goods',array('enum_id'=>$v['id']));?>"><?php echo ($v["evalue"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                <li <?php if($wei == an): ?>class="this"<?php endif; ?> ><a <?php if($_SESSION['home']['islogin']): ?>href="<?php echo U('Angel/index');?>"<?php else: ?>href="<?php echo U('Login/login');?>"<?php endif; ?> >我要创业</a></li>
            </ul>
        </div>
        <div class="wechat">
            <div class="images"><img src="/Uploads/<?php echo ($weixin); ?>" alt="微信二维码"></div>
            <div class="texts"><span>微信扫码<br>进入商城</span></div>
        </div>
    </div>
</div>
<!--导航结束-->
 
<div class="banner">
    <div class="img_list">
        <ul>
			<?php if(is_array($index_banner)): $i = 0; $__LIST__ = $index_banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><li><a href="<?php echo ($val["ad_link"]); ?>"><img src="/Uploads/<?php echo ($val["ad_code"]); ?>" alt="广告图"></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
    <div class="hd" id="hd">
        <ul>
        </ul>
    </div>
    <div class="prev"></div>
    <div class="next"></div>
    <!--左侧导航-->
    <div class="leftNav" id="leftNav">
        <dl>
            <dt>产品系列</dt>
			<?php if(is_array($cate)): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dd><?php echo ($v["cat_name"]); ?></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
    </div>
    <!--一个系列的内容最大为10条，超出10条则看不到，后台需知 1个rightCon对应上面1个系列的内容-->
	<?php if(is_array($goods)): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><div class="rightCon">
        <ul>
			<?php if(is_array($val['goods'])): $i = 0; $__LIST__ = $val['goods'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li><a href="<?php echo U('Goods/goods_xq',array('goods_id'=>$v['goods_id']));?>">
                <img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>" alt="产品图片">
                <span><?php echo ($v["goods_name"]); ?></span>
            </a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<div class="hot" id="hot">
    <h2>热销推荐</h2>
    <div class="hotLeft">
        <img src="/Uploads/<?php echo ($hot_banner["ad_code"]); ?>" alt="热销推荐">
    </div>
    <div class="hotRight">
        <ul>
			<?php if(is_array($goods_best)): $i = 0; $__LIST__ = $goods_best;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li><a href="<?php echo U('Goods/goods_xq',array('goods_id'=>$v['goods_id']));?>">
                <h4><?php echo ($v["goods_name"]); ?></h4>
                <h5><?php echo (get_goods_discribe($v["goods_id"])); ?></h5>
                <h6><?php echo (get_goods_spec($v["goods_id"])); ?></h6>
                <div class="hotImg"><img src="/Uploads/<?php echo (get_goods_img($v["goods_id"])); ?>" alt="热销推荐"></div>
            </a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>
 
<!-- 底部 -->
<!--页脚-->
<div class="footer1" style="margin-top:0;">
    <ul>
        <li style='background-image: url("/Public/home/images/y1.png")'>满99元包邮</li>
        <li style='background-image:url("/Public/home/images/y2.png")'>正品保障</li>
        <li style='background-image:url("/Public/home/images/y3.png")'>七天退货</li>
        <li style='background-image:url("/Public/home/images/y4.png")'>送货上门</li>
    </ul>
</div>
<div class="footer2_out">
    <div class="footer2">
        <div class="left_logo"><a href="<?php echo U('Index/index');?>"><img src="/Uploads/<?php echo ($logo2); ?>" alt="LOGO"></a></div>
		<?php if(is_array($article_cat)): $i = 0; $__LIST__ = $article_cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><dl>
            <dt><?php echo ($v["cat_name"]); ?></dt>
			<?php if(is_array($v["article"])): $i = 0; $__LIST__ = $v["article"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo U('Public/article',array('id'=>$vo['article_id']));?>"><?php echo ($vo["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl><?php endforeach; endif; else: echo "" ;endif; ?>

        <dl>
            <dt>友情链接</dt>
			<?php if(is_array($friend_link)): $i = 0; $__LIST__ = $friend_link;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><dd><a href="<?php echo ($val["evalue"]); ?>" target="_blabk"><?php echo ($val["ename"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
        <div class="connect">
            <h2>联系我们</h2>
            <p>周一至周日 8：00-22:00（节假日除外）
                <a class="a1" href="<?php echo U('Public/service');?>">在线客服</a>
            </p>
        </div>
        <p class="p1"><?php echo ($copyright); ?></p>
    </div>
</div>
<!--页脚结束-->
</body>
</html>