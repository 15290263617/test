<?php if (!defined('THINK_PATH')) exit();?> <!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>创业天使商城</title>
<link rel="stylesheet" type="text/css" href="/Public/Home/css/public.css">
<link rel="stylesheet" type="text/css" href="/Public/Home/css/base.css">
<script src="/Public/Home/js/jquery-1.8.3.min.js"></script>
<script src="/Public/Home/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="/Public/Home/js/base.js"></script>
<script src="/Public/layer/layer.js"></script>
</head>
<body>
<div class="login_header">
    <div class="l_h_left"><a href="<?php echo U('Index/index');?>">&nbsp;</a></div>
    <div class="l_h_right"></div>
</div>
<div class="login_con">
    <div class="login_mode">
        <h6>如有账号，请登陆</h6>
        <div class="input"><input type="text" id="phone" placeholder="手机号" ></div>
        <div class="input"><input type="password" id="password" placeholder="密码" ></div>
        <div class="verify" id="verify">
            <p>向右拖动滑块确认登录</p>
            <div class="background"></div>
            <div class="slide"></div>
            <input type="hidden" value="0">
        </div>
        <div class="nowLogin"><input id="ljdl8" type="submit" value="立即登陆"></div>
        <div class="check">
            <span><input type="checkbox">记住用户名</span>
            <p>
                <b><a href="<?php echo U('Login/zhaohui');?>">忘记密码?</a></b>
                <b class="zhuce"><a href="<?php echo U('Login/register');?>">免费注册</a></b>
            </p>
        </div>
        <!-- <dl class="partner" id="partner">
            <span>使用微信扫码登录</span>
            <div class="wechat_img"><img src="/Public/Home/images/wechat_img.jpg" alt="微信登录二维码"></div>
        </dl> -->
    </div>
	<script>
		$("#ljdl8").click(function(){
		//alert(1);
			var phone=$("#phone").val();
			var password=$("#password").val();
			var code=$(".login_mode .verify p").text();
			var verify="验证通过";
			if(!/^1[3|4|5|7|8]\d{9}$/.test(phone)){
				layer.msg('手机号不符合要求！',{icon:2});
				return false;
			}else if(password==""){
				layer.msg('密码不能为空！',{icon:2});
				return false;
			}
			if(code!==verify){
				layer.msg('验证失败，请重新验证！',{icon:2});
				return false;
			}
			$.post("<?php echo U('Login/login');?>",{'phone':phone,'password':password},function(data){
			//alert(data.status);
				if(data.status==1){
					layer.msg("登录成功",{icon:1});
					var url='<?php echo U('Index/index');?>';
					window.location.href=url;
				}else if(data.status==0){
					layer.msg("用户名不存在",{icon:2});
				}else{
					layer.msg("登录失败",{icon:2});
				}
			});
		})
	</script>
</div>