<?php
return array(
	//'配置项'=>'配置值'
		'APP_GROUP_LIST'=>'Admin,Home,Weixin,User,Wap',
		'DEFAULT_MODULE' => 'Home',
		'SESSION_AUTO_START' => true, //是否开启session
		'SHOW_PAGE_TRACE' => false,
		'WEB_SITE_TITLE' => '创业天使商城',
	//数据库
		'DB_TYPE' => 'mysql', // 数据库类型
		'DB_HOST' => '127.0.0.1', // 服务器地址
		'DB_NAME' => 'lx_yszy', // 数据库名
		'DB_USER' => 'root', // 用户名
		'DB_PWD' => 'root', // 密码
		'DB_PORT' => 3306, // 端口
		'DB_CHARSET'=> 'utf8', // 字符集
		'DB_PREFIX'=>'lx_', // 数据库表前缀
		/* 'TMPL_CACHE_ON'         =>  true,
		'DB_FIELDS_CACHE'       =>  true, */ //数据库字段缓存 
		//'URL_MODEL' =>  2,
		/* 'TMPL_CACHE_TIME'       =>  1000, */ 
	
);