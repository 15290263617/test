<?php
	//验证码
	function verify($mobile=''){
		header("Content-Type: text/html; charset=UTF-8");
		$flag = 0;
		$params='';//要post的数据
		$verify = rand(123456, 999999);//获取随机验证码
		//以下信息自己填以下
		//$mobile='';//手机号
		$argv = array(
			'name'=>'18736030959',     //必填参数。用户账号
			'pwd'=>'50708D06777B701C6731EA12EE34',     //必填参数。（web平台：基本资料中的接口密码）
			'content'=>'短信验证码为：'.$verify.'，请勿将验证码提供给他人。',   //必填参数。发送内容（1-500 个汉字）UTF-8编码
			'mobile'=>$mobile,   //必填参数。手机号码。多个以英文逗号隔开
			'stime'=>'',   //可选参数。发送时间，填写时已填写的时间发送，不填时为当前时间发送
			'sign'=>'豫商纸业',    //必填参数。用户签名。
			'type'=>'pt',  //必填参数。固定值 pt
			'extno'=>''    //可选参数，扩展码，用户定义扩展码，只能为数字
		);
		//print_r($argv);exit;
		//构造要post的字符串
		//echo $argv['content'];
		foreach ($argv as $key=>$value){
			if ($flag!=0) {
				$params .= "&";
				$flag = 1;
			}
			$params.= $key."="; $params.= urlencode($value);// urlencode($value);
			$flag = 1;
		}
		$url = "http://sms.1xinxi.cn/asmx/smsservice.aspx?".$params; //提交的url地址
		$con= substr( file_get_contents($url), 0, 1 );  //获取信息发送后的状态
		session('code',$verify);
		session('mobile',$mobile);
		/*if($con == '0'){
			echo "发送成功!";
		}else{
			echo "发送失败!";
		}*/
		return $con;

	}

	
	/* 分页方法 */
	function Page($rows, $page_size, $page) {
		$page_count = ceil($rows / $page_size);
		$rows1 = array();
		if ($page >= $page_count)
			$page = $page_count;
		if ($page <= 1 || $page == '')
			$page = 1;
		$select_limit = $page_size;
		$w_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?";
		$select_from = ($page - 1) * $page_size;
		$rows1['page_l'] = $select_from;
		$rows1['page_r'] = $select_limit;
		$pre_page = ($page == 1) ? 1 : $page - 1;
		$next_page = ($page == $page_count) ? $page_count : $page + 1;

		$pagenav .= "<a href='" . $w_url . "&page=1'>首页</a> ";
		$pagenav .= "<a href='" . $w_url . "&page=" . $pre_page . "'>前一页</a> ";
		$pagenav .= "<a href='" . $w_url . "&page=" . $next_page . "'>后一页</a> ";
		$pagenav .= "<a href='" . $w_url . "&page=" . $page_count . "'>末页</a>";
		$pagenav .= "第 " . $page . "/" . $page_count . " 页 共 " . $rows . " 条 ";
		$pagenav.="跳到&nbsp;&nbsp;<select name='topage' size='1' onchange='window.location=\"" . $w_url . "&page=\"+this.value'>\n";
		for ($i = 1; $i <= $page_count; $i++) {
			if ($i == $page)
				$pagenav.="<option value='$i' selected>$i</option>\n";
			else
				$pagenav.="<option value='$i'>$i</option>\n";
		}
		$pagenav.='</select>';
		$rows1['page'] = $pagenav;
		return $rows1;
	}
	
	//订单状态
	function get_order_status($status){
		$id=$status;
		if($id==1){
			return "等待买家付款";
		}elseif($id==2){
			return "等待卖家发货";
		}elseif($id==3){
			return "等待确认收货";
		}elseif($id==4){
			return "交易成功";
		}else{
			return "取消订单";
		}
	}

	//验证验证码
	function check_verify($code, $id = ''){
		$verify = new \Think\Verify();
		return $verify->check($code, $id);
	}
	
	//用户手机号
	function getphone($uid){
		$phone=M('user')->where("user_id = '$uid'")->getField('phone');
		return $phone;
	}
	
	//用户名字
	function getname($uid){
		$name=M('user_info')->where("user_id = '$uid'")->getField('user_name');
		// $user_name=mb_substr($name,0,1,utf-8)."xx";
		return $name;
	}
	
	//返回前三位手机号
	function get_three_phone($phone){
		$qphone=substr($phone,0,3);
		$phonea=$qphone."xxxxxxxx";
		return $phonea;
	}
	
	//返回四位手机号
	function get_four_phone($phone){
		$qphone=substr($phone,0,3);
		$hphone=substr($phone,8,4);
		$phonea=$qphone."xxxx".$hphone;
		return $phonea;
	}
	
	//通过cate_id获取cate_name
	function get_cate_name($cate_id){
		$cate_name=M('goods_cate')->where("cat_id = '$cate_id'")->getField('cat_name');
		return $cate_name;
	}
	
	
	//通过enum_id获取enum_name
	function get_enum_name($enum_id){
		$enum_name=M('sys_enum')->where("id = '$enum_id'")->getField('evalue');
		return $enum_name;
	}
	
	//通过goods_id获取商品图片
	function get_goods_img($goods_id){
		$goods_img=M('goods')->where("goods_id = '$goods_id'")->getField('goods_img');
		return $goods_img;
	}
	
	//通过goods_id获取商品名称
	function get_goods_name($goods_id){
		$goods_name=M('goods')->where("goods_id = '$goods_id'")->getField('goods_name');
		return $goods_name;
	}
	
	//通过goods_id获取商品单价
	function get_goods_price($goods_id){
		$goods_price=M('goods')->where("goods_id = '$goods_id'")->getField('market_price');
		return $goods_price;
	}
	
	//通过goods_id获取商品创业天使价格
	function get_shop_price($goods_id){
		$market_price=M('goods')->where("goods_id = '$goods_id'")->getField('market_price');
		$shop_price=number_format($market_price*0.75,2);
		return $shop_price;
	}
	
	//通过goods_id获取商品是否是礼包
	function get_goods_type($goods_id){
		$g_type=M('goods')->where("goods_id = '$goods_id'")->getField('g_type');
		return $g_type;
	}
	
	//通过goods_id获取商品库存
	function get_goods_kucun($goods_id){
		$goods_kucun=M('goods')->where("goods_id = '$goods_id'")->getField('goods_kucun');
		return $goods_kucun;
	}
	
	//通过goods_id获取商品描述
	function get_goods_discribe($goods_id){
		$goods_discribe=M('goods')->where("goods_id = '$goods_id'")->getField('goods_discribe');
		return $goods_discribe;
	}
	
	//通过goods_id获取商品规格
	function get_goods_spec($goods_id){
		$goods_spec=M('goods')->where("goods_id = '$goods_id'")->getField('goods_spec');
		return $goods_spec;
	}
	
	//通过brand_id获取品牌名称
	function get_brand_name($brand_id){
		$bname=M('brand')->where("id = '$brand_id'")->getField('bname');
		return $bname;
	}
	
	//通过car_id获取goods_id;
	function get_goods_id($car_id){
		$goods_id=M('car')->where("car_id = '$car_id'")->getField('goods_id');
		return $goods_id;
	}
	
	//通过car_id获取商品货号;
	function get_goods_sn($car_id){
		$goods_id=M('car')->where("car_id = '$car_id'")->getField('goods_id');
		$goods_sn=M('goods')->where("goods_id = '$goods_id'")->getField('goods_sn');
		return $goods_sn;
	}
	
	//通过car_id获取商品名称;
	function get_goods_namebycar_id($car_id){
		$goods_id=M('car')->where("car_id = '$car_id'")->getField('goods_id');
		$goods_name=M('goods')->where("goods_id = '$goods_id'")->getField('goods_name');
		return $goods_name;
	}
	
	//通过car_id获取商品价格;
	function get_market_price($car_id){
		$goods_id=M('car')->where("car_id = '$car_id'")->getField('goods_id');
		$market_price=M('goods')->where("goods_id = '$goods_id'")->getField('market_price');
		return $market_price;
	}
	//通过car_id获取购买数量;
	function get_market_num($car_id){
		$num=M('car')->where("car_id = '$car_id'")->getField('num');
		// $market_price=M('goods')->where("goods_id = '$goods_id'")->getField('market_price');
		return $num;
	}
	
	//通过cat_id获取文章分类
	function get_artcat_name($cat_id){
		$cat_name=M('article_cat')->where("cat_id = '$cat_id'")->getField('cat_name');
		return $cat_name;
	}
	
	//通过goods_id获取购买人数
	function get_buy_num($goods_id){
		$count=M('order_goods')->where("goods_id = '$goods_id'")->count();
		return $count;
	}
	
	
	
	
//读取SEO规则
function get_seo_meta($vars,$seo)
{

    //获取还没有经过变量替换的META信息
    $meta = D('Common/SeoRule')->getMetaOfCurrentPage($seo);
 return $meta;
    //替换META中的变量
/*     foreach ($meta as $key => &$value) {
        $value = seo_replace_variables($value, $vars);
    }
    unset($value); */

    //返回被替换的META信息
   
}

function seo_replace_variables($string, $vars)
{
    //如果输入的文字是空的，那就直接返回空的字符串好了。
    if (!$string) {
        return '';
    }

    //调用ThinkPHP中的解析引擎解析变量
    $view = new Think\View();
    $view->assign($vars);
    $result = $view->fetch('', $string);

    //返回替换变量后的结果
    return $result;
}
function clean_all_cache()
{
    $dirname = './Application/Runtime/';

//清文件缓存
    $dirs = array($dirname);
//清理缓存
    foreach ($dirs as $value) {
        rmdirr($value);
    }
    @mkdir($dirname, 0777, true);
}
function rmdirr($dirname)
{
    if (!file_exists($dirname)) {
        return false;
    }
    if (is_file($dirname) || is_link($dirname)) {
        return unlink($dirname);
    }
    $dir = dir($dirname);
    if ($dir) {
        while (false !== $entry = $dir->read()) {
            if ($entry == '.' || $entry == '..') {
                continue;
            }
            rmdirr($dirname . DIRECTORY_SEPARATOR . $entry);
        }
    }
    $dir->close();
    return rmdir($dirname);
}


	
	
	
	
	
	
	
	
	
	
	
	
	