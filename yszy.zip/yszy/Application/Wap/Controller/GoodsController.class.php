<?php
namespace Wap\Controller;

use Think\Controller;

class GoodsController extends PublicController {
	
	
	public function prolist($type=""){
		if($type==0){//推荐更多
			$good_tj=M("goods")->where("is_best=1")->select();

		}else{
			$good_tj=M("goods")->where("cat_id='$type'")->select();//分类更多

		}
		$this->assign("list",$good_tj);
		$this->display();
	}
	
    public function proxq($goods_id=""){
		//session('uid',2);
		$uid=$_SESSION['uid'];
		//dump(session());
		//产品详情
		$good_xq=M("goods")->where("goods_id='$goods_id'")->find();
		$this->assign("goods_xq",$good_xq);
		//产品图片
		$good_img=M("goods_img")->where("goods_id='$goods_id'")->select();
		$this->assign("goods_img",$good_img);
		//产品评价
		$goods_comment=M("goods_comment")->where("goods_id='$goods_id'")->select();
		if($goods_comment){
				$id=M("goods")->where("goods_id='$goods_id'")->getField('cat_id');//品牌分类
		foreach($goods_comment as $k=>&$v){
			$v['comment_content']=htmlspecialchars_decode($v['comment_content']);
			$v['comment_time']=date("Y-m-d H:i:s",$v['comment_time']);
			$v['cat_name']=M("goods_cate")->where("cat_id='$id'")->getField('cat_name');
		}
		$good=M("goods")->where("cat_id='$id'")->limit(6)->select();//更多同类产品
		$this->assign("good",$good);

		$this->assign("comment",$goods_comment);
		$this->assign("type",$id);
		$this->assign("uu",66);
	}else{
		$this->assign("uu",99);//暂无评论
	}
	

		$car=M('car')->where("user_id ='".$uid."' and status =0")->count();//购物车数量
		$this->assign("car_num",$car);

		$this->display();
	}
//添加购物车
	public function add(){
		$uid=$_SESSION['uid'];
		$goods_id=I('post.goods_id');
		if(!$uid){
			session('rtype',2);
			session('goods_id',$goods_id);
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$user_type=M('user_info')->where("user_id='$uid'")->getField('type');

		$data['user_id']=$uid;
		$data['num']=I('post.num');
		$data['goods_id']=$goods_id;
		$res=M('car')->where("goods_id = '$goods_id' && user_id = '$uid' && status = '0'")->find();

		if($res){
			$return['status']=2;
		}else{
			if($user_type==1 || $user_type==2){
				$market_price=get_goods_price(I('post.goods_id'));
			}else{
				if(get_goods_type(I('post.goods_id'))==1){
					$market_price=get_shop_price(I('post.goods_id'));
				}else{
					$market_price=get_goods_price(I('post.goods_id'));
				}
			}
			$data['xzmoney']=number_format($market_price*I('post.num'),2);
			$data['add_time']=time();
			$result=M('car')->add($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
		}
		$this->ajaxReturn($return);
	}


	
	
	
}