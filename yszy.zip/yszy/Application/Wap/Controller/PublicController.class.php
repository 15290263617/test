<?php
namespace Wap\Controller;
use Think\Controller;
class PublicController extends Controller {

	private $wc = null;
	public  $openid = '';
    public  $uid=0;
	
	public function _initialize(){
		session('gtype',null);
		session('tjid',null);
		if(!empty($_SESSION['uid'])){
            $this->uid = $_SESSION['uid'];
        }
		$this->wc = new \Org\Util\WeChat();
		
		$signPackage=$this->wc->wxJsapiPackage();
		//dump($signPackage);
		$this->assign('signPackage',$signPackage);
		
		$uid=$_SESSION['uid'];
		//A('Weixin/user_auth')
		//用户基本信息
		$userinfo=M('user_info')->where("user_id = '$uid'")->find();
		$this->assign('userinfo',$userinfo);
		//dump($userinfo);
		//导航
		$enum=M('sys_enum')->where("egroup = '1'")->select();
		$this->assign('enum',$enum);
		
		//分类
		$cate=M('goods_cate')->select();
		$this->assign('cate',$cate);
		
		//购物车数量
		$car_num=M('car')->where("user_id = '$uid' && status = '0'")->count();
		$this->assign('car_num',$car_num);
		
		//各订单状态数量
		//待付款
		/* $payment_num=M('order_info')->where("order_status = '1' && user_id = '$uid'")->count();
		//待发货
		$shipment_num=M('order_info')->where("order_status = '2' && user_id = '$uid'")->count();
		//待收货
		$receipt_num=M('order_info')->where("order_status = '3' && user_id = '$uid'")->count();
		//待评价
		$appraiset_num=M('order_info')->where("order_status = '4' && user_id = '$uid'")->count();
		//已完成
		$complete_num=M('order_info')->where("order_status = '5' && user_id = '$uid'")->count();
		$this->assign('payment_num',$payment_num);
		$this->assign('shipment_num',$shipment_num);
		$this->assign('receipt_num',$receipt_num);
		$this->assign('appraiset_num',$appraiset_num);
		$this->assign('complete_num',$complete_num); */
		
		//文章分类
		$article_cat=M('article_cat')->select();
		foreach($article_cat as $k => $v){
			$cat_id=$v['cat_id'];
			$article=M('article')->where("cat_id = '$cat_id'")->select();
			$article_cat[$k]['article']=$article;
		}
		$this->assign('article_cat',$article_cat);
		
		//友情链接
		$friend_link=M('sys_enum')->where("egroup = 10")->select();
		$this->assign('friend_link',$friend_link);
		
		//系统常量
		$logo1=M('sys_enum')->where("id = 4")->getField('evalue');
		$logo2=M('sys_enum')->where("id = 5")->getField('evalue');
		$tel=M('sys_enum')->where("id = 7")->getField('evalue');
		$weixin=M('sys_enum')->where("id = 6")->getField('evalue');
		$copyright=M('sys_enum')->where("id = '14'")->getField('evalue');
		$this->assign('logo1',$logo1);
		$this->assign('logo2',$logo2);
		$this->assign('tel',$tel);
		$this->assign('weixin',$weixin);
		$this->assign('copyright',$copyright);
		
		//主页banner
		$index_banner=M('ads')->order('sort asc')->where("position_id = '0'")->select();
		$this->assign('banner_num',count($index_banner));
		$this->assign('index_banner',$index_banner);
		
		
		
		//主页热销推荐图
		$hot_banner=M('ads')->order('sort asc')->where("position_id = '2'")->find();
		$this->assign('hot_banner',$hot_banner);
		
		
		
		
		
		//运费
		$yunfei=M('sys_enum')->where("id = '15'")->getField('evalue');
		$this->assign('yunfei',$yunfei);

	}
	
	public function get_signPackage(){
        $signPackage=$this->wc->wxJsapiPackage();
        return $signPackage;
    }

	//文章get_brand_name
	public function article(){
		$id=I('get.id');
		$article=M('article')->where("article_id = '$id'")->find();
		$this->assign('article',$article);
		$this->assign('id',$id);
		$this->display();
	}

	//联系客户
	public function help(){
		$result=M('sys_enum')->where("egroup = '12'")->select();
		$this->assign('result',$result);
		$this->display();
	}
	
	
	//我的帐号
	public function account(){
		//session('uid',null);exit;
		$uid=$_SESSION['uid'];
		if(!$uid){
			session('rtype',1);
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$arr1=array();$arr2=array();
		$tx=M('tx_record')->where("user_id = '$uid' && status = 2")->select();
		$cz=M('cz_record')->where("user_id = '$uid' && status = 2")->select();
		foreach($tx as $key => $val){
			$arr1[$key]['money']=$val['tx_money'];
			$arr1[$key]['time']=$val['tx_time'];
			$arr1[$key]['status']=1;
		}
		foreach($cz as $k => $v){
			$arr2[$k]['money']=$v['cz_money'];
			$arr2[$k]['time']=$v['cz_time'];
			$arr2[$k]['status']=2;
		}
		$arr=array_merge($arr1,$arr2);
		foreach($arr as $ke => $va){
			$time[$ke]=$va['time'];
		}
		array_multisort($time,SORT_DESC,$arr);
		$this->assign('arr',$arr);
		$position="z";
		$this->assign('wei',$position);
		$this->display();
	}
	
	public function bdsjh(){
		if(I('post.')){
			$phone=I('post.phone');
			$newpassword=md5(I('post.password'));
			$user=M('user')->where("phone='$phone'")->find();
			if($user){//判断用户是否存在，存在的话判断密码，对了直接取user_id绑定信息，错了输出错误
				$spassword=$user['password'];
				if($spassword==$newpassword){
					$user_id=$user['user_id'];
					$ztype=1;
				}else{
					//session('user_info',null);
					$this->redirect('Wap/Public/bdsjh',array(),3,'密码错误，绑定失败');
				}
			}else{//不存在的话直接注册生成一个用户
				$arr['phone']=$phone;
				$arr['password']=$newpassword;
				$user_id=M('user')->add($arr);
				$ztype=2;
			}
			if($user_id>0){
				$userinfo=session('user_info');
				$data = array(
					'openid'    =>  $userinfo['openid'],
					'nick_name' =>  $userinfo['nickname'],
					'sex'       =>  $userinfo['sex'],
					'location_c'=>  $userinfo['city']."市",
					'location_p'=>  $userinfo['province']."省",
					//'country' =>  $userinfo['country'],
					'head_img'  =>  $userinfo['headimgurl'],
					'type'   	=>  2,
					'logintime'	=>	time(),
					'user_id'	=>	$user_id
				);
				$openid=$userinfo['openid'];
				$tjid=M('user_wx')->where("openid='$openid'")->getField('tjid');
				if($tjid){
					$data['recommend_id']=$tjid;
				}
				if($ztype==1){
					$id = M('user_info')->where("user_id='$user_id'")->save($data);
				}else{
/* 					$str_bh=time();
					$abc=substr($str_bh,-4);
					$data['user_number']="CY".rand(10,99).$abc.rand(1000,9999); */
					$id = M('user_info')->add($data);
					$dat['addtime']=time();
					M('user_info')->where("user_id='$user_id'")->save($dat);
				}
					if ($id > 0) {
						session('user_info',null);
						session('uid',$user_id);
            // $this->prize_go_num($rows['id']);
						$rtype=session('rtype');//跳转的session
						switch ($rtype){
						case 1:
							$this->redirect('Wap/Public/account');
						break;
						case 2:
							$goods_id=session('goods_id');
							$this->redirect('Wap/Goods/proxq',array('goods_id'=>$goods_id));
						break;
						case 3:
							$this->redirect('Wap/Personal/center');
						break;
						/* case 4:
							$this->redirect('Wap/Index/index');
						break; */
						default:
							$this->redirect('Wap/Index/index');
						break;
						}
					}else{
						session('user_info',null);
						exit('账号绑定失败');
					} 
			}else{
				session('user_info',null);
				exit('账号绑定失败');
			}
		}else{
			$this->display();
		}
	}
	
	public function bdcg(){
		
		$this->display();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}