<?php
namespace Wap\Controller;

use Think\Controller;

class PersonalController extends PublicController {
	
	public function __construct(){
		parent::__construct();
		 //session('uid',null);
		//dump($_SESSION); 
		//session('uid',null);exit;
		$uid=$_SESSION['uid'];
		if(!$uid){
			session('rtype',3);
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		
		$payment_num=M('order_info')->where("order_status = '1' && user_id = '$uid'")->count();
		//待发货
		$shipment_num=M('order_info')->where("order_status = '2' && user_id = '$uid'")->count();
		//待收货
		$receipt_num=M('order_info')->where("order_status = '3' && user_id = '$uid'")->count();
		//待评价
		$appraiset_num=M('order_info')->where("order_status = '4' && user_id = '$uid'")->count();
		//已完成
		$complete_num=M('order_info')->where("order_status = '5' && user_id = '$uid'")->count();
		$this->assign('payment_num',$payment_num);
		$this->assign('shipment_num',$shipment_num);
		$this->assign('receipt_num',$receipt_num);
		$this->assign('appraiset_num',$appraiset_num);
		$this->assign('complete_num',$complete_num); 
	} 

	//个人中心
    public function center(){
		if(I('post.')){
			
			$result=M('user_info')->where("user_id = '$uid'")->save(I('post.'));
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			//dump($_SESSION);
			$position="c";
		$this->assign('wei',$position);
			$this->display();
		}
	}
	
	//我的帐号
	public function account(){
		$arr1=array();$arr2=array();
		$tx=M('tx_record')->where("user_id = '$uid' && status = 2")->select();
		$cz=M('cz_record')->where("user_id = '$uid' && status = 2")->select();
		foreach($tx as $key => $val){
			$arr1[$key]['money']=$val['tx_money'];
			$arr1[$key]['time']=$val['tx_time'];
			$arr1[$key]['status']=1;
		}
		foreach($cz as $k => $v){
			$arr2[$k]['money']=$v['cz_money'];
			$arr2[$k]['time']=$v['cz_time'];
			$arr2[$k]['status']=2;
		}
		$arr=array_merge($arr1,$arr2);
		foreach($arr as $ke => $va){
			$time[$ke]=$va['time'];
		}
		array_multisort($time,SORT_DESC,$arr);
		$this->assign('arr',$arr);
		$position="z";
		$this->assign('wei',$position);
		$this->display();
	}
	
	
	//我的资料
	public function center_data(){
		$uid=$_SESSION['uid'];
		//dump($uid);
		if(I('post.')){
			$result=M('user_info')->where("user_id = '$uid'")->save(I('post.'));
			if($result){
				$this->redirect('Personal/center_data');
			}else{
				$this->redirect('Personal/center_data');
			}
		}else{
			$this->display();
		}
	}

	//修改头像
	public function head_img(){
		$uid=$_SESSION['uid'];
		$upload = new \Think\Upload();// 实例化上传类          
		$upload->maxSize   =     31457280 ;// 设置附件上传大小
		$upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		$upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		$upload->savePath  =     'home/'.CONTROLLER_NAME.'/'; // 设置附件上传（子）目录
		$upload->saveName  =array('uniqid',time().'_'.mt_rand());
		$info   =   $upload->upload();
		if(!$info){
			$this->error($upload->getError());
		}else{
			foreach($info as $file){
				$data['head_img']=$file['savepath'] . $file['savename'];
				$result=M('user_info')->where("user_id = '$uid'")->save($data);
				if($result){
					$this->redirect("Personal/center_data");
				}
			}
		}
	}

	
	//我的地址
	public function center_dizhi(){
		$uid=$_SESSION['uid'];
		$result=M('user_address')->where("user_id = '$uid'")->select();
		$this->assign('address',$result);
		$this->display();
	}
	
	//修改地址
	public function center_dizhigl(){
		if(I('post.')){
			$data['address_xx']=I('post.address_xx');
			$data['location_p']=I('post.location_p');
			$data['location_c']=I('post.location_c');
			$data['location_a']=I('post.location_a');
			$data['consignee']=I('post.consignee');
			$data['mobile']=I('post.mobile');
			if(I('post.is_default')=='on'){
				$data['is_default']=1;
				M('user_address')->where("user_id = '$uid'")->setField('is_default',0);
			}else{
				$data['is_default']=0;
			}
			$add_id=I('post.id');
			$result=M('user_address')->where("address_id = '$add_id'")->save($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$id=I('get.address_id');
			$address=M('user_address')->where("address_id = '$id'")->find();
			$this->assign('address',$address);
			$this->display();
		}
		
	}
	
	//添加地址
	public function center_dizhiadd(){
		if(I('post.')){
			$uid=$_SESSION['uid'];
			$data['user_id']=$uid;
			$data['address_xx']=I('post.address_xx');
			$data['location_p']=I('post.location_p');
			$data['location_c']=I('post.location_c');
			$data['location_a']=I('post.location_a');
			$data['consignee']=I('post.consignee');
			$data['mobile']=I('post.mobile');
			if(I('post.is_default')=='on'){
				$data['is_default']=1;
				M('user_address')->where("user_id = '$uid'")->setField('is_default',0);
			}else{
				$data['is_default']=0;
			}
			$result=M('user_address')->add($data);
			if($result){
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	//订单
	public function dingdan(){
		//dump(session());
		$user_id=$_SESSION['uid'];
		$status=I('get.status');
		if($status){
			$order=M('order_info')->order('order_id desc')->where("order_status = '$status' && user_id = '$user_id'")->select();
		}else{
			$order=M('order_info')->order('order_id desc')->where("user_id = '$user_id'")->select();
		}
		foreach($order as $k => $v){
			$order_id=$v['order_id'];
			$res=M('order_goods')->where("order_id = '$order_id'")->select();
			$order[$k]['goods']=$res;
		}
		//dump($order);
		$this->assign('order',$order);
		$this->assign('status',$status);
		$this->display();
	}
	
	
	//订单收货
	public function shouhuo(){
		$order_id=I('post.order_id');
		$result=M('order_info')->where("order_id = '$order_id'")->setField('order_status','4');
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	//评论
	public function comment(){
		if(I('post.')){
			//dump($_FILES);exit;
			if($_FILES['comment_img']['error']==0){
				$upload = new \Think\Upload();
				$upload->maxSize = 3145728;
				$upload->exts = array('jpg', 'gif', 'png', 'jpeg', 'swf', 'avi', 'flv');
				$upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
				$upload->savePath  =     'wap/'.CONTROLLER_NAME.'/'; // 设置附件上传（子）目录
				$upload->saveName  =array('uniqid',time().'_'.mt_rand());
				$info = $upload->upload();
				if($info){
					$data['comment_img']=$info['comment_img']['savepath'].$info['comment_img']['savename'];
					$data['user_id']=$_SESSION['uid'];
					$data['goods_id']=I('post.goods_id');
					$data['comment_content']=I('post.comment_content');
					$data['comment_time']=time();
					$data['star']=5;
					$result=M('goods_comment')->add($data);
					if($result){
						$goods_id=I('post.goods_id');
						$order_id=I('post.order_id'); 
						M('order_goods')->where("order_id = '$order_id' && goods_id = '$goods_id'")->setField('p_status','2');
						$this->redirect('Personal/dingdan', array('status' => 4));
					}
				}
			}
		}else{
			$goods_id=I('get.goods_id');
			$order_id=I('get.order_id'); 
			$order_goods=M('order_goods')->where("order_id = '$order_id' && goods_id = '$goods_id'")->find();
			$this->assign('order_goods',$order_goods);
			$this->display();
		}
	}
	
	//订单取消
	public function quxiao(){
		$order_id=I('post.order_id');
		$result=M('order_info')->where("order_id = '$order_id'")->setField('order_status','99');
		if($result){
			$return['status']=1;
		}else{
			$return['status']=0;
		}
		$this->ajaxReturn($return);
	}
	
	
	//充值
	public function cz(){
		$uid=$_SESSION['uid'];
		if(I('post.')){
			$data['cz_sn']=$cz_sn="YSCZ".time().rand(10,99);
			$data['user_id']=$uid;
			$data['money']=I('post.money');
			$data['time']=time();
			$res=M('cz_order')->add($data);
			if($res){
				$return['cz_sn']=$cz_sn;
				$return['status']=1;
			}else{
				$return['status']=0;
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	//体现
	public function tx(){
		if(I('post.')){
			$data['user_id']=$uid=$_SESSION['uid'];
			$data['phone']=I('post.phone');
			$data['bank_name']=I('post.bank');
			$data['bank_number']=I('post.bank_number');
			$data['tx_money']=$tx_money=I('post.tx_money');
			$data['true_name']=I('post.true_name');
			$data['tx_time']=time();
			$money=M('user_info')->where('user_id = '.$uid)->getField('money');
			if($tx_money>$money){
				$return['status']=2;
			}else{
				$result=M('tx_record')->add($data);
				if($result){
					$a=$money-$tx_money;
					M('user_info')->where("user_id = '$uid'")->setField('money',$a);
					$return['status']=1;
				}else{
					$return['status']=0;
				}
			}
			$this->ajaxReturn($return);
		}else{
			$this->display();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}