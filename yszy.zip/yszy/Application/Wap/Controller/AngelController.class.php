<?php
namespace Wap\Controller;

use Think\Controller;

class AngelController extends PublicController {
	
	public function index(){
		//我要创业
		$angel_banner=M('ads')->order('sort asc')->where("position_id = '1'")->find();
		$this->assign('angel_banner',$angel_banner);
		
		//创业礼包一图
		$libao1=M('ads')->order('sort asc')->where("position_id = '3'")->find();
		$this->assign('libao1',$libao1);

		//创业礼包二图
		$libao2=M('ads')->order('sort asc')->where("position_id = '6'")->find();
		$this->assign('libao2',$libao2);
		
		//我要创业底部banner图
		$libao3=M('ads')->order('sort asc')->where("position_id = '7'")->select();
		$this->assign('libao3',$libao3);
		
		$a=M('goods')->where("is_on_sale = '1' && g_type = '2'")->getField('goods_id');
		$b=M('goods')->where("is_on_sale = '1' && g_type = '3'")->getField('goods_id');
		$this->assign('a_id',$a);
		$this->assign('b_id',$b);
		
		$position="a";
		$this->assign('wei',$position);
		$this->display();
	}

	public function angel_xq(){
		$goods=M('goods')->where("is_on_sale = '1' && g_type = '2'")->select();
		$this->assign('goods',$goods);
		
		//创业礼包一详情图
		$libao1_xq=M('ads')->order('sort asc')->where("position_id = '4'")->find();
		$this->assign('libao1_xq',$libao1_xq);
		
		$position="a";
		$this->assign('wei',$position);
		$this->display();
	}
	
	public function angel_xq2(){
		$goods=M('goods')->where("is_on_sale = '1' && g_type = '3'")->select();
		$this->assign('goods',$goods);
		
		//创业礼包二详情图
		$libao2_xq=M('ads')->order('sort asc')->where("position_id = '5'")->find();
		$this->assign('libao2_xq',$libao2_xq);
		
		$position="a";
		$this->assign('wei',$position);
		$this->display();
	}
	
	
	
	
	
	
	
	
}