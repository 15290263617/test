<?php
namespace Wap\Controller;

use Think\Controller;

class BuycarController extends PublicController {
	
    public function buycar(){
		$uid=$_SESSION['uid'];
		if(!$uid){
			session('rtype',2);
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$user_type=M('user_info')->where("user_id='$uid'")->getfield('type');
		$car=M('car')->where("user_id = '$uid' && status = '0'")->select();
		foreach($car as $k => $v){
			$car[$k]['g_type']=get_goods_type($v['goods_id']);
			if($user_type==1 || $user_type==2){
				$car[$k]['money']=$v['xzmoney'];
			}else{
				if(get_goods_type($v['goods_id'])==1){
					$car[$k]['money']=number_format($v['num']*get_shop_price($v['goods_id']),2);
				}else{
					$car[$k]['money']=$v['xzmoney'];
				}
			}
			$money+=$v['money'];
		}
		// dump($car);
		$this->assign('car',$car);
		$this->assign('user_type',$user_type);
		$this->assign('totalmoney',number_format($money,2));

		//ÈÈÏú°ñµ¥
		$goods_best=M('goods')->order('goods_id desc')->limit('0,5')->where("is_best = '1' && is_on_sale = '1' && g_type = '1' ")->select();
		$this->assign('goods_best',$goods_best);
		//dump($goods_best);
		$this->display();
	}
	//Á¢¼´¹ºÂò
	public function goumai(){
		$goods_id=I('post.goods_id');
		$uid=$_SESSION['uid'];
		if(!$uid){
			session('rtype',2);
			session('goods_id',$goods_id);
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$return['status']=1;
		$return['goods_id']=I('post.goods_id');
		$return['num']=I('post.num');
		$this->ajaxReturn($return);
	}


public function check1(){
		$uid=$_SESSION['uid'];
		if(!$uid){
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$user_type=M('user_info')->where("user_id='$uid'")->getfield('type');

		$car_id=I('get.car_id');
		$carid=explode(',',$car_id);
		for($i=0;$i<count($carid);$i++){
			$car[$i]=M('car')->where("car_id = '$carid[$i]'")->find();
			if($user_type==1 || $user_type==2){
				$goods_price=get_goods_price($car[$i]['goods_id']);
			}else{
				if(get_goods_type($car[$i]['goods_id'])==1){
					$goods_price=get_shop_price($car[$i]['goods_id']);
				}else{
					$goods_price=get_goods_price($car[$i]['goods_id']);
				}
				
			}
			$car[$i]['jiesuan_price']=number_format($num[$i]*$goods_price,2);
			$car[$i]['jiesuan_num']=$num[$i];
			$car[$i]['g_type']=get_goods_type($car[$i]['goods_id']);
			$totalmoney+=$car[$i]['jiesuan_price'];
			$allmoney+=$car[$i]['xzmoney'];
		}
		$this->assign('nump',$car);
		$this->assign('allmoney',$allmoney);
		$this->assign('totalmoney',number_format($totalmoney,2));
		$address=M('user_address')->where("user_id = '$uid'")->select();
		$is_default=M('user_address')->where("user_id = '$uid' && is_default = '1'")->find();
		$this->assign('address',$address);
		$this->assign('add_id',$is_default['address_id']);
		$this->assign('user_type',$user_type);
		$this->display();
}

	public function order(){
		$uid=$_SESSION['uid'];
		$car_id=I('post.car_id');
		$add_id=I('post.add_id');
		$address=M('user_address')->where("address_id = '$add_id'")->find();
		$totalmoney=I('post.totalmoney');
		$data['order_sn']="YSZY".time().rand(10,99);
		$data['user_id']=$uid;
		$data['consignee']=$address['consignee'];
		$data['address']=$address['city_addr'];
		$data['address_xx']=$address['address_xx'];
		$data['phone']=$address['mobile'];
		$data['order_money']=I('post.totalmoney');
		$data['yunfei']=I('post.yunfei');
		$data['add_time']=time();
		$data['buy_status']=1;
		$result=M('order_info')->add($data);

		if($result){
			$dat['order_id']=$result;
			$carid=explode(',',$car_id);
			for($i=0;$i<count($carid);$i++){
				$dat['goods_id']=get_goods_id($carid[$i]);//产品的id
				$dat['goods_sn']=get_goods_sn($carid[$i]);
				$dat['goods_name']=get_goods_namebycar_id($carid[$i]);
				$dat['market_price']=get_market_price($carid[$i]);
				$dat['goods_number']=get_market_num($carid[$i]);
				$dat['xzmoney']=number_format($num[$i]*get_market_price($carid[$i]),2);
				// $dat['goods_number']=$num[$i];
				// $dat['xzmoney']=number_format($dat['goods_number']*get_market_price($carid[$i]),2);
				$res=M('order_goods')->add($dat);
				M('car')->where("car_id = '$carid[$i]'")->setField('status','1');
				if($res){
					$return['status']=1;
					$return['order_id']=$result;
				}else{
					$return['status']=0;
				}
			}
		}
		$this->ajaxReturn($return);
	}


//Ìá½»
	public function tijao(){
		$num=$_POST['num'];

		if ($num!="") {
		      	$num=rtrim($num,'-');
		      	$where=explode('-',$num);
		    }
		$return['status']=1;
		$return['car_id']=$where;
		$this->ajaxReturn($return);
	}



	public function check(){

		$uid=$_SESSION['uid'];
		if(!$uid){
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$user_type=M('user_info')->where("user_id='$uid'")->getfield('type');
		/* $user_type=$_SESSION['home']['type']; */
		$goods_id=I('get.goods_id');
		$num=I('get.num');
		$goods=M('goods')->where("goods_id = '$goods_id'")->find();
		if($user_type==1 || $user_type==2){
			$goods['totalmoney']=number_format($num*$goods['market_price'],2);
		}else{
			if($goods['g_type']==1){
				$goods['totalmoney']=number_format($num*get_shop_price($goods['goods_id']),2);
			}else{
				$goods['totalmoney']=number_format($num*$goods['market_price'],2);
			}
		}
		$this->assign('num',$num);//
		$this->assign('allmoney',$goods['totalmoney']);
		$this->assign('goods',$goods);//
		$address=M('user_address')->where("user_id = '$uid'")->select();//
		$is_default=M('user_address')->where("user_id = '$uid' && is_default = '1'")->find();//
//		print_r($is_default['address_id']);
		$this->assign('address',$address);//
		$this->assign('add_id',$is_default['address_id']);//
		$this->assign('user_type',$user_type);

		$this->display();
	}
	public function xiadan(){
		$uid=$_SESSION['uid'];
		$goods_id=I('post.goods_id');
		$goodsinfo=M('goods')->where("goods_id")->where("goods_id = '$goods_id'")->find();
		$num=I('post.num');
		$add_id=I('post.add_id');
		$address=M('user_address')->where("address_id = '$add_id'")->find();
		$totalmoney=I('post.totalmoney');
		$data['order_sn']="YSZY".time().rand(10,99);
		$data['user_id']=$uid;
		$data['consignee']=$address['consignee'];
		$data['address']=$address['city_addr'];
		$data['address_xx']=$address['location_p'].$address['location_c'].$address['location_a'];
		$data['phone']=$address['mobile'];
		$data['order_money']=I('post.totalmoney');
		$data['yunfei']=I('post.yunfei');
		$data['add_time']=time();
		$result=M('order_info')->add($data);
		if($result){
			$dat['order_id']=$result;
			$dat['goods_id']=$goods_id;
			$dat['goods_sn']=$goodsinfo['goods_sn'];
			$dat['goods_name']=$goodsinfo['goods_name'];
			$dat['market_price']=$goodsinfo['market_price'];
			$dat['goods_number']=$num;
			$dat['xzmoney']=$totalmoney;
			$res=M('order_goods')->add($dat);
			if($res){
				$return['status']=1;
				$return['order_id']=$result;
			}else{
				$return['status']=0;
			}
		}
		$this->ajaxReturn($return);
	}
	public function comment(){

		$this->display();
	}
	
	public function dingdan(){

		$this->display();
	}
	public function pay(){
		$uid=$_SESSION['uid'];
		if(!$uid){
			$weixin=A('Weixin/Weixin');
			$weixin->user_auth();
		}
		$order_id=I('get.order_id');
		$orderinfo=M('order_info')->where("order_id = '$order_id'")->find();
		$this->assign('orderinfo',$orderinfo);
		
		$this->display();
	}
	public function dingdanxq(){
		$this->display();
	}

	public function do_delete(){
		$num=$_POST['num'];
		
    if ($num!="") {
      	$num=rtrim($num,',');
      	$where=explode(',',$num);
      	$cond['car_id']=array('in',$where);
        $result=M('car')->where($cond)->delete();
      // $result=M()->query("DELETE from `lx_car` where `car_id` in ($num)");
      echo 1;
    }else{
      // query("DELETE from `lx_$table` where `id`='".$id."'");  
      echo -1;    
    }
    
  }



public function xiu(){
		$uid=$_SESSION['uid'];
		$add_id=I('post.add_id');
		$address=M('user_address')->where("user_id='$uid' AND is_default = 1")->setField('is_default',0);
		$address1=M('user_address')->where("address_id='$add_id'")->setField('is_default',1);
		
		
		if($address && $address){
			
				$return['status']=1;
				$return['order_id']=$result;
			}else{
				$return['status']=0;
			}
		
		$this->ajaxReturn($return);
	}

}