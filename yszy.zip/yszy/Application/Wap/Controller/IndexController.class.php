<?php
namespace Wap\Controller;

use Think\Controller;

class IndexController extends PublicController {

    public function index(){
		//session('uid',2);
		//dump($_SESSION);
		//产品分类
		$arr=M("goods_cate")->order("cat_sort asc")->select();
		$this->assign("type",$arr);

		//产品推荐
		$good_tj=M("goods")->where("is_best=1")->limit(6)->select();
		$this->assign("tj",$good_tj);
		
		
		$position="i";
		$this->assign('wei',$position);
		$this->display();
	}
}