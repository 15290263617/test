<?php
namespace Wap\Controller;
use Think\Controller;

class BandController extends Controller{
	public function index(){
			$gtype=I('gtype');
			session('gtype',$gtype);
			$tjid=I('tjid');
			if($tjid){
				session('tjid',$tjid);
			}
			$weixin=A('Weixin/Weixin');
			$weixin->user_authopen();
	}
}	