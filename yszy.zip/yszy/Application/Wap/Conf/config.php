<?php
return array(
	define('WEB_HOST', 'http://www.chuangyepaper.com/'),
    /*微信支付配置*/
    'WxPayConf_pub'=>array(
        'APPID' => 'wxd203d7682a1e9aa8',
        'MCHID' => '1329446701',
        'KEY' => '商户秘钥',
        'APPSECRET' => 'lingxiuwangluokejiyouxiangongsi0',
        'JS_API_CALL_URL' => WEB_HOST.'/index.php/Home/WxJsAPI/jsApiCall',
        'SSLCERT_PATH' => WEB_HOST.'/ThinkPHP/Library/Vendor/WxPayPubHelper/cacert/apiclient_cert.pem',
        'SSLKEY_PATH' => WEB_HOST.'/ThinkPHP/Library/Vendor/WxPayPubHelper/cacert/apiclient_key.pem',
        'NOTIFY_URL' =>  WEB_HOST.'/index.php/Wap/WxPay/notify_url',
        'NOTIFY_URL1' =>  WEB_HOST.'/index.php/Wap/Wxcz/notify_url',
        'CURL_TIMEOUT' => 30
    )
);